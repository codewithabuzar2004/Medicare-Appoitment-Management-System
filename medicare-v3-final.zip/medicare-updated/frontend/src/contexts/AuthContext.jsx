import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../lib/api';

const AuthContext = createContext({});
export const useAuth = () => useContext(AuthContext);

const storage = {
  get:    (k) => { try { return sessionStorage.getItem(k); }     catch { return null; } },
  set:    (k, v) => { try { sessionStorage.setItem(k, v); }      catch {} },
  remove: (k) => { try { sessionStorage.removeItem(k); }         catch {} },
};

export const AuthProvider = ({ children }) => {
  const [user, setUser]         = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Restore session from sessionStorage on tab open
  useEffect(() => {
    const savedUser  = storage.get('user');
    const savedToken = storage.get('token');
    if (savedUser && savedToken) {
      try { setUser(JSON.parse(savedUser)); }
      catch { storage.remove('user'); storage.remove('token'); }
    }
    setIsLoading(false);
  }, []);

  const saveSession = (token, userData) => {
    storage.set('token', token);
    storage.set('user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = useCallback(() => {
    storage.remove('token');
    storage.remove('user');
    setUser(null);
  }, []);

  // Listen to auth:logout event dispatched by api.js 401 interceptor
  useEffect(() => {
    const handler = () => logout();
    window.addEventListener('auth:logout', handler);
    return () => window.removeEventListener('auth:logout', handler);
  }, [logout]);

  const login = async (email, password, role) => {
    const { data } = await api.post('/auth/login', { email, password, role });
    saveSession(data.token, data.user);
    return data.user;
  };

  const registerPatient = async (formData) => {
    const { data } = await api.post('/auth/register/patient', formData);
    saveSession(data.token, data.user);
    return data.user;
  };

  const registerDoctor = async (formData) => {
    const { data } = await api.post('/auth/register/doctor', formData);
    if (data.pending) return { pending: true, message: data.message };
    saveSession(data.token, data.user);
    return data.user;
  };

  // Re-fetch user from server and update sessionStorage (call after profile update)
  const refreshUser = async () => {
    try {
      const { data } = await api.get('/auth/me');
      if (data.user) {
        storage.set('user', JSON.stringify(data.user));
        setUser(data.user);
      }
    } catch { /* silently ignore */ }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, registerPatient, registerDoctor, refreshUser, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};