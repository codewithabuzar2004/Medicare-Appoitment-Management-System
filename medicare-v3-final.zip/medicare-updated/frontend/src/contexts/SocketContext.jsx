import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext(null);
export const useSocket = () => useContext(SocketContext);

// Use relative path so Vite proxy handles it — CORS never triggered
// In production set VITE_SOCKET_URL to your backend URL
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || '';

export const SocketProvider = ({ children }) => {
  const { user } = useAuth();
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!user) {
      setSocket(prev => {
        if (prev) prev.disconnect();
        return null;
      });
      setConnected(false);
      return;
    }

    const sock = io(SOCKET_URL, {
      path: '/socket.io',
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });

    const joinRoom = () => {
      if (user.role === 'patient') sock.emit('join', `patient_${user._id}`);
      else if (user.role === 'doctor') sock.emit('join', `doctor_${user._id}`);
      else if (user.role === 'admin')  sock.emit('join', 'admin');
    };

    sock.on('connect', () => {
      setConnected(true);
      joinRoom();
    });

    sock.on('disconnect', () => setConnected(false));
    sock.on('reconnect', joinRoom);

    setSocket(sock);

    return () => {
      sock.disconnect();
      setSocket(null);
      setConnected(false);
    };
  }, [user?._id, user?.role]);

  return (
    <SocketContext.Provider value={{ socket, connected }}>
      {children}
    </SocketContext.Provider>
  );
};
