import { Component } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider }   from './contexts/AuthContext';
import { SocketProvider } from './contexts/SocketContext';
import ProtectedRoute     from './components/ProtectedRoute';
import ToastContainer     from './components/ToastContainer';
import Index              from './pages/Index';
import Login              from './pages/Login';
import Register           from './pages/Register';
import Doctors            from './pages/Doctors';
import PatientDashboard   from './pages/PatientDashboard';
import DoctorDashboard    from './pages/DoctorDashboard';
import AdminDashboard     from './pages/AdminDashboard';
import { About, Services, Contact, NotFound } from './pages/StaticPages';
import ResetPassword from './pages/ResetPassword';

// ── Global Error Boundary ──────────────────────────────────────────
// Catches any unhandled React render crash and shows a recovery screen
// instead of a blank white page
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('💥 React ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh', display: 'flex', alignItems: 'center',
          justifyContent: 'center', flexDirection: 'column', gap: 16,
          fontFamily: 'sans-serif', background: '#f9fafb', padding: 24,
          textAlign: 'center',
        }}>
          <div style={{ fontSize: 48 }}>⚠️</div>
          <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1f2937' }}>
            Something went wrong
          </h2>
          <p style={{ color: '#6b7280', maxWidth: 380, fontSize: 14 }}>
            An unexpected error occurred. Please go back to the home page and try again.
          </p>
          {this.state.error && (
            <pre style={{
              background: '#fee2e2', color: '#991b1b', padding: '10px 16px',
              borderRadius: 8, fontSize: 12, maxWidth: 480, overflowX: 'auto',
            }}>
              {this.state.error.message}
            </pre>
          )}
          <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              style={{
                background: '#4f46e5', color: '#fff', border: 'none',
                borderRadius: 8, padding: '10px 20px', cursor: 'pointer',
                fontWeight: 600, fontSize: 14,
              }}>
              Try Again
            </button>
            <button
              onClick={() => { window.location.href = '/'; }}
              style={{
                background: '#fff', color: '#4f46e5', border: '2px solid #4f46e5',
                borderRadius: 8, padding: '10px 20px', cursor: 'pointer',
                fontWeight: 600, fontSize: 14,
              }}>
              Go to Home
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ── App ───────────────────────────────────────────────────────────
const App = () => (
  <ErrorBoundary>
    <AuthProvider>
      <SocketProvider>
        <ToastContainer />
        <BrowserRouter>
          <Routes>
            <Route path="/"                   element={<Index />} />
            <Route path="/login"              element={<Login />} />
            <Route path="/register"           element={<Register />} />
            <Route path="/doctors"            element={<Doctors />} />
            <Route path="/services"           element={<Services />} />
            <Route path="/about"              element={<About />} />
            <Route path="/contact"            element={<Contact />} />
            <Route path="/patient/dashboard"  element={
              <ErrorBoundary>
                <ProtectedRoute allowedRoles={['patient']}>
                  <PatientDashboard />
                </ProtectedRoute>
              </ErrorBoundary>
            } />
            <Route path="/doctor/dashboard"   element={
              <ErrorBoundary>
                <ProtectedRoute allowedRoles={['doctor']}>
                  <DoctorDashboard />
                </ProtectedRoute>
              </ErrorBoundary>
            } />
            <Route path="/admin/dashboard"    element={
              <ErrorBoundary>
                <ProtectedRoute allowedRoles={['admin']}>
                  <AdminDashboard />
                </ProtectedRoute>
              </ErrorBoundary>
            } />
            <Route path="/reset-password/:token" element={<ResetPassword />} />
            <Route path="*"                   element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </SocketProvider>
    </AuthProvider>
  </ErrorBoundary>
);

export default App;
