// About.jsx
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Link } from 'react-router-dom';
import { Heart, Shield, Users, Clock, Award, Target } from 'lucide-react';

const stats = [
  { label: 'Active Doctors', value: '500+', icon: Users },
  { label: 'Patients Served', value: '50,000+', icon: Heart },
  { label: 'Years Experience', value: '10+', icon: Award },
  { label: 'Available 24/7', value: '365 Days', icon: Clock },
];

const values = [
  { title: 'Patient First', desc: 'Every decision we make puts our patients\' well-being at the center.', icon: Heart },
  { title: 'Trust & Security', desc: 'Your health data is protected with enterprise-grade encryption.', icon: Shield },
  { title: 'Accessibility', desc: 'Quality healthcare accessible to everyone, anywhere, anytime.', icon: Target },
];

export const About = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-foreground">About <span className="text-gradient">MediCare</span></h1>
          <p className="text-lg text-muted-foreground mt-4 max-w-2xl mx-auto">We're on a mission to make healthcare accessible, affordable, and convenient for everyone.</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {stats.map((s, i) => (
            <motion.div key={s.label} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1 }}>
              <div className="bg-card rounded-xl border border-border p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3"><s.icon className="h-6 w-6 text-primary" /></div>
                <p className="text-3xl font-bold text-foreground">{s.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{s.label}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-heading font-bold text-foreground mb-4">Our Story</h2>
            <div className="space-y-4 text-muted-foreground">
              <p>MediCare was founded with a simple belief: everyone deserves easy access to quality healthcare.</p>
              <p>Our platform bridges the gap between patients and healthcare providers with verified doctors, transparent pricing, and instant booking.</p>
              <p>Today, MediCare serves thousands of patients across India, connecting them with 500+ verified specialists.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[{ label: 'Founded', value: '2020' }, { label: 'Team Members', value: '50+' }, { label: 'Cities Covered', value: '25+' }, { label: 'Specializations', value: '30+' }].map((item, i) => (
              <motion.div key={item.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 + i * 0.1 }}>
                <div className="bg-card rounded-xl border border-border p-4 text-center">
                  <p className="text-2xl font-bold text-primary">{item.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{item.label}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <div className="mb-16">
          <h2 className="text-3xl font-heading font-bold text-foreground text-center mb-8">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {values.map((v, i) => (
              <motion.div key={v.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + i * 0.1 }}>
                <div className="bg-card rounded-xl border border-border p-6 text-center hover-lift h-full">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4"><v.icon className="h-7 w-7 text-primary" /></div>
                  <h3 className="text-lg font-bold text-foreground">{v.title}</h3>
                  <p className="text-sm text-muted-foreground mt-2">{v.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }} className="text-center glass rounded-2xl p-10">
          <h2 className="text-2xl font-heading font-bold text-foreground mb-3">Join the MediCare Family</h2>
          <p className="text-muted-foreground mb-6">Whether you're a patient or a healthcare professional, we'd love to have you on board.</p>
          <div className="flex gap-3 justify-center">
            <Link to="/register" className="px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity">Register Now</Link>
            <Link to="/contact" className="px-6 py-3 rounded-lg border border-border text-foreground font-medium hover:bg-muted transition-colors">Contact Us</Link>
          </div>
        </motion.div>
      </div>
    </main>
    <Footer />
  </div>
);

// Services.jsx
import { Brain, Bone, Baby, Eye, Ear, Stethoscope, Pill, Activity, Microscope, Syringe, Thermometer } from 'lucide-react';

const services = [
  { name: 'Cardiology', desc: 'Heart health checkups, ECG, and advanced cardiac care.', icon: Heart, color: 'bg-red-100 text-red-600' },
  { name: 'Neurology', desc: 'Brain & nervous system disorders, headaches, and epilepsy.', icon: Brain, color: 'bg-purple-100 text-purple-600' },
  { name: 'Orthopedics', desc: 'Bone, joint, and muscle care including fractures and arthritis.', icon: Bone, color: 'bg-blue-100 text-blue-600' },
  { name: 'Pediatrics', desc: 'Complete healthcare for infants, children, and adolescents.', icon: Baby, color: 'bg-pink-100 text-pink-600' },
  { name: 'Ophthalmology', desc: 'Eye exams, vision correction, and surgical treatments.', icon: Eye, color: 'bg-emerald-100 text-emerald-600' },
  { name: 'ENT Care', desc: 'Ear, nose, and throat specialist consultations.', icon: Ear, color: 'bg-amber-100 text-amber-600' },
  { name: 'General Medicine', desc: 'Routine checkups, fever, infections, and preventive care.', icon: Stethoscope, color: 'bg-teal-100 text-teal-600' },
  { name: 'Dermatology', desc: 'Skin conditions, acne treatment, and cosmetic procedures.', icon: Pill, color: 'bg-orange-100 text-orange-600' },
  { name: 'Diagnostics', desc: 'Blood tests, X-rays, MRI, and comprehensive health packages.', icon: Microscope, color: 'bg-indigo-100 text-indigo-600' },
  { name: 'Vaccination', desc: 'All age vaccinations, flu shots, and travel immunizations.', icon: Syringe, color: 'bg-green-100 text-green-600' },
  { name: 'Emergency Care', desc: '24/7 emergency medical services and trauma care.', icon: Activity, color: 'bg-red-100 text-red-600' },
  { name: 'Health Checkup', desc: 'Full body health screening and preventive packages.', icon: Thermometer, color: 'bg-cyan-100 text-cyan-600' },
];

export const Services = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-4xl font-heading font-bold text-foreground">Our <span className="text-gradient">Services</span></h1>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto">Comprehensive healthcare services tailored to your needs.</p>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((svc, i) => (
            <motion.div key={svc.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <div className="bg-card rounded-xl border border-border p-6 flex flex-col h-full hover-lift">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${svc.color}`}><svc.icon className="h-6 w-6" /></div>
                <h3 className="text-lg font-bold text-foreground">{svc.name}</h3>
                <p className="text-sm text-muted-foreground mt-2 flex-1">{svc.desc}</p>
                <Link to="/doctors" className="mt-4 w-full flex items-center justify-center h-9 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted transition-colors">Find Specialists</Link>
              </div>
            </motion.div>
          ))}
        </div>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-center mt-16">
          <h2 className="text-2xl font-heading font-bold text-foreground mb-3">Need a consultation?</h2>
          <p className="text-muted-foreground mb-6">Register now and book your first appointment today.</p>
          <Link to="/register" className="inline-flex items-center px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity">Get Started</Link>
        </motion.div>
      </div>
    </main>
    <Footer />
  </div>
);

// Contact.jsx
import { useState } from 'react';
import { Mail, Phone, MapPin, Clock as ClockIcon, Send, MessageSquare } from 'lucide-react';
import { useToast } from '../hooks/use-toast';
import api from '../lib/api';

const contactInfo = [
  { icon: Mail, label: 'Email', value: 'support@medicare.com', desc: 'We reply within 24 hours' },
  { icon: Phone, label: 'Phone', value: '+91 98765 43210', desc: 'Mon-Sat, 9AM-6PM IST' },
  { icon: MapPin, label: 'Address', value: 'Mumbai, Maharashtra, India', desc: 'Head Office' },
  { icon: ClockIcon, label: 'Working Hours', value: '24/7 Online Support', desc: 'Emergency always available' },
];

export const Contact = () => {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!form.name.trim() || form.name.trim().length < 2) errs.name = 'Name is required (min 2 chars)';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'Valid email is required';
    if (!form.subject.trim()) errs.subject = 'Subject is required';
    if (!form.message.trim() || form.message.trim().length < 10) errs.message = 'Message must be at least 10 characters';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      await api.post('/contact', form);
      toast({ title: 'Message Sent!', description: "We'll get back to you soon." });
      setForm({ name: '', email: '', subject: '', message: '' });
      setErrors({});
    } catch {
      toast({ title: 'Error', description: 'Failed to send message', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const update = (key, value) => {
    setForm(p => ({ ...p, [key]: value }));
    if (errors[key]) setErrors(p => { const n = { ...p }; delete n[key]; return n; });
  };

  const inputClass = (field) => `w-full h-10 px-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring ${errors[field] ? 'border-destructive' : 'border-input'}`;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-4xl font-heading font-bold text-foreground">Contact <span className="text-gradient">Us</span></h1>
            <p className="text-muted-foreground mt-3 max-w-xl mx-auto">Have a question or need help? Reach out to us.</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {contactInfo.map((info, i) => (
              <motion.div key={info.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                <div className="bg-card rounded-xl border border-border p-5 text-center hover-lift h-full">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3"><info.icon className="h-5 w-5 text-primary" /></div>
                  <h3 className="font-bold text-foreground text-sm">{info.label}</h3>
                  <p className="text-sm text-foreground mt-1">{info.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{info.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="max-w-2xl mx-auto">
            <div className="bg-card rounded-xl border border-border p-8">
              <div className="flex items-center gap-2 mb-6">
                <MessageSquare className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-heading font-bold text-foreground">Send us a Message</h2>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-foreground">Your Name</label>
                    <input placeholder="John Doe" value={form.name} onChange={e => update('name', e.target.value)} className={`mt-1 ${inputClass('name')}`} />
                    {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Your Email</label>
                    <input type="email" placeholder="you@example.com" value={form.email} onChange={e => update('email', e.target.value)} className={`mt-1 ${inputClass('email')}`} />
                    {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Subject</label>
                  <input placeholder="How can we help?" value={form.subject} onChange={e => update('subject', e.target.value)} className={`mt-1 ${inputClass('subject')}`} />
                  {errors.subject && <p className="text-sm text-destructive mt-1">{errors.subject}</p>}
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Message</label>
                  <textarea placeholder="Write your message here..." rows={5} value={form.message} onChange={e => update('message', e.target.value)} className={`mt-1 w-full px-3 py-2 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none ${errors.message ? 'border-destructive' : 'border-input'}`} />
                  {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
                </div>
                <button type="submit" disabled={loading} className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity disabled:opacity-60">
                  <Send className="h-4 w-4" /> {loading ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

// NotFound.jsx
export const NotFound = () => (
  <div className="flex min-h-screen items-center justify-center bg-muted">
    <div className="text-center">
      <h1 className="mb-4 text-4xl font-bold">404</h1>
      <p className="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
      <a href="/" className="text-primary underline hover:text-primary/90">Return to Home</a>
    </div>
  </div>
);
