import { useState, useEffect, useMemo, useCallback } from 'react';
import useRealtimeRefresh from '../hooks/useRealtimeRefresh';
import { useSocket } from '../contexts/SocketContext';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import api from '../lib/api';
import {
  Heart, LogOut, Users, Stethoscope, Calendar, ShieldCheck, Ban, UserCheck,
  Search, Plus, IndianRupee, Mail, Phone, User as UserIcon, Lock, Trash2,
  Edit, CheckCircle, XCircle, Eye, X, Clock, LayoutDashboard, ChevronRight, Award, FileText, Star
, CreditCard, Banknote } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../hooks/use-toast';

const fmtSlotTime = (t) => {
  if (!t) return t;
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${ampm}`;
};

const SPECIALIZATIONS = [
  'Cardiologist', 'Dermatologist', 'Orthopedic', 'Pediatrician',
  'Neurologist', 'ENT Specialist', 'Gynecologist', 'General Physician',
  'Psychiatrist', 'Dentist'
];

const StatusBadge = ({ status }) => {
  const map = {
    confirmed: 'bg-green-100 text-green-700',
    completed: 'bg-teal-100 text-teal-700',
    pending:   'bg-yellow-100 text-yellow-700',
    cancelled: 'bg-red-100 text-red-700',
    active:    'bg-green-100 text-green-700',
    blocked:   'bg-red-100 text-red-700',
    rejected:  'bg-red-100 text-red-700',
  };
  const cls = map[status?.toLowerCase()] || 'bg-gray-100 text-gray-600';
  return <span className={`px-2 py-0.5 rounded-md text-xs font-semibold capitalize ${cls}`}>{status}</span>;
};

const Modal = ({ open, onClose, title, children }) => (
  <AnimatePresence>
    {open && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
        <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
          onClick={e => e.stopPropagation()}
          className="bg-card rounded-2xl border border-border p-6 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-heading font-bold text-foreground">{title}</h2>
            <button onClick={onClose} className="p-1 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

// Forms defined OUTSIDE to prevent remount / lose focus on every keystroke
const DoctorForm = ({ form, setForm, errors, setErrors, onSubmit, isEdit }) => {
  const ic = (field) =>
    `w-full h-11 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors[field] ? 'border-destructive' : 'border-input'}`;
  const onChange = useCallback((field, val) => {
    setForm(p => ({ ...p, [field]: val }));
    setErrors(p => ({ ...p, [field]: '' }));
  }, [setForm, setErrors]);
  return (
    <div className="space-y-4 max-h-[68vh] overflow-y-auto pr-1">
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Doctor Name</label>
        <div className="relative">
          <Stethoscope className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="text" placeholder="Dr. John Smith" autoComplete="off"
            value={form.name ?? ''} onChange={e => onChange('name', e.target.value)} className={ic('name')} />
        </div>
        {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Specialization</label>
        <select value={form.specialization ?? ''} onChange={e => onChange('specialization', e.target.value)}
          className={`w-full h-11 px-3 rounded-lg border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors.specialization ? 'border-destructive' : 'border-input'}`}>
          <option value="">Select specialization</option>
          {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        {errors.specialization && <p className="text-xs text-destructive mt-1">{errors.specialization}</p>}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Consultation Fee (₹)</label>
          <div className="relative">
            <IndianRupee className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <input type="number" placeholder="500" min="1" step="1"
              value={form.consultation_fee ?? ''} onChange={e => onChange('consultation_fee', e.target.value)} className={ic('consultation_fee')} />
          </div>
          {errors.consultation_fee && <p className="text-xs text-destructive mt-1">{errors.consultation_fee}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Experience (Years)</label>
          <div className="relative">
            <Award className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <input type="number" placeholder="5" min="0" max="60"
              value={form.experience_years ?? ''} onChange={e => onChange('experience_years', e.target.value)} className={ic('experience_years')} />
          </div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Rating (0–5)</label>
          <div className="relative">
            <Star className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <input type="number" placeholder="4.5" min="0" max="5" step="0.1"
              value={form.rating ?? ''} onChange={e => onChange('rating', e.target.value)} className={ic('rating')} />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Total Reviews</label>
          <div className="relative">
            <FileText className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
            <input type="number" placeholder="0" min="0"
              value={form.total_reviews ?? ''} onChange={e => onChange('total_reviews', e.target.value)} className={ic('total_reviews')} />
          </div>
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">About Doctor</label>
        <textarea placeholder="Brief description of expertise..." rows={2}
          value={form.about ?? ''} onChange={e => onChange('about', e.target.value)}
          className="w-full px-3 py-2.5 rounded-lg border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors resize-none" />
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Email</label>
        <div className="relative">
          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="email" placeholder="doctor@email.com" autoComplete="off"
            value={form.email ?? ''} onChange={e => onChange('email', e.target.value)} className={ic('email')} />
        </div>
        {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">
          Password {isEdit && <span className="text-muted-foreground font-normal text-xs">(leave blank to keep current)</span>}
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="password" placeholder="••••••••" autoComplete="new-password"
            value={form.password ?? ''} onChange={e => onChange('password', e.target.value)} className={ic('password')} />
        </div>
        {errors.password && <p className="text-xs text-destructive mt-1">{errors.password}</p>}
      </div>
      <button onClick={onSubmit}
        className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 active:scale-[0.98] transition-all mt-2">
        {isEdit ? <><Edit className="h-4 w-4" /> Update Doctor</> : <><Plus className="h-4 w-4" /> Add Doctor</>}
      </button>
    </div>
  );
};

const PatientForm = ({ form, setForm, errors, setErrors, onSubmit, isEdit }) => {
  const ic = (field) =>
    `w-full h-11 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors[field] ? 'border-destructive' : 'border-input'}`;
  const onChange = useCallback((field, val) => {
    setForm(p => ({ ...p, [field]: val }));
    setErrors(p => ({ ...p, [field]: '' }));
  }, [setForm, setErrors]);
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Full Name</label>
        <div className="relative">
          <UserIcon className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="text" placeholder="John Doe" autoComplete="off"
            value={form.name ?? ''} onChange={e => onChange('name', e.target.value)} className={ic('name')} />
        </div>
        {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Email</label>
        <div className="relative">
          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="email" placeholder="patient@email.com" autoComplete="off"
            value={form.email ?? ''} onChange={e => onChange('email', e.target.value)} className={ic('email')} />
        </div>
        {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Phone</label>
        <div className="relative">
          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="tel" placeholder="+91 98765 43210" autoComplete="off"
            value={form.phone ?? ''} maxLength={10} onChange={e => onChange('phone', e.target.value.replace(/\D/g,''))} className={ic('phone')} />
        </div>
        {errors.phone && <p className="text-xs text-destructive mt-1">{errors.phone}</p>}
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">
          Password {isEdit && <span className="text-muted-foreground font-normal text-xs">(leave blank to keep current)</span>}
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="password" placeholder="••••••••" autoComplete="new-password"
            value={form.password ?? ''} onChange={e => onChange('password', e.target.value)} className={ic('password')} />
        </div>
        {errors.password && <p className="text-xs text-destructive mt-1">{errors.password}</p>}
      </div>
      <button onClick={onSubmit}
        className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 active:scale-[0.98] transition-all mt-2">
        {isEdit ? <><Edit className="h-4 w-4" /> Update Patient</> : <><Plus className="h-4 w-4" /> Add Patient</>}
      </button>
    </div>
  );
};

const AdminDashboard = () => {
  const { user, logout } = useAuth();
  const { connected }    = useSocket();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [users, setUsers] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [activityLogs, setActivityLogs] = useState([]);
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [reviews, setReviews]           = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [doctorSearch, setDoctorSearch] = useState('');
  const [specFilter, setSpecFilter] = useState('all');
  const [patientSearch, setPatientSearch] = useState('');
  const [apptSearch, setApptSearch] = useState('');
  const [apptStatusFilter, setApptStatusFilter] = useState('all');

  const [addDoctorOpen, setAddDoctorOpen] = useState(false);
  const [addPatientOpen, setAddPatientOpen] = useState(false);
  const [editDoctorOpen, setEditDoctorOpen] = useState(null);
  const [editPatientOpen, setEditPatientOpen] = useState(null);
  const [viewDoctorOpen, setViewDoctorOpen] = useState(null);
  const [viewPatientOpen, setViewPatientOpen] = useState(null);
  const [viewDoctorSlots, setViewDoctorSlots] = useState([]);
  const [viewDoctorAppts, setViewDoctorAppts] = useState([]);
  const [viewPatientAppts, setViewPatientAppts] = useState([]);

  const [doctorForm, setDoctorForm] = useState({});
  const [patientForm, setPatientForm] = useState({});
  const [doctorErrors, setDoctorErrors] = useState({});
  const [patientErrors, setPatientErrors] = useState({});

  const loadData = useCallback(async () => {
    try {
      // All 5 fetches in parallel — allSettled ensures one failure never blocks others
      const [ur, dr, ar, lr, pr] = await Promise.allSettled([
        api.get('/admin/patients'),
        api.get('/admin/doctors'),
        api.get('/admin/appointments'),
        api.get('/admin/activity-logs?limit=50'),
        api.get('/admin/payments'),
      ]);
      if (ur.status === 'fulfilled') {
        const d = ur.value.data;
        setUsers(Array.isArray(d) ? d : (d.users || []));
      }
      if (dr.status === 'fulfilled') {
        const d = dr.value.data;
        setDoctors(Array.isArray(d) ? d : (d.doctors || []));
      }
      if (ar.status === 'fulfilled') {
        const d = ar.value.data;
        setAppointments(Array.isArray(d) ? d : (d.appointments || []));
      }
      if (lr.status === 'fulfilled') {
        // API returns { success, total, page, logs }
        setActivityLogs(lr.value.data.logs || []);
      } else {
        console.warn('[Admin] Activity logs fetch failed:', lr.reason?.message);
      }
      if (pr.status === 'fulfilled') {
        setPaymentHistory(pr.value.data.payments || []);
      } else {
        console.warn('[Admin] Payment history fetch failed:', pr.reason?.message);
      }
      // Fetch reviews
      try {
        const rv = await api.get('/admin/reviews');
        setReviews(rv.data.reviews || []);
      } catch (e) { console.warn('[Admin] Reviews fetch failed:', e.message); }
    } catch (err) {
      console.error('[Admin] loadData error:', err?.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Real-time: refreshes instantly when server emits 'refresh' via Socket.io
  // Call loadData on mount
  useEffect(() => { loadData(); }, [loadData]);
  useRealtimeRefresh(loadData);

  const filteredDoctors = useMemo(() => doctors.filter(d => {
    const ms = !doctorSearch || (d.name||'').toLowerCase().includes(doctorSearch.toLowerCase()) || (d.email||'').toLowerCase().includes(doctorSearch.toLowerCase());
    return ms && (specFilter === 'all' || d.specialization === specFilter);
  }), [doctors, doctorSearch, specFilter]);

  const filteredPatients = useMemo(() => users.filter(u =>
    !patientSearch || (u.name||'').toLowerCase().includes(patientSearch.toLowerCase()) ||
    (u.email||'').toLowerCase().includes(patientSearch.toLowerCase()) || u.phone?.includes(patientSearch)
  ), [users, patientSearch]);

  const filteredAppointments = useMemo(() => appointments.filter(a => {
    const ms = !apptSearch || (a.patient_id?.name || '').toLowerCase().includes(apptSearch.toLowerCase()) || (a.doctor_id?.name || '').toLowerCase().includes(apptSearch.toLowerCase());
    return ms && (apptStatusFilter === 'all' || a.status === apptStatusFilter);
  }), [appointments, apptSearch, apptStatusFilter]);

  const toggleUserStatus = async (id, cur) => {
    const newStatus = cur === 'active' ? 'blocked' : 'active';
    // Optimistic update — immediately reflect in UI
    setUsers(prev => prev.map(u => u._id === id ? { ...u, status: newStatus } : u));
    try {
      await api.put(`/admin/users/${id}/toggle-status`);
      toast({ title: `Patient ${newStatus === 'blocked' ? '🚫 Blocked' : '✅ Activated'}` });
    } catch (err) {
      // Revert on error
      setUsers(prev => prev.map(u => u._id === id ? { ...u, status: cur } : u));
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const toggleDoctorStatus = async (id, cur) => {
    const newStatus = cur === 'active' ? 'blocked' : 'active';
    // Optimistic update — immediately reflect in UI
    setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: newStatus } : d));
    try {
      await api.put(`/admin/users/${id}/toggle-status`);
      toast({ title: newStatus === 'blocked' ? '🚫 Doctor Blocked' : '✅ Doctor Activated' });
    } catch (err) {
      // Revert on error
      setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: cur } : d));
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const approveDoctor = async (id, name) => {
    // Optimistic update
    setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: 'active' } : d));
    try {
      await api.put(`/admin/doctors/${id}/approve`);
      toast({ title: `✅ Dr. ${name} Approved!`, description: 'Doctor can now login.' });
    } catch (err) {
      setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: 'pending' } : d));
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const rejectDoctor = async (id, name) => {
    if (!window.confirm(`Reject Dr. ${name}? They will not be able to login.`)) return;
    // Optimistic update
    setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: 'rejected' } : d));
    try {
      await api.put(`/admin/doctors/${id}/reject`);
      toast({ title: `Dr. ${name} Rejected` });
    } catch (err) {
      setDoctors(prev => prev.map(d => d._id === id ? { ...d, status: 'pending' } : d));
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const deleteDoctor = async (id) => {
    if (!window.confirm('Delete this doctor? This will also delete all their appointments and availability slots.')) return;
    try {
      await api.delete(`/admin/doctors/${id}`);
      toast({ title: 'Doctor deleted' });
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const deletePatient = async (id) => {
    if (!window.confirm('Delete this patient? This will also delete all their appointments.')) return;
    try {
      await api.delete(`/admin/patients/${id}`);
      toast({ title: 'Patient deleted' });
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const handleApptStatus = async (id, status) => {
    try {
      await api.put(`/admin/appointments/${id}/status`, { status });
      toast({ title: `Appointment ${status}` });
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };

  const validateDoctor = () => {
    const e = {};
    if (!doctorForm.name?.trim() || doctorForm.name.trim().length < 2) e.name = 'Name required (min 2 chars)';
    if (!doctorForm.specialization) e.specialization = 'Specialization required';
    if (!doctorForm.consultation_fee || Number(doctorForm.consultation_fee) <= 0) e.consultation_fee = 'Valid fee required';
    if (!doctorForm.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(doctorForm.email)) e.email = 'Valid email required';
    if (!editDoctorOpen && (!doctorForm.password || doctorForm.password.length < 6)) e.password = 'Password min 6 chars';
    setDoctorErrors(e); return Object.keys(e).length === 0;
  };
  const validatePatient = () => {
    const e = {};
    if (!patientForm.name?.trim() || patientForm.name.trim().length < 2) e.name = 'Name required (min 2 chars)';
    if (!patientForm.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(patientForm.email)) e.email = 'Valid email required';
    if (!patientForm.phone?.trim() || !/^\d{10}$/.test(patientForm.phone.trim())) e.phone = 'Phone number must be exactly 10 digits';
    if (!editPatientOpen && (!patientForm.password || patientForm.password.length < 6)) e.password = 'Password min 6 chars';
    setPatientErrors(e); return Object.keys(e).length === 0;
  };

  const handleAddDoctor = async () => {
    if (!validateDoctor()) return;
    try {
      const d = {
        name:             doctorForm.name?.trim(),
        specialization:   doctorForm.specialization,
        consultation_fee: Number(doctorForm.consultation_fee),
        experience_years: Number(doctorForm.experience_years) || 0,
        about:            doctorForm.about?.trim() || '',
        email:            doctorForm.email?.trim(),
        password:         doctorForm.password,
        rating:           Number(doctorForm.rating) || 4.0,
      };
      await api.post('/admin/doctors', d);
      toast({ title: 'Doctor added!' });
      setDoctorForm({}); setDoctorErrors({}); setAddDoctorOpen(false); loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const handleEditDoctor = async () => {
    if (!validateDoctor() || !editDoctorOpen) return;
    try {
      const d = {
        name:             doctorForm.name?.trim(),
        specialization:   doctorForm.specialization,
        consultation_fee: Number(doctorForm.consultation_fee),
        experience_years: Number(doctorForm.experience_years) || 0,
        about:            doctorForm.about?.trim() || '',
        email:            doctorForm.email?.trim(),
        rating:           Number(doctorForm.rating) || undefined,
      };
      if (doctorForm.password) d.password = doctorForm.password;
      await api.put(`/admin/doctors/${editDoctorOpen}`, d);
      toast({ title: 'Doctor updated!' });
      setDoctorForm({}); setDoctorErrors({}); setEditDoctorOpen(null); loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const handleAddPatient = async () => {
    if (!validatePatient()) return;
    try {
      const d = {
        name:     patientForm.name?.trim() || patientForm.full_name?.trim(),
        email:    patientForm.email.trim(),
        password: patientForm.password,
        phone:    patientForm.phone.trim(),
      };
      await api.post('/admin/patients', d);
      toast({ title: 'Patient added!' });
      setPatientForm({}); setPatientErrors({}); setAddPatientOpen(false); loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };
  const handleEditPatient = async () => {
    if (!validatePatient() || !editPatientOpen) return;
    try {
      const d = {
        name:  patientForm.name?.trim() || patientForm.full_name?.trim(),
        email: patientForm.email.trim(),
        phone: patientForm.phone.trim(),
      };
      if (patientForm.password) d.password = patientForm.password;
      await api.put(`/admin/patients/${editPatientOpen}`, d);
      toast({ title: 'Patient updated!' });
      setPatientForm({}); setPatientErrors({}); setEditPatientOpen(null); loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed', variant: 'destructive' });
    }
  };

  const openEditDoctor = (d) => {
    setDoctorForm({
      name:             d.name || '',
      specialization:   d.specialization || '',
      consultation_fee: d.consultation_fee ? String(d.consultation_fee) : '',
      experience_years: d.experience_years ? String(d.experience_years) : '',
      about:            d.about || '',
      email:            d.email || '',
      rating:           d.rating ? String(d.rating) : '4.0',
      password:         '',
    });
    setDoctorErrors({});
    setEditDoctorOpen(d._id);
  };
  const openEditPatient = (u) => {
    setPatientForm({ name: u.name || '', email: u.email || '', phone: u.phone || '', password: '' });
    setPatientErrors({});
    setEditPatientOpen(u._id);
  };
  const openViewDoctor = async (d) => {
    setViewDoctorOpen(d);
    try {
      const sr = await api.get(`/doctors/${d._id}/availability`);
      setViewDoctorSlots(sr.data.slots || sr.data || []);
      setViewDoctorAppts(appointments.filter(a => {
        const did = a.doctor_id?._id || a.doctor_id;
        return did?.toString() === d._id?.toString();
      }));
    } catch {
      setViewDoctorSlots([]);
      setViewDoctorAppts([]);
    }
  };

  const openViewPatient = async (u) => {
    setViewPatientOpen(u);
    try {
      setViewPatientAppts(appointments.filter(a => {
        const pid = a.patient_id?._id || a.patient_id;
        return pid?.toString() === u._id?.toString();
      }));
    } catch {
      setViewPatientAppts([]);
    }
  };

  const navItems = [
    { id: 'overview',      label: 'Overview',      icon: LayoutDashboard },
    { id: 'patients',      label: 'Patients',       icon: Users,       count: users.length },
    { id: 'doctors',       label: 'Doctors',        icon: Stethoscope,  count: doctors.length },
    { id: 'appointments',  label: 'Appointments',   icon: Calendar,    count: appointments.length },
    { id: 'activity',      label: 'Activity Logs',  icon: ShieldCheck },
    { id: 'payments',      label: 'Payments',        icon: CreditCard },
    { id: 'reviews',       label: 'Reviews',         icon: Star },
  ];

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-3">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-muted-foreground text-sm">Loading dashboard…</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex" data-theme="admin">

      {/* SIDEBAR */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-card border-r border-border flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:static lg:flex`}>
        <div className="flex items-center gap-3 px-5 py-5 border-b border-border">
          <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
            <Heart className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <p className="font-heading font-bold text-foreground text-base leading-tight">MediCare</p>
            <span className="text-xs font-semibold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">Admin Panel</span>
          </div>
        </div>

        {/* Role card */}
        <div className="mx-4 mt-4 p-3 rounded-xl bg-primary/5 border border-primary/10 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="h-5 w-5 text-primary" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground truncate">{user?.name || user?.email}</p>
            <span className="inline-block text-xs font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-full capitalize">{user?.role}</span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">Management</p>
          {navItems.map(item => (
            <button key={item.id} onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                activeTab === item.id ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}>
              <item.icon className="h-4 w-4 flex-shrink-0" />
              <span className="flex-1 text-left">{item.label}</span>
              {item.count !== undefined && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full font-semibold ${activeTab === item.id ? 'bg-white/20 text-white' : 'bg-muted-foreground/10 text-muted-foreground'}`}>
                  {item.count}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="px-3 pb-4 border-t border-border pt-4">
          <button onClick={() => { logout(); navigate('/login?role=admin'); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all">
            <Lock className="h-4 w-4" /> Forgot Password
          </button>
          <button onClick={() => { logout(); navigate('/'); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-all">
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* MAIN */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="bg-card border-b border-border px-4 lg:px-6 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-muted">
              <LayoutDashboard className="h-5 w-5" />
            </button>
            <div>
              <nav className="flex items-center gap-1 text-xs text-muted-foreground">
                <span>Admin</span>
                <ChevronRight className="h-3 w-3" />
                <span className="text-foreground font-medium capitalize">{activeTab}</span>
              </nav>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg font-heading font-bold text-foreground capitalize">
                  {activeTab === 'overview' ? 'Dashboard Overview' : activeTab}
                </h1>
                <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-bold
                  ${connected ? 'bg-green-100 border-green-200 text-green-700' : 'bg-gray-100 border-gray-200 text-gray-500'}`}>
                  <span className="relative flex h-1.5 w-1.5">
                    {connected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>}
                    <span className={`relative inline-flex rounded-full h-1.5 w-1.5 ${connected ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                  </span>
                  {connected ? 'LIVE' : 'Connecting...'}
                </span>
              </div>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-primary" />
            {user?.email}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">

          {/* OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Patients',    value: users.length,        icon: Users,       color: 'bg-blue-50 text-blue-600',   tab: 'patients' },
                  { label: 'Total Doctors',      value: doctors.length,      icon: Stethoscope, color: 'bg-teal-50 text-teal-600',   tab: 'doctors' },
                  { label: 'Active Doctors',     value: doctors.filter(d=>d.status==='active').length,  icon: ShieldCheck, color: 'bg-green-50 text-green-600',  tab: 'doctors' },
                  { label: 'Pending Approval',  value: doctors.filter(d=>d.status==='pending').length, icon: Clock,       color: 'bg-yellow-50 text-yellow-600', tab: 'doctors' },
                  { label: 'Appointments',       value: appointments.length, icon: Calendar,    color: 'bg-purple-50 text-purple-600',tab: 'appointments' },
                ].map((s, i) => (
                  <motion.button key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                    onClick={() => setActiveTab(s.tab)}
                    className="bg-card rounded-2xl border border-border p-5 text-left hover:shadow-md hover:-translate-y-0.5 transition-all">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${s.color}`}>
                      <s.icon className="h-5 w-5" />
                    </div>
                    <p className="text-2xl font-bold text-foreground">{s.value}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                  </motion.button>
                ))}
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                {[
                  { label: 'pending',  value: appointments.filter(a=>a.status==='pending').length,  color: 'bg-yellow-400' },
                  { label: 'confirmed', value: appointments.filter(a=>a.status==='confirmed').length, color: 'bg-green-500' },
                  { label: 'completed', value: appointments.filter(a=>a.status==='completed').length, color: 'bg-teal-500' },
                  { label: 'cancelled', value: appointments.filter(a=>a.status==='cancelled').length, color: 'bg-red-500' },
                ].map((s, i) => (
                  <div key={i} className="bg-card rounded-2xl border border-border p-5 flex items-center gap-4">
                    <div className={`w-3 h-12 rounded-full ${s.color}`} />
                    <div>
                      <p className="text-2xl font-bold text-foreground">{s.value}</p>
                      <p className="text-sm text-muted-foreground">{s.label} Appointments</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-card rounded-2xl border border-border p-5">
                <h3 className="font-heading font-bold text-foreground mb-4 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" /> Recent Appointments
                </h3>
                {appointments.length === 0
                  ? <p className="text-sm text-muted-foreground text-center py-4">No appointments yet</p>
                  : appointments.slice(0, 5).map(appt => (
                    <div key={appt._id} className="flex items-center justify-between p-3 bg-muted rounded-xl mb-2">
                      <div>
                        <p className="text-sm font-medium text-foreground">{appt.patient_id?.name || 'Unknown Patient'} → {appt.doctor_id?.name || 'Unknown Doctor'}</p>
                        <p className="text-xs text-muted-foreground">{new Date(appt.appointment_date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', day: '2-digit', month: 'short', year: 'numeric' })}</p>
                      </div>
                      <StatusBadge status={appt.status} />
                    </div>
                  ))
                }
              </div>
            </div>
          )}

          {/* PATIENTS */}
          {activeTab === 'patients' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <input placeholder="Search by name, email or phone…" value={patientSearch}
                    onChange={e => setPatientSearch(e.target.value)}
                    className="w-full h-10 pl-10 pr-3 rounded-xl border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
                <button onClick={() => { setPatientForm({}); setPatientErrors({}); setAddPatientOpen(true); }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                  <Plus className="h-4 w-4" /> Add Patient
                </button>
              </div>
              {filteredPatients.length === 0
                ? <p className="text-muted-foreground text-center py-8">No patients found.</p>
                : filteredPatients.map((u, i) => (
                  <motion.div key={u._id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                    <div className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between flex-wrap gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                          <UserIcon className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{u.name}</p>
                          <p className="text-sm text-muted-foreground">{u.email} • {u.phone}</p>
                          <p className="text-xs text-muted-foreground">Joined: {new Date(u.createdAt).toLocaleDateString('en-IN')}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={u.status} />
                        <button onClick={() => openViewPatient(u)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors" title="View"><Eye className="h-4 w-4" /></button>
                        <button onClick={() => openEditPatient(u)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors" title="Edit"><Edit className="h-4 w-4" /></button>
                        <button onClick={() => toggleUserStatus(u._id, u.status)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors">
                          {u.status === 'active' ? <Ban className="h-4 w-4 text-orange-500" /> : <UserCheck className="h-4 w-4 text-green-600" />}
                        </button>
                        <button onClick={() => deletePatient(u._id)} className="p-2 rounded-lg border border-border hover:bg-red-50 transition-colors"><Trash2 className="h-4 w-4 text-destructive" /></button>
                      </div>
                    </div>
                  </motion.div>
                ))
              }
            </div>
          )}

          {/* DOCTORS */}
          {activeTab === 'doctors' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                <div className="flex gap-3 flex-1">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input placeholder="Search by name or email…" value={doctorSearch}
                      onChange={e => setDoctorSearch(e.target.value)}
                      className="w-full h-10 pl-10 pr-3 rounded-xl border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <select value={specFilter} onChange={e => setSpecFilter(e.target.value)}
                    className="h-10 px-3 rounded-xl border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring min-w-[160px]">
                    <option value="all">All Specializations</option>
                    {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <button onClick={() => { setDoctorForm({}); setDoctorErrors({}); setAddDoctorOpen(true); }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                  <Plus className="h-4 w-4" /> Add Doctor
                </button>
              </div>
              {/* ── PENDING DOCTORS - Prominent Alert Section ── */}
              {(() => {
                const pendingDoctors = doctors.filter(d => d.status === 'pending');
                if (pendingDoctors.length === 0) return null;
                return (
                  <div className="bg-yellow-50 border-2 border-yellow-300 rounded-2xl p-5 mb-2">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-8 h-8 rounded-lg bg-yellow-400 flex items-center justify-center">
                        <Clock className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-yellow-800">
                          {pendingDoctors.length} Doctor{pendingDoctors.length > 1 ? 's' : ''} Awaiting Approval
                        </h3>
                        <p className="text-xs text-yellow-700">These doctors cannot login until you approve them</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {pendingDoctors.map(d => (
                        <div key={d._id} className="bg-white border border-yellow-200 rounded-xl p-3 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-9 h-9 rounded-lg bg-yellow-100 flex items-center justify-center flex-shrink-0">
                              <Stethoscope className="h-4 w-4 text-yellow-600" />
                            </div>
                            <div className="min-w-0">
                              <p className="font-semibold text-foreground text-sm truncate">{d.name}</p>
                              <p className="text-xs text-muted-foreground truncate">{d.specialization} • {d.email}</p>
                              <p className="text-[10px] text-yellow-600 font-medium mt-0.5">
                                Registered: {new Date(d.createdAt).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="px-2 py-0.5 rounded-md bg-yellow-100 text-yellow-700 text-xs font-semibold">Pending</span>
                            <button onClick={() => approveDoctor(d._id, d.name)}
                              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-bold hover:bg-green-600 transition-colors shadow-sm">
                              <UserCheck className="h-3.5 w-3.5" /> Approve
                            </button>
                            <button onClick={() => rejectDoctor(d._id, d.name)}
                              className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-orange-500 text-white text-xs font-bold hover:bg-orange-600 transition-colors" title="Reject Registration">
                              <XCircle className="h-3.5 w-3.5" /> Reject
                            </button>
                            <button onClick={() => deleteDoctor(d._id)}
                              className="p-1.5 rounded-lg border border-border hover:bg-red-50 transition-colors" title="Delete">
                              <Trash2 className="h-3.5 w-3.5 text-destructive" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}

              {/* ── ACTIVITY LOGS ── */}

              {/* ── ALL DOCTORS LIST ── */}
              {filteredDoctors.length === 0
                ? <p className="text-muted-foreground text-center py-8">No doctors found.</p>
                : filteredDoctors.map((d, i) => (
                  <motion.div key={d._id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                    <div className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between flex-wrap gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                          <Stethoscope className="h-5 w-5 text-teal-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{d.name}</p>
                          <p className="text-sm text-muted-foreground">{d.specialization} • ₹{d.consultation_fee}</p>
                          <p className="text-xs text-muted-foreground">{d.email} • Joined: {new Date(d.createdAt).toLocaleDateString('en-IN')}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={d.status} />
                        <button onClick={() => openViewDoctor(d)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors" title="View"><Eye className="h-4 w-4" /></button>
                        <button onClick={() => openEditDoctor(d)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors" title="Edit"><Edit className="h-4 w-4" /></button>
                        {d.status === 'pending' ? (
                          <button onClick={() => approveDoctor(d._id, d.name)} title="Approve Doctor"
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-green-500 text-white text-xs font-semibold hover:bg-green-600 transition-colors">
                            <UserCheck className="h-3.5 w-3.5" /> Approve
                          </button>
                        ) : (
                          <button onClick={() => toggleDoctorStatus(d._id, d.status)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors"
                            title={d.status === 'active' ? 'Block Doctor' : 'Activate Doctor'}>
                            {d.status === 'active' ? <Ban className="h-4 w-4 text-orange-500" /> : <UserCheck className="h-4 w-4 text-green-600" />}
                          </button>
                        )}
                        <button onClick={() => deleteDoctor(d._id)} className="p-2 rounded-lg border border-border hover:bg-red-50 transition-colors"><Trash2 className="h-4 w-4 text-destructive" /></button>
                      </div>
                    </div>
                  </motion.div>
                ))
              }
            </div>
          )}

        {/* ── PAYMENTS TAB ── */}
        {activeTab === 'payments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-bold text-foreground text-lg flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" /> Payment Transactions
              </h3>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> {paymentHistory.filter(p=>p.status==='success').length} Paid</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400" /> {paymentHistory.filter(p=>p.status==='pending').length} Pending</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> {paymentHistory.filter(p=>p.status==='failed').length} Failed</span>
              </div>
            </div>

            {paymentHistory.length === 0 ? (
              <p className="text-muted-foreground text-center py-12">No payment records yet.</p>
            ) : (
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="hidden md:grid grid-cols-7 gap-3 px-5 py-3 bg-muted/50 border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  <div className="col-span-2">Transaction</div>
                  <div>Patient</div>
                  <div>Doctor</div>
                  <div>Amount</div>
                  <div>Method</div>
                  <div>Status</div>
                </div>
                <div className="divide-y divide-border">
                  {paymentHistory.map((pay) => (
                    <div key={pay._id} className="grid grid-cols-1 md:grid-cols-7 gap-2 md:gap-3 px-5 py-4 hover:bg-muted/30 transition-colors">
                      <div className="col-span-2">
                        <p className="text-sm font-semibold text-foreground">#{pay._id?.slice(-6).toUpperCase()}</p>
                        <p className="text-xs text-muted-foreground">{new Date(pay.createdAt).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'})}</p>
                        {pay.razorpay_payment_id && <p className="text-[10px] text-muted-foreground font-mono">{pay.razorpay_payment_id.slice(0,16)}…</p>}
                      </div>
                      <div className="text-sm text-foreground font-medium">{pay.patient_id?.name || '—'}<br/><span className="text-xs text-muted-foreground">{pay.patient_id?.phone || ''}</span></div>
                      <div className="text-sm text-foreground">{pay.doctor_id?.name || '—'}<br/><span className="text-xs text-muted-foreground">{pay.doctor_id?.specialization || ''}</span></div>
                      <div className="text-sm font-bold text-foreground">₹{pay.amount?.toLocaleString('en-IN')}</div>
                      <div>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-semibold ${pay.paymentMode === 'razorpay' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-teal-50 text-teal-700 border border-teal-200'}`}>
                          {pay.paymentMode === 'razorpay' ? <CreditCard className="h-3 w-3" /> : <CreditCard className="h-3 w-3" />}
                          {pay.paymentMode === 'razorpay' ? 'Online' : 'Online'}
                        </span>
                      </div>
                      <div>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-bold ${
                          pay.status === 'success'  ? 'bg-green-100 text-green-700' :
                          pay.status === 'pending'  ? 'bg-yellow-100 text-yellow-700' :
                          pay.status === 'failed'   ? 'bg-red-100 text-red-700' :
                          pay.status === 'refunded' ? 'bg-purple-100 text-purple-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {pay.status === 'success' ? '✓ Paid' : pay.status === 'pending' ? '⏳ Pending' : pay.status === 'failed' ? '✗ Failed' : pay.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="px-5 py-3 bg-muted/30 border-t border-border flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">{paymentHistory.length} total transactions</span>
                  <span className="text-sm font-bold text-foreground">
                    Total Revenue: ₹{paymentHistory.filter(p=>p.status==='success').reduce((s,p)=>s+(p.amount||0),0).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── REVIEWS TAB ── */}
        {activeTab === 'reviews' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-bold text-foreground text-lg flex items-center gap-2">
                <Star className="h-5 w-5 text-amber-500" /> Doctor Reviews
              </h3>
              <span className="text-sm text-muted-foreground">{reviews.length} total</span>
            </div>

            {reviews.length === 0 ? (
              <p className="text-muted-foreground text-center py-12">No reviews yet.</p>
            ) : (
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                <div className="hidden md:grid grid-cols-6 gap-3 px-5 py-3 bg-muted/50 border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  <div className="col-span-2">Patient</div>
                  <div>Doctor</div>
                  <div>Rating</div>
                  <div>Review</div>
                  <div>Date</div>
                </div>
                <div className="divide-y divide-border">
                  {reviews.map((rv) => (
                    <div key={rv._id} className="grid grid-cols-1 md:grid-cols-6 gap-2 md:gap-3 px-5 py-4 hover:bg-muted/30 transition-colors">
                      <div className="col-span-2">
                        <p className="text-sm font-semibold text-foreground">{rv.patient_id?.name || '—'}</p>
                        <p className="text-xs text-muted-foreground">{rv.patient_id?.email || ''}</p>
                      </div>
                      <div>
                        <p className="text-sm text-foreground font-medium">{rv.doctor_id?.name || '—'}</p>
                        <p className="text-xs text-muted-foreground">{rv.doctor_id?.specialization || ''}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {[1,2,3,4,5].map(n => (
                          <Star key={n} className={`h-3.5 w-3.5 ${n <= rv.rating ? 'text-amber-400 fill-amber-400' : 'text-muted-foreground/30'}`} />
                        ))}
                        <span className="text-xs font-bold text-foreground ml-1">{rv.rating}</span>
                      </div>
                      <div>
                        <p className="text-sm text-foreground line-clamp-2">{rv.review || <span className="text-muted-foreground italic">No comment</span>}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">{new Date(rv.createdAt).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'})}</p>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${rv.isVisible ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {rv.isVisible ? 'Visible' : 'Hidden'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="px-5 py-3 bg-muted/30 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    Average: <strong>{reviews.length ? (reviews.reduce((s,r)=>s+r.rating,0)/reviews.length).toFixed(1) : '—'}</strong> ★ across {reviews.length} reviews
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'activity' && (
          <div className="space-y-3">
            <h3 className="font-heading font-bold text-foreground text-lg">Admin Activity Logs</h3>
            {activityLogs.length === 0
              ? <p className="text-muted-foreground text-center py-8">No activity logs yet.</p>
              : activityLogs.map((log) => (
                <div key={log._id} className="bg-card rounded-xl border border-border p-4 flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-block px-2 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-bold">{log.action}</span>
                      <span className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</span>
                    </div>
                    <p className="text-sm text-foreground mt-1">{log.details}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">By: {log.admin_id?.name || 'Admin'}</p>
                  </div>
                </div>
              ))
            }
          </div>
        )}

          {/* APPOINTMENTS */}
          {activeTab === 'appointments' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <input placeholder="Search patient or doctor…" value={apptSearch}
                    onChange={e => setApptSearch(e.target.value)}
                    className="w-full h-10 pl-10 pr-3 rounded-xl border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
                <select value={apptStatusFilter} onChange={e => setApptStatusFilter(e.target.value)}
                  className="h-10 px-3 rounded-xl border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring w-40">
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
              {filteredAppointments.length === 0
                ? <p className="text-muted-foreground text-center py-8">No appointments found.</p>
                : filteredAppointments.map((appt, i) => (
                  <motion.div key={appt._id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                    <div className="bg-card rounded-2xl border border-border p-4 flex items-center justify-between flex-wrap gap-3">
                      <div>
                        <p className="font-semibold text-foreground">
                          {appt.patient_id?.name || 'Unknown'} → {appt.doctor_id?.name || 'Unknown'}
                        </p>
                        <p className="text-sm text-muted-foreground">{appt.doctor_id?.specialization || '—'} • ₹{appt.fee_at_booking ?? appt.doctor_id?.consultation_fee ?? '—'}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(appt.appointment_date).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={appt.status} />
                        {appt.paymentStatus && (
                          <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
                            appt.paymentStatus === 'paid'    ? 'bg-green-100 text-green-700' :
                            appt.paymentStatus === 'failed'  ? 'bg-red-100 text-red-700'   :
                            appt.paymentStatus === 'refunded'? 'bg-blue-100 text-blue-700' :
                            'bg-gray-100 text-gray-600'
                          }`}>₹ {appt.paymentStatus}</span>
                        )}
                        {appt.status === 'pending' && (
                          <>
                            <button onClick={() => handleApptStatus(appt._id, 'confirmed')} title="Confirm" className="p-2 rounded-lg border border-border hover:bg-green-50 transition-colors"><CheckCircle className="h-4 w-4 text-green-600" /></button>
                            <button onClick={() => handleApptStatus(appt._id, 'cancelled')} title="Cancel" className="p-2 rounded-lg border border-border hover:bg-red-50 transition-colors"><XCircle className="h-4 w-4 text-red-600" /></button>
                          </>
                        )}
                        {appt.status === 'confirmed' && (
                          <>
                            <button onClick={() => handleApptStatus(appt._id, 'completed')} title="Mark Completed"
                              className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-green-200 bg-green-50 text-xs text-green-700 hover:bg-green-100 transition-colors">
                              <CheckCircle className="h-3.5 w-3.5" /> Complete
                            </button>
                            <button onClick={() => handleApptStatus(appt._id, 'cancelled')} title="Cancel"
                              className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-border text-xs text-destructive hover:bg-red-50 transition-colors">
                              <XCircle className="h-3.5 w-3.5" /> Cancel
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))
              }
            </div>
          )}

        </main>
      </div>

      {/* MODALS */}
      <Modal open={addDoctorOpen} onClose={() => { setAddDoctorOpen(false); setDoctorForm({}); setDoctorErrors({}); }} title="Add New Doctor">
        <DoctorForm form={doctorForm} setForm={setDoctorForm} errors={doctorErrors} setErrors={setDoctorErrors} onSubmit={handleAddDoctor} isEdit={false} />
      </Modal>
      <Modal open={!!editDoctorOpen} onClose={() => { setEditDoctorOpen(null); setDoctorForm({}); setDoctorErrors({}); }} title="Edit Doctor">
        <DoctorForm form={doctorForm} setForm={setDoctorForm} errors={doctorErrors} setErrors={setDoctorErrors} onSubmit={handleEditDoctor} isEdit={true} />
      </Modal>
      <Modal open={addPatientOpen} onClose={() => { setAddPatientOpen(false); setPatientForm({}); setPatientErrors({}); }} title="Add New Patient">
        <PatientForm form={patientForm} setForm={setPatientForm} errors={patientErrors} setErrors={setPatientErrors} onSubmit={handleAddPatient} isEdit={false} />
      </Modal>
      <Modal open={!!editPatientOpen} onClose={() => { setEditPatientOpen(null); setPatientForm({}); setPatientErrors({}); }} title="Edit Patient">
        <PatientForm form={patientForm} setForm={setPatientForm} errors={patientErrors} setErrors={setPatientErrors} onSubmit={handleEditPatient} isEdit={true} />
      </Modal>

      <Modal open={!!viewDoctorOpen} onClose={() => setViewDoctorOpen(null)} title="Doctor Details">
        {viewDoctorOpen && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-muted-foreground text-xs mb-0.5">Name</p><p className="font-medium text-foreground">{viewDoctorOpen.name}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Specialization</p><p className="font-medium text-foreground">{viewDoctorOpen.specialization}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Fee</p><p className="font-medium text-foreground">₹{viewDoctorOpen.consultation_fee}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Email</p><p className="font-medium text-foreground break-all">{viewDoctorOpen.email}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Status</p><StatusBadge status={viewDoctorOpen.status} /></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Joined</p><p className="font-medium text-foreground">{new Date(viewDoctorOpen.createdAt).toLocaleDateString('en-IN')}</p></div>
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Availability ({viewDoctorSlots.length} slots)</p>
              {viewDoctorSlots.length === 0 ? <p className="text-xs text-muted-foreground">No slots set</p> :
                viewDoctorSlots.map(s => <div key={s._id} className="bg-muted p-2 rounded mb-1 text-sm">{s.day}: {fmtSlotTime(s.start_time)} – {fmtSlotTime(s.end_time)} IST</div>)}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Appointments ({viewDoctorAppts.length})</p>
              {viewDoctorAppts.length === 0 ? <p className="text-xs text-muted-foreground">No appointments</p> :
                viewDoctorAppts.map(a => (
                  <div key={a._id} className="flex justify-between items-center bg-muted p-2 rounded mb-1 text-sm">
                    <span>{a.patient_id?.name} — {new Date(a.appointment_date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}</span>
                    <StatusBadge status={a.status} />
                  </div>
                ))}
            </div>
          </div>
        )}
      </Modal>

      <Modal open={!!viewPatientOpen} onClose={() => setViewPatientOpen(null)} title="Patient Details">
        {viewPatientOpen && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-muted-foreground text-xs mb-0.5">Name</p><p className="font-medium text-foreground">{viewPatientOpen.name}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Email</p><p className="font-medium text-foreground break-all">{viewPatientOpen.email}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Phone</p><p className="font-medium text-foreground">{viewPatientOpen.phone}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Status</p><StatusBadge status={viewPatientOpen.status} /></div>
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Appointments ({viewPatientAppts.length})</p>
              {viewPatientAppts.length === 0 ? <p className="text-xs text-muted-foreground">No appointments</p> :
                viewPatientAppts.map(a => (
                  <div key={a._id} className="flex justify-between items-center bg-muted p-2 rounded mb-1 text-sm">
                    <span>{a.doctor_id?.name} — {new Date(a.appointment_date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}</span>
                    <StatusBadge status={a.status} />
                  </div>
                ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AdminDashboard;
