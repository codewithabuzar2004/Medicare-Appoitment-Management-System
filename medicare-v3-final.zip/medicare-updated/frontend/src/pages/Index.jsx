import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import Footer from '../components/Footer';
import { FeaturesSection, StatsSection, HowItWorksSection, CTASection } from '../components/Sections';

const Index = () => {
  const { user } = useAuth();
  const navigate  = useNavigate();

  useEffect(() => {
    if (user) {
      if      (user.role === 'patient') navigate('/patient/dashboard', { replace: true });
      else if (user.role === 'doctor')  navigate('/doctor/dashboard',  { replace: true });
      else if (user.role === 'admin')   navigate('/admin/dashboard',   { replace: true });
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <StatsSection />
      <HowItWorksSection />
      <CTASection />
      <Footer />
    </div>
  );
};

export default Index;
