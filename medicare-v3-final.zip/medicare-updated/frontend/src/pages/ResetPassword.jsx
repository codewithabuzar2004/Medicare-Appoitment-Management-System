import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Lock, Eye, EyeOff, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { useToast } from '../hooks/use-toast';
import api from '../lib/api';

const ResetPassword = () => {
  const { token }   = useParams();
  const navigate    = useNavigate();
  const { toast }   = useToast();

  // Token verification state
  const [tokenStatus, setTokenStatus] = useState('verifying'); // 'verifying' | 'valid' | 'invalid'
  const [userName, setUserName]       = useState('');

  // Form state
  const [newPassword, setNewPassword]         = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass]               = useState(false);
  const [showConfirm, setShowConfirm]         = useState(false);
  const [errors, setErrors]                   = useState({});
  const [loading, setLoading]                 = useState(false);
  const [success, setSuccess]                 = useState(false);

  // Verify token as soon as page loads
  useEffect(() => {
    if (!token) { setTokenStatus('invalid'); return; }
    api.get(`/auth/reset-password/${token}/verify`)
      .then(({ data }) => {
        setTokenStatus('valid');
        setUserName(data.name || '');
      })
      .catch(() => setTokenStatus('invalid'));
  }, [token]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!newPassword || newPassword.length < 6)
      errs.newPassword = 'Password must be at least 6 characters';
    if (!confirmPassword)
      errs.confirmPassword = 'Please confirm your password';
    else if (newPassword !== confirmPassword)
      errs.confirmPassword = 'Passwords do not match';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setLoading(true);
    try {
      await api.post(`/auth/reset-password/${token}`, { newPassword, confirmPassword });
      setSuccess(true);
      toast({ title: '✅ Password Reset Successful!', description: 'You can now login with your new password.' });
    } catch (err) {
      const msg = err.response?.data?.message || 'Reset failed. The link may have expired.';
      toast({ title: 'Reset Failed', description: msg, variant: 'destructive' });
      if (msg.toLowerCase().includes('expired') || msg.toLowerCase().includes('invalid')) {
        setTokenStatus('invalid');
      }
    } finally { setLoading(false); }
  };

  const ic = (err) =>
    `w-full h-11 pl-10 pr-10 rounded-lg border bg-background text-foreground text-sm ` +
    `placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring ` +
    `transition-colors ${err ? 'border-destructive' : 'border-input'}`;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 to-background">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md">

        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-4">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-2xl font-heading font-bold text-foreground">MediCare</span>
          </Link>
        </div>

        <div className="glass rounded-2xl p-8 border-t-[3px] border-primary shadow-lg">

          {/* ── VERIFYING ────────────────────────────────────── */}
          {tokenStatus === 'verifying' && (
            <div className="text-center py-8 space-y-4">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground font-medium">Verifying reset link…</p>
            </div>
          )}

          {/* ── INVALID / EXPIRED ────────────────────────────── */}
          {tokenStatus === 'invalid' && (
            <div className="text-center space-y-5">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
                <XCircle className="h-8 w-8 text-destructive" />
              </div>
              <div>
                <h2 className="text-xl font-heading font-bold text-foreground">Link Expired or Invalid</h2>
                <p className="text-sm text-muted-foreground mt-2">
                  This password reset link has expired or is no longer valid.
                  Reset links expire after 15 minutes for security.
                </p>
              </div>
              <Link to="/login"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                Request New Reset Link
              </Link>
            </div>
          )}

          {/* ── SUCCESS ──────────────────────────────────────── */}
          {success && (
            <div className="text-center space-y-5">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h2 className="text-xl font-heading font-bold text-foreground">Password Reset!</h2>
                <p className="text-sm text-muted-foreground mt-2">
                  Your password has been updated successfully.
                  You can now login with your new password.
                </p>
              </div>
              <Link to="/login"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                Go to Login →
              </Link>
            </div>
          )}

          {/* ── RESET FORM ───────────────────────────────────── */}
          {tokenStatus === 'valid' && !success && (
            <form onSubmit={handleSubmit} className="space-y-5" noValidate>
              <div className="text-center mb-6">
                <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Lock className="h-7 w-7 text-primary" />
                </div>
                <h2 className="text-xl font-heading font-bold text-foreground">
                  Set New Password
                  {userName && <span className="text-muted-foreground font-normal text-base">, {userName}</span>}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">Enter your new password below</p>
              </div>

              {/* New Password */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">New Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type={showPass ? 'text' : 'password'}
                    placeholder="Minimum 6 characters"
                    value={newPassword}
                    onChange={e => { setNewPassword(e.target.value); setErrors(p => ({ ...p, newPassword: '' })); }}
                    className={ic(errors.newPassword)} />
                  <button type="button" onClick={() => setShowPass(p => !p)}
                    className="absolute right-3 top-3.5 text-muted-foreground hover:text-foreground">
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.newPassword && <p className="text-sm text-destructive">{errors.newPassword}</p>}
              </div>

              {/* Confirm Password */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
                  <input
                    type={showConfirm ? 'text' : 'password'}
                    placeholder="Repeat your new password"
                    value={confirmPassword}
                    onChange={e => { setConfirmPassword(e.target.value); setErrors(p => ({ ...p, confirmPassword: '' })); }}
                    className={ic(errors.confirmPassword)} />
                  <button type="button" onClick={() => setShowConfirm(p => !p)}
                    className="absolute right-3 top-3.5 text-muted-foreground hover:text-foreground">
                    {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
              </div>

              {/* Password strength hint */}
              {newPassword.length > 0 && (
                <div className="flex gap-1">
                  {[1,2,3,4].map(i => (
                    <div key={i} className={`h-1 flex-1 rounded-full transition-colors ${
                      newPassword.length >= i * 3
                        ? newPassword.length >= 10 ? 'bg-green-500'
                          : newPassword.length >= 7 ? 'bg-yellow-400'
                          : 'bg-red-400'
                        : 'bg-muted'
                    }`} />
                  ))}
                  <span className="text-xs text-muted-foreground ml-2">
                    {newPassword.length < 6 ? 'Too short' : newPassword.length < 8 ? 'Weak' : newPassword.length < 10 ? 'Good' : 'Strong'}
                  </span>
                </div>
              )}

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-opacity disabled:opacity-60">
                {loading
                  ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Resetting…</>
                  : <><RefreshCw className="h-4 w-4" /><span>Reset Password</span></>}
              </button>

              <p className="text-center text-xs text-muted-foreground">
                Remember your password?{' '}
                <Link to="/login" className="text-primary hover:underline font-medium">Back to Login</Link>
              </p>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default ResetPassword;
