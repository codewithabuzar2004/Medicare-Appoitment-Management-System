import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import api from '../lib/api';
import { Search, Stethoscope, IndianRupee, Mail, Clock, Eye, X } from 'lucide-react';
const SPECIALIZATIONS = ['Cardiologist','Dermatologist','Orthopedic','Pediatrician','Neurologist','ENT Specialist','Gynecologist','General Physician','Psychiatrist','Dentist'];

const Doctors = () => {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const bookHref  = user?.role === 'patient' ? '/patient/dashboard' : '/register';
  const handleBook = (e) => {
    if (user?.role === 'patient') { e.preventDefault(); navigate('/patient/dashboard'); }
  };
  const [doctors, setDoctors] = useState([]);
  const [search, setSearch] = useState('');
  const [specFilter, setSpecFilter] = useState('all');
  const [viewDoc, setViewDoc] = useState(null);
  const [slots, setSlots] = useState([]);

  useEffect(() => {
    api.get('/doctors').then(r => setDoctors(r.data.doctors || r.data)).catch(() => {});
  }, []);

  const filtered = useMemo(() => doctors.filter(d => {
    const matchSearch = (d.name||'').toLowerCase().includes(search.toLowerCase()) || (d.specialization||'').toLowerCase().includes(search.toLowerCase());
    const matchSpec = specFilter === 'all' || d.specialization === specFilter;
    return matchSearch && matchSpec;
  }), [doctors, search, specFilter]);

  const openDoc = async (doc) => {
    setViewDoc(doc);
    const r = await api.get(`/doctors/${doc._id}/availability`);
    setSlots(r.data.slots || r.data);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-4xl font-heading font-bold text-foreground">Our <span className="text-gradient">Doctors</span></h1>
            <p className="text-muted-foreground mt-3 max-w-xl mx-auto">Find and book appointments with our verified healthcare professionals.</p>
          </motion.div>

          <div className="flex flex-col sm:flex-row gap-3 mb-8 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <input placeholder="Search by name or specialization..." value={search} onChange={e => setSearch(e.target.value)} className="w-full h-10 pl-10 pr-3 rounded-lg border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <select value={specFilter} onChange={e => setSpecFilter(e.target.value)} className="h-10 px-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring w-full sm:w-52">
              <option value="all">All Specializations</option>
              {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {filtered.length === 0 ? (
            <p className="text-center text-muted-foreground py-12">No doctors found.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((doc, i) => (
                <motion.div key={doc._id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <div className="bg-card rounded-xl border border-border p-6 flex flex-col h-full hover-lift">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                      <Stethoscope className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="text-lg font-bold text-foreground">{doc.name}</h3>
                    <span className="inline-block px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium w-fit mt-1">{doc.specialization}</span>
                    <div className="flex items-center gap-1 mt-3 text-sm text-muted-foreground"><IndianRupee className="h-3 w-3" /> ₹{doc.consultation_fee} consultation</div>
                    <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground"><Mail className="h-3 w-3" /> {doc.email}</div>
                    <div className="mt-auto pt-4 flex gap-2">
                      <button onClick={() => openDoc(doc)} className="flex-1 flex items-center justify-center gap-1 h-9 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted transition-colors">
                        <Eye className="h-4 w-4" /> View
                      </button>
                      <Link to={bookHref} onClick={handleBook} className="flex-1 flex items-center justify-center h-9 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">Book Now</Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      <AnimatePresence>
        {viewDoc && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setViewDoc(null)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-card rounded-2xl border border-border p-6 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-heading font-bold text-foreground">Doctor Details</h2>
                <button onClick={() => setViewDoc(null)} className="text-muted-foreground hover:text-foreground"><X className="h-5 w-5" /></button>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground">Name:</span><p className="font-medium text-foreground">{viewDoc.name}</p></div>
                <div><span className="text-muted-foreground">Specialization:</span><p className="font-medium text-foreground">{viewDoc.specialization}</p></div>
                <div><span className="text-muted-foreground">Fee:</span><p className="font-medium text-foreground">₹{viewDoc.consultation_fee}</p></div>
                <div><span className="text-muted-foreground">Email:</span><p className="font-medium text-foreground">{viewDoc.email}</p></div>
              </div>
              <div className="mt-4">
                <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-1"><Clock className="h-4 w-4 text-primary" /> Available Slots</p>
                {slots.length === 0 ? <p className="text-xs text-muted-foreground">No availability set yet</p> :
                  slots.map(s => <div key={s._id} className="bg-muted p-2 rounded mb-1 text-sm text-foreground">{s.day}: {s.start_time} - {s.end_time}</div>)
                }
              </div>
              <Link to={bookHref} onClick={handleBook} className="mt-4 w-full flex items-center justify-center h-10 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity">Book Appointment</Link>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  );
};

export default Doctors;
