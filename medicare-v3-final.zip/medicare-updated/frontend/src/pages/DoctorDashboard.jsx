import { useState, useEffect, useMemo, useCallback } from 'react';
import useRealtimeRefresh from '../hooks/useRealtimeRefresh';
import { useSocket } from '../contexts/SocketContext';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import api from '../lib/api';
import {
  Heart, LogOut, User, Calendar, Clock, CheckCircle, XCircle, Plus, Trash2,
  Search, Eye, X, Stethoscope, Mail, Lock, IndianRupee, Edit, Save,
  UserCircle, Phone, ChevronDown, Award, FileText, Star
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../hooks/use-toast';

// ─── IST helpers ──────────────────────────────────────────────────────────────
const IST = { timeZone: 'Asia/Kolkata' };
const fmtDate = (iso) => new Date(iso).toLocaleDateString('en-IN', { ...IST, day: '2-digit', month: 'short', year: 'numeric' });
const fmtTime = (iso) => new Date(iso).toLocaleTimeString('en-IN', { ...IST, hour: '2-digit', minute: '2-digit', hour12: true });
const fmtSlotTime = (t) => {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${ampm}`;
};

// convert display hour (clockwise 9–7) → 24h string "HH"
const clockHourTo24 = (h) => {
  const n = parseInt(h);
  if (n === 12) return 12;
  if (n >= 1 && n <= 7) return n + 12;
  return n; // 9,10,11
};

// convert 24h "HH" → clockwise display hour string
const h24ToClockHour = (hh24) => {
  if (!hh24) return '9';
  const h = parseInt(hh24);
  const h12 = h % 12 || 12;
  return String(h12);
};

// ─── Reusable Clock Time Picker for slot management ──────────────────────────
const SlotTimePicker = ({ label, value, onChange }) => {
  const initH  = value ? h24ToClockHour(value.slice(0, 2)) : '9';
  const initM  = value ? value.slice(3, 5) : '00';
  const [h12,  setH12]  = useState(initH);
  const [min,  setMin]  = useState(initM);
  const [hOpen, setHOpen] = useState(false);
  const [mOpen, setMOpen] = useState(false);

  // Clockwise: 9 AM → 7 PM
  const hours = ['9','10','11','12','1','2','3','4','5','6','7'];
  const mins  = ['00', '15', '30', '45'];

  const hourLabel = (h) => {
    const n = parseInt(h);
    if (n === 9 || n === 10 || n === 11) return `${h} AM`;
    if (n === 12) return `12 PM`;
    return `${h} PM`;
  };

  const emit = (nh, nm) => {
    const hh24 = clockHourTo24(nh);
    onChange(`${String(hh24).padStart(2,'0')}:${nm}`);
  };

  const Sel = ({ open, setOpen, val, opts, onPick, label: lbl, width = 'w-20' }) => (
    <div className="relative">
      <button type="button" onClick={() => setOpen(o => !o)}
        className={`${width} flex items-center justify-between px-2.5 py-2 rounded-xl border text-sm font-semibold transition-all
          ${open ? 'border-primary bg-primary/8 shadow-sm' : 'border-border bg-background hover:border-primary/40'}`}>
        <span className="text-foreground">{lbl ? lbl(val) : val}</span>
        <ChevronDown className={`h-3.5 w-3.5 text-muted-foreground transition-transform duration-150 ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.12 }}
            className={`absolute top-full mt-1 left-0 z-[60] ${width} bg-card border border-border rounded-xl shadow-2xl overflow-hidden`}>
            <div className="max-h-48 overflow-y-auto py-1">
              {opts.map(o => (
                <button key={o} type="button" onClick={() => { onPick(o); setOpen(false); }}
                  className={`w-full text-left px-3 py-1.5 text-sm transition-colors
                    ${o === val ? 'bg-primary text-primary-foreground font-bold' : 'hover:bg-muted text-foreground'}`}>
                  {lbl ? lbl(o) : o}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  return (
    <div>
      <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">{label}</label>
      <div className="flex items-center gap-1.5 p-2 rounded-xl border border-border bg-background hover:border-primary/40 transition-colors">
        <Clock className="h-4 w-4 text-primary flex-shrink-0 ml-0.5" />
        <Sel open={hOpen} setOpen={setHOpen} val={h12} opts={hours} label={hourLabel}
          onPick={v => { setH12(v); emit(v, min); }} width="w-24" />
        <span className="text-muted-foreground font-bold text-sm">:</span>
        <Sel open={mOpen} setOpen={setMOpen} val={min} opts={mins}
          onPick={v => { setMin(v); emit(h12, v); }} width="w-16" />
      </div>
      {value && (
        <p className="text-[11px] text-primary font-medium mt-1 ml-1">
          ✓ {fmtSlotTime(value)} IST
        </p>
      )}
    </div>
  );
};

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// ─── Modal ────────────────────────────────────────────────────────────────────
const Modal = ({ open, onClose, title, children }) => (
  <AnimatePresence>
    {open && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
          onClick={e => e.stopPropagation()}
          className="bg-card rounded-2xl border border-border p-6 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-heading font-bold text-foreground">{title}</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

const StatusBadge = ({ status }) => {
  const map = {
    confirmed: 'bg-green-100 text-green-700',
    completed: 'bg-teal-100 text-teal-700',
    pending:   'bg-yellow-100 text-yellow-700',
    cancelled: 'bg-red-100 text-red-700',
    active:    'bg-green-100 text-green-700',
    blocked:   'bg-red-100 text-red-700',
    rejected:  'bg-red-100 text-red-700',
  };
  const cls = map[status?.toLowerCase()] || 'bg-gray-100 text-gray-600';
  return <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${cls}`}>{status}</span>;
};

const SlotPill = ({ slot, onRemove }) => (
  <div className="flex items-center justify-between bg-muted rounded-xl px-4 py-3 border border-border">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
        <Clock className="h-4 w-4 text-primary" />
      </div>
      <div>
        <p className="text-sm font-semibold text-foreground">{slot.day}</p>
        <p className="text-xs text-muted-foreground">{fmtSlotTime(slot.start_time)} – {fmtSlotTime(slot.end_time)} IST</p>
      </div>
    </div>
    {onRemove && (
      <button onClick={onRemove} className="p-1.5 rounded-lg text-destructive hover:bg-destructive/10 transition-colors">
        <Trash2 className="h-4 w-4" />
      </button>
    )}
  </div>
);

// ─── Doctor Profile Edit Form (outside to prevent remount) ────────────────────
const SPECIALIZATIONS = [
  'Cardiologist', 'Dermatologist', 'Orthopedic', 'Pediatrician',
  'Neurologist', 'ENT Specialist', 'Gynecologist', 'General Physician',
  'Psychiatrist', 'Dentist'
];

const DoctorProfileForm = ({ form, setForm, errors, setErrors, saving, onSubmit }) => {
  const ic = (field) =>
    `w-full h-11 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors[field] ? 'border-destructive' : 'border-input'}`;

  const onChange = useCallback((field, val) => {
    setForm(p => ({ ...p, [field]: val }));
    setErrors(p => ({ ...p, [field]: '' }));
  }, [setForm, setErrors]);

  return (
    <div className="space-y-4">
      {/* Doctor Name */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Doctor Name</label>
        <div className="relative">
          <Stethoscope className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="text" placeholder="Dr. John Smith" autoComplete="off"
            value={form.name ?? ''} onChange={e => onChange('name', e.target.value)}
            className={ic('name')} />
        </div>
        {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
      </div>

      {/* Specialization */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Specialization</label>
        <select value={form.specialization ?? ''} onChange={e => onChange('specialization', e.target.value)}
          className={`w-full h-11 px-3 rounded-lg border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors.specialization ? 'border-destructive' : 'border-input'}`}>
          <option value="">Select specialization</option>
          {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        {errors.specialization && <p className="text-xs text-destructive mt-1">{errors.specialization}</p>}
      </div>

      {/* Consultation Fee */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Consultation Fee (₹)</label>
        <div className="relative">
          <IndianRupee className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="number" placeholder="500" min="1" step="1"
            value={form.consultation_fee ?? ''} onChange={e => onChange('consultation_fee', e.target.value)}
            className={ic('consultation_fee')} />
        </div>
        {errors.consultation_fee && <p className="text-xs text-destructive mt-1">{errors.consultation_fee}</p>}
      </div>

      {/* Experience Years */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Experience (Years)</label>
        <div className="relative">
          <Award className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="number" placeholder="5" min="0" max="60"
            value={form.experience_years ?? ''} onChange={e => onChange('experience_years', e.target.value)}
            className={ic('experience_years')} />
        </div>
      </div>

      {/* About */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">About <span className="text-muted-foreground font-normal text-xs">(shown to patients)</span></label>
        <div className="relative">
          <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
          <textarea placeholder="Brief description of your expertise..." rows={3}
            value={form.about ?? ''} onChange={e => onChange('about', e.target.value)}
            className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors resize-none" />
        </div>
      </div>

      {/* Email */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Email</label>
        <div className="relative">
          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="email" placeholder="doctor@email.com" autoComplete="off"
            value={form.email ?? ''} onChange={e => onChange('email', e.target.value)}
            className={ic('email')} />
        </div>
        {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
      </div>

      {/* Password section */}
      <div className="border-t border-border pt-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Change Password (optional)</p>
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <input type="password" placeholder="Leave blank to keep current" autoComplete="new-password"
                value={form.password ?? ''} onChange={e => onChange('password', e.target.value)}
                className={ic('password')} />
            </div>
            {errors.password && <p className="text-xs text-destructive mt-1">{errors.password}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Confirm New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <input type="password" placeholder="Repeat new password" autoComplete="new-password"
                value={form.confirm_password ?? ''} onChange={e => onChange('confirm_password', e.target.value)}
                className={ic('confirm_password')} />
            </div>
            {errors.confirm_password && <p className="text-xs text-destructive mt-1">{errors.confirm_password}</p>}
          </div>
        </div>
      </div>

      <button onClick={onSubmit} disabled={saving}
        className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-60">
        {saving
          ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Saving…</>
          : <><Save className="h-4 w-4" /> Save Changes</>}
      </button>
    </div>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────
const DoctorDashboard = () => {
  const { user, logout, refreshUser } = useAuth();
  const { connected }    = useSocket();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [appointments, setAppointments] = useState([]);
  const [availability, setAvailability] = useState([]);
  // Pre-populate from sessionStorage user so profile shows instantly
  const [doctorProfile, setDoctorProfile] = useState(user || null);
  const [activeTab, setActiveTab] = useState('appointments');
  const [initialLoading, setInitialLoading] = useState(true);
  const [newDay, setNewDay] = useState('Monday');
  const [newStart, setNewStart] = useState('');
  const [newEnd, setNewEnd] = useState('');
  const [slotKey, setSlotKey] = useState(0); // increment to reset SlotTimePicker
  const [apptSearch, setApptSearch] = useState('');
  const [apptStatusFilter, setApptStatusFilter] = useState('all');
  const [viewPatientOpen, setViewPatientOpen] = useState(null);

  // Profile edit
  const [profileEditOpen, setProfileEditOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({});
  const [profileErrors, setProfileErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [apptRes, availRes, profileRes] = await Promise.allSettled([
        api.get('/doctor/appointments'),
        api.get('/doctor/availability'),
        api.get('/doctor/profile'),
      ]);
      if (apptRes.status === 'fulfilled') {
        const d = apptRes.value.data;
        setAppointments(Array.isArray(d) ? d : (d.appointments || []));
      }
      if (availRes.status === 'fulfilled') {
        const d = availRes.value.data;
        setAvailability(Array.isArray(d) ? d : (d.slots || []));
      }
      if (profileRes.status === 'fulfilled') {
        const d = profileRes.value.data;
        setDoctorProfile(d.doctor || d);
      }
    } catch (err) {
      console.error('DoctorDashboard loadData error:', err?.message);
    } finally {
      setInitialLoading(false);
    }
  }, []);

  // Real-time: refreshes instantly when server emits 'refresh' via Socket.io
  useRealtimeRefresh(loadData);

  const filteredAppointments = useMemo(() => appointments.filter(a => {
    const matchSearch = !apptSearch || (a.patient_id?.name || '').toLowerCase().includes(apptSearch.toLowerCase());
    return matchSearch && (apptStatusFilter === 'all' || a.status === apptStatusFilter);
  }), [appointments, apptSearch, apptStatusFilter]);

  const handleStatus = async (id, status) => {
    try {
      await api.put(`/doctor/appointments/${id}/status`, { status });
      toast({ title: `Appointment ${status}` });
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to update status', variant: 'destructive' });
    }
  };

  const addAvailability = async () => {
    if (!newStart || !newEnd) { toast({ title: 'Error', description: 'Fill start and end time', variant: 'destructive' }); return; }
    if (newStart >= newEnd) { toast({ title: 'Error', description: 'End time must be after start time', variant: 'destructive' }); return; }
    try {
      await api.post('/doctor/availability', { day: newDay, start_time: newStart, end_time: newEnd });
      toast({ title: 'Slot added!' }); setNewStart(''); setNewEnd(''); setSlotKey(k => k + 1); loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to add slot', variant: 'destructive' });
    }
  };

  const removeSlot = async (id) => {
    try { await api.delete(`/doctor/availability/${id}`); toast({ title: 'Slot removed' }); loadData(); }
    catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to remove slot', variant: 'destructive' });
    }
  };

  // Profile edit handlers
  const openProfileEdit = () => {
    setProfileForm({
      name:             doctorProfile?.name || '',
      specialization:   doctorProfile?.specialization || '',
      consultation_fee: doctorProfile?.consultation_fee ? String(doctorProfile.consultation_fee) : '',
      experience_years: doctorProfile?.experience_years ? String(doctorProfile.experience_years) : '',
      about:            doctorProfile?.about || '',
      email:            doctorProfile?.email || '',
      password:         '',
      confirm_password: '',
    });
    setProfileErrors({});
    setProfileEditOpen(true);
  };

  const validateProfile = () => {
    const e = {};
    if (!profileForm.name?.trim() || profileForm.name.trim().length < 2) e.name = 'Name required (min 2 chars)';
    if (!profileForm.specialization) e.specialization = 'Specialization required';
    if (!profileForm.consultation_fee || Number(profileForm.consultation_fee) <= 0) e.consultation_fee = 'Valid fee required';
    if (!profileForm.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileForm.email)) e.email = 'Valid email required';
    if (profileForm.password && profileForm.password.length < 6) e.password = 'Password must be at least 6 characters';
    if (profileForm.password && profileForm.password !== profileForm.confirm_password) e.confirm_password = 'Passwords do not match';
    setProfileErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSaveProfile = async () => {
    if (!validateProfile()) return;
    setSaving(true);
    try {
      const payload = {
        name:             profileForm.name?.trim(),
        specialization:   profileForm.specialization,
        consultation_fee: Number(profileForm.consultation_fee),
        experience_years: Number(profileForm.experience_years) || 0,
        about:            profileForm.about?.trim() || '',
        email:            profileForm.email?.trim(),
      };
      if (profileForm.password) payload.password = profileForm.password;
      const res = await api.put('/doctor/profile', payload);
      const updated = res.data.doctor || res.data;
      setDoctorProfile(updated);
      await refreshUser(); // update sessionStorage user
      toast({ title: 'Profile Updated!', description: 'Your profile has been saved.' });
      setProfileEditOpen(false);
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to save', variant: 'destructive' });
    } finally { setSaving(false); }
  };

  const todayIST = new Date().toLocaleDateString('en-IN', IST);
  const todayAppointments = appointments.filter(a =>
    new Date(a.appointment_date).toLocaleDateString('en-IN', IST) === todayIST
  );

  const tabs = [
    { id: 'appointments', label: 'Appointments' },
    { id: 'availability',  label: 'Availability' },
    { id: 'patients',      label: 'My Patients' },
    { id: 'profile',       label: 'My Profile' },
  ];

  return (
    <div className="min-h-screen bg-background" data-theme="doctor">
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-primary" />
          <span className="font-heading font-bold text-lg text-foreground">MediCare</span>
          <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 text-xs font-semibold">Doctor</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <UserCircle className="h-5 w-5" />
            <span className="hidden sm:inline">{doctorProfile?.name || user?.name}</span>
          </button>
          <button onClick={() => { logout(); navigate('/'); }} className="p-2 text-muted-foreground hover:text-foreground">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto p-6 space-y-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-3xl font-heading font-bold text-foreground">Doctor Dashboard 🩺</h1>
            {/* Live indicator */}
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold
              ${connected ? 'bg-green-100 border-green-200 text-green-700' : 'bg-gray-100 border-gray-200 text-gray-500'}`}>
              <span className="relative flex h-2 w-2">
                {connected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>}
                <span className={`relative inline-flex rounded-full h-2 w-2 ${connected ? 'bg-green-500' : 'bg-gray-400'}`}></span>
              </span>
              {connected ? 'Live — Real-time' : 'Connecting...'}
            </span>
          </div>
          <p className="text-muted-foreground mt-1">Manage your appointments, availability and profile</p>
        </motion.div>

        {/* Initial loading overlay */}
        {initialLoading && (
          <div className="flex items-center justify-center py-16">
            <div className="text-center space-y-3">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground text-sm">Loading your dashboard…</p>
            </div>
          </div>
        )}

        {/* Stats */}
        {!initialLoading && <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { label: 'Total',    value: appointments.length,                                  icon: Calendar,    color: 'bg-blue-50 text-blue-600' },
            { label: 'Today',    value: todayAppointments.length,                             icon: Clock,       color: 'bg-purple-50 text-purple-600' },
            { label: 'pending',  value: appointments.filter(a=>a.status==='pending').length,  icon: Clock,       color: 'bg-yellow-50 text-yellow-600' },
            { label: 'confirmed', value: appointments.filter(a=>a.status==='confirmed').length, icon: CheckCircle, color: 'bg-green-50 text-green-600' },
            { label: 'cancelled', value: appointments.filter(a=>a.status==='cancelled').length, icon: XCircle,     color: 'bg-red-50 text-red-600' },
          ].map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                <div className={`p-2 rounded-lg ${s.color}`}><s.icon className="h-4 w-4" /></div>
                <div><p className="text-xl font-bold text-foreground">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
              </div>
            </motion.div>
          ))}
        </div>}

        {/* Tabs */}
        {!initialLoading && <div className="flex gap-1 bg-muted p-1 rounded-lg w-fit flex-wrap">
          {tabs.map(t => {
            const pendingCount = t.id === 'appointments'
              ? appointments.filter(a => a.status === 'pending').length
              : 0;
            return (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`relative px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === t.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                {t.label}
                {pendingCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] flex items-center justify-center rounded-full bg-yellow-500 text-white text-[10px] font-bold px-1 animate-pulse">
                    {pendingCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>}

        {!initialLoading && activeTab === 'appointments' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input placeholder="Search patient..." value={apptSearch} onChange={e => setApptSearch(e.target.value)}
                  className="w-full h-10 pl-10 pr-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <select value={apptStatusFilter} onChange={e => setApptStatusFilter(e.target.value)}
                className="h-10 px-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring w-40">
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            {filteredAppointments.length === 0
              ? <p className="text-muted-foreground text-center py-8">No appointments found.</p>
              : filteredAppointments.map((appt, i) => {
                  const patient = appt.patient_id;
                  // Show "NEW" badge if booked within last 10 minutes and still Pending
                  const isNew = appt.status === 'pending' &&
                    (new Date() - new Date(appt.createdAt)) < 10 * 60 * 1000;
                  return (
                    <motion.div key={appt._id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}>
                      <div className={`bg-card rounded-xl border p-4 flex items-center justify-between flex-wrap gap-3 transition-all
                        ${isNew ? 'border-yellow-300 shadow-md shadow-yellow-50' : 'border-border'}`}>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                            <User className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-foreground">{patient?.name || 'Unknown Patient'}</p>
                              {isNew && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-100 border border-yellow-300 text-[10px] font-bold text-yellow-700 uppercase tracking-wide animate-pulse">
                                  🆕 New
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {patient?.email || '—'}
                              {patient?.phone && (
                                <> • <a href={`tel:${patient.phone}`} className="text-primary hover:underline">{patient.phone}</a></>
                              )}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="inline-flex items-center gap-1 text-xs bg-primary/5 text-primary px-2 py-0.5 rounded-full font-medium">
                                <Calendar className="h-3 w-3" /> {fmtDate(appt.appointment_date)}
                              </span>
                              <span className="inline-flex items-center gap-1 text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                                <Clock className="h-3 w-3" /> {fmtTime(appt.appointment_date)} IST
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusBadge status={appt.status} />
                          {patient && (
                            <button onClick={() => setViewPatientOpen(patient)} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors">
                              <Eye className="h-4 w-4" />
                            </button>
                          )}
                          {/* Pending: show Approve + Reject */}
                          {appt.status === 'pending' && (
                            <>
                              <button onClick={() => handleStatus(appt._id, 'confirmed')} title="Approve" className="p-2 rounded-lg border border-border hover:bg-green-50 transition-colors"><CheckCircle className="h-4 w-4 text-green-600" /></button>
                              <button onClick={() => handleStatus(appt._id, 'cancelled')} title="Reject" className="p-2 rounded-lg border border-border hover:bg-red-50 transition-colors"><XCircle className="h-4 w-4 text-red-600" /></button>
                            </>
                          )}
                          {/* Confirmed: Mark Complete or Cancel */}
                          {appt.status === 'confirmed' && (
                            <>
                              <button onClick={() => handleStatus(appt._id, 'completed')} title="Mark as Completed"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-green-200 bg-green-50 text-xs text-green-700 hover:bg-green-100 transition-colors">
                                <Award className="h-3.5 w-3.5" /> Complete
                              </button>
                              <button onClick={() => handleStatus(appt._id, 'cancelled')} title="Cancel Appointment"
                                className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-border text-xs text-destructive hover:bg-red-50 transition-colors">
                                <XCircle className="h-3.5 w-3.5" /> Cancel
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })
            }
          </div>
        )}

        {!initialLoading && activeTab === 'availability' && (
          <div className="bg-card rounded-xl border border-border p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-heading font-bold text-foreground flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" /> Manage Availability
              </h3>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-lg">All times in IST</span>
            </div>
            <div className="bg-muted/50 rounded-xl p-4 border border-border space-y-3">
              <p className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Plus className="h-4 w-4 text-primary" /> Add New Slot
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Day */}
                <div>
                  <label className="text-xs font-semibold text-muted-foreground mb-1.5 block">Day</label>
                  <select value={newDay} onChange={e => setNewDay(e.target.value)}
                    className="w-full h-11 px-3 rounded-xl border border-border bg-background text-foreground text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all">
                    {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                {/* Start Time */}
                <SlotTimePicker key={`start-${slotKey}`} label="Start Time (IST)" value={newStart} onChange={setNewStart} />
                {/* End Time */}
                <SlotTimePicker key={`end-${slotKey}`} label="End Time (IST)" value={newEnd} onChange={setNewEnd} />
              </div>
              {/* Preview + Add button */}
              <div className="flex items-center justify-between gap-3">
                {newStart && newEnd ? (
                  <div className="flex-1 rounded-xl bg-primary/5 border border-primary/20 px-4 py-2.5">
                    <p className="text-xs text-muted-foreground">Preview</p>
                    <p className="text-sm font-bold text-foreground">
                      {newDay} · {fmtSlotTime(newStart)} → {fmtSlotTime(newEnd)} IST
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground flex-1">Select day and times above</p>
                )}
                <button onClick={addAvailability}
                  className="flex items-center gap-1.5 h-10 px-5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 active:scale-95 transition-all whitespace-nowrap">
                  <Plus className="h-4 w-4" /> Add Slot
                </button>
              </div>
            </div>
            <div className="space-y-2">
              {availability.length === 0
                ? <p className="text-sm text-muted-foreground text-center py-4">No slots added yet.</p>
                : availability.map(slot => <SlotPill key={slot._id} slot={slot} onRemove={() => removeSlot(slot._id)} />)
              }
            </div>
          </div>
        )}

        {!initialLoading && activeTab === 'patients' && (
          <div className="space-y-3">
            {(() => {
              const seen = new Set();
              const patients = appointments.map(a => a.patient_id).filter(p => p && !seen.has(p._id) && seen.add(p._id));
              return patients.length === 0
                ? <p className="text-muted-foreground text-center py-8">No patients yet.</p>
                : patients.map((p, i) => {
                    const patientAppts = appointments.filter(a => a.patient_id?._id === p._id);
                    const lastAppt = [...patientAppts].sort((a, b) => new Date(b.appointment_date) - new Date(a.appointment_date))[0];
                    return (
                      <motion.div key={p._id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}>
                        <div className="bg-card rounded-xl border border-border p-4 flex items-center justify-between flex-wrap gap-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                              <User className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-semibold text-foreground">{p.name}</p>
                              <p className="text-sm text-muted-foreground">
                              {p.email || '—'}
                              {p.phone && (
                                <> • <a href={`tel:${p.phone}`} className="text-primary hover:underline">{p.phone}</a></>
                              )}
                            </p>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <span className="text-xs text-muted-foreground">{patientAppts.length} appointment{patientAppts.length !== 1 ? 's' : ''} • {patientAppts.filter(a => a.status === 'confirmed').length} approved</span>
                                {lastAppt && (
                                  <span className="inline-flex items-center gap-1 text-xs bg-muted px-2 py-0.5 rounded-full text-muted-foreground">
                                    <Clock className="h-3 w-3" /> Last: {fmtDate(lastAppt.appointment_date)} IST
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <button onClick={() => setViewPatientOpen(p)}
                            className="flex items-center gap-1 px-3 py-2 rounded-lg border border-border text-sm hover:bg-muted transition-colors">
                            <Eye className="h-4 w-4" /> View
                          </button>
                        </div>
                      </motion.div>
                    );
                  });
            })()}
          </div>
        )}

        {!initialLoading && activeTab === 'profile' && !doctorProfile && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center space-y-3">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground text-sm">Loading profile…</p>
            </div>
          </div>
        )}
        {!initialLoading && activeTab === 'profile' && doctorProfile && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">

            {/* Profile card */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <Stethoscope className="h-9 w-9 text-purple-600" />
                  </div>
                  <div>
                    <h2 className="text-xl font-heading font-bold text-foreground">{doctorProfile.name}</h2>
                    <p className="text-sm text-muted-foreground">{doctorProfile.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <StatusBadge status={doctorProfile.status} />
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{doctorProfile.specialization}</span>
                    </div>
                  </div>
                </div>
                <button onClick={openProfileEdit}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                  <Edit className="h-4 w-4" /> Edit Profile
                </button>
                  <a href="/login" onClick={(e) => { e.preventDefault(); logout(); navigate('/login?role=doctor'); }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors ml-2">
                    <Lock className="h-4 w-4" /> Forgot Password
                  </a>
              </div>

              {/* Info grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: Stethoscope,   label: 'Specialization', value: doctorProfile.specialization,   color: 'bg-purple-50 text-purple-600' },
                  { icon: IndianRupee,   label: 'Consultation Fee', value: `₹${doctorProfile.consultation_fee}`, color: 'bg-green-50 text-green-600' },
                  { icon: Mail,          label: 'Email',           value: doctorProfile.email,            color: 'bg-purple-50 text-purple-600' },
                  { icon: Calendar,      label: 'Member Since',    value: new Date(doctorProfile.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }), color: 'bg-blue-50 text-blue-600' },
                ].map((item, i) => (
                  <div key={i} className="bg-muted/50 rounded-xl p-4 flex items-center gap-3 border border-border">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${item.color}`}>
                      <item.icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground">{item.label}</p>
                      <p className="text-sm font-semibold text-foreground truncate">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Appointment summary */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h3 className="font-heading font-bold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" /> Appointment Summary
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                {[
                  { label: 'Total',    value: appointments.length,                                  color: 'bg-blue-50 text-blue-600' },
                  { label: 'Today',    value: todayAppointments.length,                             color: 'bg-purple-50 text-purple-600' },
                  { label: 'confirmed', value: appointments.filter(a=>a.status==='confirmed').length, color: 'bg-green-50 text-green-600' },
                  { label: 'pending',  value: appointments.filter(a=>a.status==='pending').length,  color: 'bg-yellow-50 text-yellow-600' },
                ].map((s, i) => (
                  <div key={i} className={`rounded-xl p-4 text-center ${s.color}`}>
                    <p className="text-2xl font-bold">{s.value}</p>
                    <p className="text-xs font-medium mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>
              {availability.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-foreground mb-2">My Availability Slots</p>
                  <div className="space-y-2">{availability.map(s => <SlotPill key={s._id} slot={s} />)}</div>
                </div>
              )}
            </div>

          </motion.div>
        )}
      </div>

      {/* ── EDIT PROFILE MODAL ── */}
      <Modal open={profileEditOpen} onClose={() => setProfileEditOpen(false)} title="Edit Profile & Security">
        <DoctorProfileForm
          form={profileForm}
          setForm={setProfileForm}
          errors={profileErrors}
          setErrors={setProfileErrors}
          saving={saving}
          onSubmit={handleSaveProfile}
        />
      </Modal>

      {/* ── PATIENT DETAIL MODAL ── */}
      <Modal open={!!viewPatientOpen} onClose={() => setViewPatientOpen(null)} title="Patient Details">
        {viewPatientOpen && (
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-muted-foreground text-xs mb-0.5">Name</p><p className="font-medium text-foreground">{viewPatientOpen.name}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Email</p><p className="font-medium text-foreground break-all">{viewPatientOpen.email}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Phone</p><p className="font-medium text-foreground">{viewPatientOpen.phone}</p></div>
              <div><p className="text-muted-foreground text-xs mb-0.5">Status</p><StatusBadge status={viewPatientOpen.status} /></div>
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">Appointment History</p>
              {appointments.filter(a => a.patient_id?._id === viewPatientOpen._id).map(a => (
                <div key={a._id} className="flex justify-between items-center bg-muted p-3 rounded-lg mb-2">
                  <div>
                    <p className="text-sm font-medium text-foreground">{fmtDate(a.appointment_date)}</p>
                    <p className="text-xs text-muted-foreground">{fmtTime(a.appointment_date)} IST</p>
                  </div>
                  <StatusBadge status={a.status} />
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default DoctorDashboard;
