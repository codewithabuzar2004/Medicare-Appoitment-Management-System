import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { Heart, Mail, Lock, User, Phone, ArrowRight, Stethoscope, ShieldCheck, IndianRupee, Award, FileText } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

const SPECIALIZATIONS = ['Cardiologist','Dermatologist','Orthopedic','Pediatrician','Neurologist','ENT Specialist','Gynecologist','General Physician','Psychiatrist','Dentist'];

const roleConfig = {
  patient: { label:'Patient', icon:User,         gradient:'from-[hsl(174,62%,38%)] to-[hsl(199,89%,48%)]', bgPattern:'radial-gradient(circle at 20% 80%, hsl(174 62% 38% / 0.15) 0%, transparent 50%)', accent:'hsl(174 62% 38%)', description:'Book appointments with top doctors' },
  doctor:  { label:'Doctor',  icon:Stethoscope,  gradient:'from-[hsl(262,80%,50%)] to-[hsl(280,70%,60%)]', bgPattern:'radial-gradient(circle at 30% 70%, hsl(262 80% 50% / 0.15) 0%, transparent 50%)', accent:'hsl(262 80% 50%)', description:'Join our network of healthcare professionals' },
  // NOTE: Admin registration is intentionally excluded from public register page.
  //       Admin is created automatically on first server start via seed data.
};

const Register = () => {
  const [searchParams] = useSearchParams();
  const initialRole = ['patient','doctor'].includes(searchParams.get('role'))
    ? searchParams.get('role') : 'patient';
  const [role, setRole]         = useState(initialRole);
  const [formData, setFormData] = useState({});
  const [errors, setErrors]     = useState({});
  const [loading, setLoading]   = useState(false);
  const [pendingApproval, setPendingApproval] = useState(false);
  const { registerPatient, registerDoctor, user } = useAuth();
  const navigate  = useNavigate();

  // Redirect already logged-in users to their dashboard
  useEffect(() => {
    if (user) {
      if      (user.role === 'patient') navigate('/patient/dashboard', { replace: true });
      else if (user.role === 'doctor')  navigate('/doctor/dashboard',  { replace: true });
      else                              navigate('/admin/dashboard',   { replace: true });
    }
  }, [user, navigate]);
  const { toast } = useToast();
  const config    = roleConfig[role];

  // Reset ALL fields whenever role changes
  useEffect(() => { setFormData({}); setErrors({}); }, [role]);

  const update = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }));
    if (errors[key]) setErrors(prev => { const n = { ...prev }; delete n[key]; return n; });
  };

  const validate = () => {
    const errs = {};
    if (role === 'patient') {
      if (!formData.full_name?.trim() || formData.full_name.trim().length < 2) errs.full_name = 'Name required (min 2 chars)';
      if (!formData.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) errs.email = 'Valid email required';
      if (!formData.phone?.trim() || !/^\d{10}$/.test(formData.phone.trim())) errs.phone = 'Phone number must be exactly 10 digits';
      if (!formData.password || formData.password.length < 6) errs.password = 'Password min 6 chars';
    } else if (role === 'doctor') {
      if (!formData.doctor_name?.trim() || formData.doctor_name.trim().length < 2) errs.doctor_name = 'Name required';
      if (!formData.specialization) errs.specialization = 'Specialization required';
      if (!formData.consultation_fee || Number(formData.consultation_fee) <= 0) errs.consultation_fee = 'Valid fee required';
      if (formData.experience_years !== '' && formData.experience_years !== undefined && Number(formData.experience_years) < 0) errs.experience_years = 'Cannot be negative';
      if (!formData.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) errs.email = 'Valid email required';
      if (!formData.password || formData.password.length < 6) errs.password = 'Password min 6 chars';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      if (role === 'patient') {
        await registerPatient({ name: (formData.full_name || formData.name || '').trim(), email: formData.email?.trim(), password: formData.password, phone: formData.phone?.trim() });
        toast({ title: 'Welcome!', description: 'Patient account created successfully' });
        navigate('/patient/dashboard');
      } else if (role === 'doctor') {
        await registerDoctor({
          name:             formData.doctor_name?.trim(),
          specialization:   formData.specialization,
          consultation_fee: Number(formData.consultation_fee),
          experience_years: Number(formData.experience_years) || 0,
          about:            formData.about?.trim() || '',
          email:            formData.email?.trim(),
          password:         formData.password,
        });
        // Doctor registration is pending — show approval message, do NOT redirect
        setPendingApproval(true);
        setFormData({});
        return; // skip the navigate below
      }
      // Admin registration is not available via the public interface.
      setFormData({}); setErrors({});
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Registration failed', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const ic = (field) =>
    `w-full h-10 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring ${errors[field] ? 'border-destructive' : 'border-input'}`;
  const FE = ({ field }) => errors[field] ? <p className="text-sm text-destructive mt-1">{errors[field]}</p> : null;

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      data-theme={role === 'patient' ? undefined : role}
      style={{ background: config.bgPattern, backgroundColor: 'hsl(var(--background))' }}>
      <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="w-full max-w-lg">
        <div className="text-center mb-6">
          <Link to="/" className="inline-flex items-center gap-2 mb-3">
            <Heart className="h-8 w-8 text-primary" /><span className="text-2xl font-heading font-bold text-foreground">MediCare</span>
          </Link>
          <h1 className="text-3xl font-heading font-bold text-foreground">Create Account</h1>
          <AnimatePresence mode="wait">
            <motion.p key={role} initial={{ opacity:0, y:5 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-5 }}
              className="text-muted-foreground mt-1">{config.description}</motion.p>
          </AnimatePresence>
        </div>

        {/* Role tabs */}
        <div className="flex gap-2 mb-6 justify-center">
          {Object.keys(roleConfig).map(r => {
            const Icon = roleConfig[r].icon;
            return (
              <motion.button key={r} whileHover={{ scale:1.05 }} whileTap={{ scale:0.95 }}
                onClick={() => setRole(r)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium text-sm transition-all duration-300 border-2
                  ${role===r ? `bg-gradient-to-r ${roleConfig[r].gradient} text-white border-transparent shadow-lg` : 'bg-card text-muted-foreground border-border hover:border-primary/30'}`}>
                <Icon className="h-4 w-4"/>{roleConfig[r].label}
              </motion.button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={role} initial={{ opacity:0, x:20 }} animate={{ opacity:1, x:0 }} exit={{ opacity:0, x:-20 }}
            transition={{ duration:0.3 }} className="glass rounded-2xl p-8 max-h-[72vh] overflow-y-auto"
            style={{ borderTop:`3px solid ${config.accent}` }}>
            {/* Doctor pending approval screen */}
            {pendingApproval && role === 'doctor' && (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-yellow-100 flex items-center justify-center mx-auto">
                  <ShieldCheck className="h-8 w-8 text-yellow-600" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-foreground">Registration Submitted!</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Your registration is <span className="font-semibold text-yellow-600">pending admin approval</span>.
                    You will be able to login once an admin reviews and approves your account.
                  </p>
                </div>
                <Link to="/login?role=doctor"
                  className={`inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium text-white bg-gradient-to-r ${config.gradient} hover:opacity-90 transition-opacity`}>
                  Go to Login
                </Link>
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4" noValidate autoComplete="off">
              {/* Block browser autocomplete */}
              <input type="text" name="fake_u" style={{ display:'none' }} readOnly />
              <input type="password" name="fake_p" style={{ display:'none' }} readOnly />

              {/* ── PATIENT ── */}
              {role==='patient' && (<>
                <div>
                  <label className="text-sm font-medium text-foreground">Full Name</label>
                  <div className="relative mt-1"><User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input placeholder="Enter your full name" value={formData.full_name||''} autoComplete="off"
                      onChange={e=>update('full_name',e.target.value)} className={ic('full_name')}/>
                  </div><FE field="full_name"/>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Email</label>
                  <div className="relative mt-1"><Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input type="email" placeholder="Enter your email" value={formData.email||''} autoComplete="off"
                      onChange={e=>update('email',e.target.value)} className={ic('email')}/>
                  </div><FE field="email"/>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Phone</label>
                  <div className="relative mt-1"><Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input type="tel" placeholder="Enter 10-digit phone number" value={formData.phone||''} autoComplete="off"
                      maxLength={10} onChange={e=>update('phone', e.target.value.replace(/\D/g,''))} className={ic('phone')}/>
                  </div><FE field="phone"/>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Password</label>
                  <div className="relative mt-1"><Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input type="password" placeholder="Create a password (min 6 chars)" value={formData.password||''} autoComplete="new-password"
                      onChange={e=>update('password',e.target.value)} className={ic('password')}/>
                  </div><FE field="password"/>
                </div>
              </>)}

              {/* ── DOCTOR ── */}
              {role==='doctor' && (<>
                <div>
                  <label className="text-sm font-medium text-foreground">Doctor Name</label>
                  <div className="relative mt-1"><Stethoscope className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input placeholder="Enter doctor's full name" value={formData.doctor_name||''} autoComplete="off"
                      onChange={e=>update('doctor_name',e.target.value)} className={ic('doctor_name')}/>
                  </div><FE field="doctor_name"/>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Specialization</label>
                  <select value={formData.specialization||''} onChange={e=>update('specialization',e.target.value)}
                    className={`w-full h-10 px-3 mt-1 rounded-lg border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring ${errors.specialization?'border-destructive':'border-input'}`}>
                    <option value="">Select specialization</option>
                    {SPECIALIZATIONS.map(s=><option key={s} value={s}>{s}</option>)}
                  </select><FE field="specialization"/>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-foreground">Consultation Fee (₹)</label>
                    <div className="relative mt-1"><IndianRupee className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                      <input type="number" placeholder="Enter consultation fee in ₹" step="1" value={formData.consultation_fee||''} autoComplete="off"
                        onChange={e=>update('consultation_fee',e.target.value)} className={ic('consultation_fee')}/>
                    </div><FE field="consultation_fee"/>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Experience (Years)</label>
                    <div className="relative mt-1"><Award className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                      <input type="number" placeholder="Years of experience" value={formData.experience_years||''} autoComplete="off"
                        onChange={e=>update('experience_years',e.target.value)} className={ic('experience_years')}/>
                    </div><FE field="experience_years"/>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">About <span className="text-muted-foreground font-normal text-xs">(optional)</span></label>
                  <div className="relative mt-1">
                    <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <textarea placeholder="Write a short bio about your expertise" value={formData.about||''}
                      onChange={e=>update('about',e.target.value)} rows={3}
                      className="w-full pl-10 pr-3 py-2 rounded-lg border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"/>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Email</label>
                  <div className="relative mt-1"><Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input type="email" placeholder="Enter your email" value={formData.email||''} autoComplete="off"
                      onChange={e=>update('email',e.target.value)} className={ic('email')}/>
                  </div><FE field="email"/>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Password</label>
                  <div className="relative mt-1"><Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"/>
                    <input type="password" placeholder="Create a password (min 6 chars)" value={formData.password||''} autoComplete="new-password"
                      onChange={e=>update('password',e.target.value)} className={ic('password')}/>
                  </div><FE field="password"/>
                </div>
              </>)}



              <button type="submit" disabled={loading}
                className={`w-full flex items-center justify-center gap-2 h-11 rounded-lg font-medium text-white bg-gradient-to-r ${config.gradient} hover:opacity-90 transition-opacity disabled:opacity-60`}>
                {loading ? 'Creating...' : <><span>Register as {config.label}</span><ArrowRight className="h-4 w-4"/></>}
              </button>
            </form>
            <p className="text-center text-sm text-muted-foreground mt-6">
              Already have an account? <Link to={`/login?role=${role}`} className="text-primary font-medium hover:underline">Login</Link>
            </p>
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default Register;
