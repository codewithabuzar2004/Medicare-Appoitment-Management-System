import { useState, useEffect, useMemo, useCallback } from 'react';
import useRealtimeRefresh from '../hooks/useRealtimeRefresh';
import { useSocket } from '../contexts/SocketContext';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import api from '../lib/api';
import {
  Calendar, Clock, Search, LogOut, User, Heart, Stethoscope, IndianRupee,
  Eye, XCircle, CheckCircle, X, Edit, Lock, Mail, Phone, Save, UserCircle,
  Star, Award, MessageSquare, ChevronDown, CreditCard, Banknote,
  ShieldCheck, AlertCircle, RefreshCw
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../hooks/use-toast';

// ─── IST helpers ──────────────────────────────────────────────────────────────
const IST = { timeZone: 'Asia/Kolkata' };
const fmtDate = (iso) => new Date(iso).toLocaleDateString('en-IN', { ...IST, day: '2-digit', month: 'short', year: 'numeric' });
const fmtTime = (iso) => new Date(iso).toLocaleTimeString('en-IN', { ...IST, hour: '2-digit', minute: '2-digit', hour12: true });
const fmtSlotTime = (t) => {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${ampm}`;
};

// ─── Modal ────────────────────────────────────────────────────────────────────
const Modal = ({ open, onClose, title, children }) => (
  <AnimatePresence>
    {open && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
        <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
          onClick={e => e.stopPropagation()}
          className="bg-card rounded-2xl border border-border p-6 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-lg font-heading font-bold text-foreground">{title}</h2>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted transition-colors">
              <X className="h-5 w-5" />
            </button>
          </div>
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

const StatusBadge = ({ status }) => {
  const map = {
    // Appointment statuses
    confirmed: 'bg-green-100 text-green-700',
    completed: 'bg-teal-100 text-teal-700',
    pending:   'bg-yellow-100 text-yellow-700',
    cancelled: 'bg-red-100 text-red-700',
    // User statuses
    active:    'bg-green-100 text-green-700',
    blocked:   'bg-red-100 text-red-700',
    rejected:  'bg-red-100 text-red-700',
  };
  const cls = map[status?.toLowerCase()] || 'bg-gray-100 text-gray-600';
  return <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${cls}`}>{status}</span>;
};

const SlotRow = ({ slot, selected, onClick }) => (
  <div
    onClick={onClick}
    className={`flex items-center gap-3 rounded-xl px-4 py-3 border cursor-pointer transition-all duration-150
      ${selected
        ? 'bg-primary/10 border-primary shadow-sm scale-[1.01]'
        : 'bg-muted border-border hover:border-primary/50 hover:bg-primary/5'}`}
  >
    <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0
      ${selected ? 'bg-primary' : 'bg-primary/10'}`}>
      <Clock className={`h-3.5 w-3.5 ${selected ? 'text-white' : 'text-primary'}`} />
    </div>
    <div className="flex-1">
      <p className="text-sm font-semibold text-foreground">{slot.day}</p>
      <p className="text-xs text-muted-foreground">{fmtSlotTime(slot.start_time)} – {fmtSlotTime(slot.end_time)} IST</p>
    </div>
    {selected && <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />}
  </div>
);

// ─── Star Rating Display ──────────────────────────────────────────────────────
const StarRating = ({ rating, size = 'sm' }) => {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  const sz = size === 'sm' ? 'h-3.5 w-3.5' : 'h-5 w-5';

  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(i => (
        <Star key={i}
          className={`${sz} ${i <= full ? 'text-amber-400 fill-amber-400' : i === full+1 && half ? 'text-amber-400 fill-amber-200' : 'text-gray-300 fill-gray-100'}`}
        />
      ))}
    </div>
  );
};

// ─── Doctor Review Card (shown inside Book modal & View modal) ────────────────
const DoctorReviewCard = ({ doctor }) => {
  const exp = doctor.experience_years || 0;
  const rating = doctor.rating || 4.0;
  const reviews = doctor.total_reviews || 0;
  const about = doctor.about || 'Experienced medical professional dedicated to patient care.';

  const getBadge = (exp) => {
    if (exp >= 15) return { label: 'Senior Expert', color: 'bg-purple-100 text-purple-700 border-purple-200' };
    if (exp >= 10) return { label: 'Highly Experienced', color: 'bg-blue-100 text-blue-700 border-blue-200' };
    if (exp >= 5)  return { label: 'Experienced', color: 'bg-green-100 text-green-700 border-green-200' };
    return { label: 'Qualified Doctor', color: 'bg-teal-100 text-teal-700 border-teal-200' };
  };
  const badge = getBadge(exp);

  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/5 to-background p-4 space-y-3">
      {/* Header row */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Stethoscope className="h-6 w-6 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-foreground text-sm leading-tight">{doctor.name}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{doctor.specialization}</p>
          <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-semibold border ${badge.color}`}>
            {badge.label}
          </span>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl bg-amber-50 border border-amber-100 p-2.5 text-center">
          <Award className="h-4 w-4 text-amber-500 mx-auto mb-1" />
          <p className="text-sm font-bold text-foreground">{exp}+</p>
          <p className="text-[10px] text-muted-foreground leading-tight">Yrs Experience</p>
        </div>
        <div className="rounded-xl bg-blue-50 border border-blue-100 p-2.5 text-center">
          <div className="flex justify-center mb-1">
            <StarRating rating={rating} size="sm" />
          </div>
          <p className="text-sm font-bold text-foreground">{rating.toFixed(1)}</p>
          <p className="text-[10px] text-muted-foreground leading-tight">Rating</p>
        </div>
        <div className="rounded-xl bg-green-50 border border-green-100 p-2.5 text-center">
          <MessageSquare className="h-4 w-4 text-green-500 mx-auto mb-1" />
          <p className="text-sm font-bold text-foreground">{reviews}</p>
          <p className="text-[10px] text-muted-foreground leading-tight">Reviews</p>
        </div>
      </div>

      {/* Fee + About */}
      <div className="flex items-center gap-2 rounded-xl bg-primary/8 px-3 py-2">
        <IndianRupee className="h-4 w-4 text-primary flex-shrink-0" />
        <span className="text-sm font-semibold text-foreground">₹{doctor.consultation_fee}</span>
        <span className="text-xs text-muted-foreground">consultation fee</span>
      </div>
      <div className="flex gap-2">
        <MessageSquare className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">{about}</p>
      </div>
    </div>
  );
};

// ─── Clockwise Time Picker for patient booking (9 AM → 7 PM, no AM/PM split) ──
const TimePicker = ({ onChange, slots }) => {
  const today = new Date(Date.now() + 5.5 * 60 * 60 * 1000).toISOString().split('T')[0];
  const [dateVal, setDateVal] = useState('');
  const [hour,    setHour]    = useState('9');   // default 9 AM
  const [minute,  setMinute]  = useState('00');
  const [hOpen,   setHOpen]   = useState(false);
  const [mOpen,   setMOpen]   = useState(false);

  // Clockwise: 9, 10, 11, 12, 1, 2, 3, 4, 5, 6, 7  (9 AM to 7 PM)
  const hours   = ['9','10','11','12','1','2','3','4','5','6','7'];
  const minutes = ['00','10','20','30','40','50'];

  // Map display hour to 24h for ISO
  const hourTo24 = (h) => {
    const n = parseInt(h);
    if (n === 12) return 12;       // 12 noon
    if (n >= 1 && n <= 7) return n + 12; // 1–7 → 13–19 (PM)
    return n;                      // 9, 10, 11 → AM
  };

  // Display label: add AM/PM hint
  const hourLabel = (h) => {
    const n = parseInt(h);
    if (n === 9 || n === 10 || n === 11) return `${h} AM`;
    if (n === 12) return `12 PM`;
    return `${h} PM`;
  };

  const toISO = (d, h, m) => {
    if (!d) return '';
    const h24 = hourTo24(h);
    return `${d}T${String(h24).padStart(2, '0')}:${m}:00+05:30`;
  };

  const emit = (d, h, m) => onChange(toISO(d, h, m));

  const Sel = ({ open, setOpen, val, opts, onPick, label, cls = '' }) => (
    <div className={`relative ${cls}`}>
      <button type="button" onClick={() => setOpen(o => !o)}
        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl border text-sm font-semibold transition-all duration-150
          ${open ? 'border-primary bg-primary/8 shadow-sm' : 'border-border bg-background hover:border-primary/40'}`}>
        <span className="text-foreground">{label ? label(val) : val}</span>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.13 }}
            className="absolute top-full left-0 mt-1 z-[70] w-full bg-card border border-border rounded-xl shadow-2xl overflow-hidden">
            <div className="max-h-52 overflow-y-auto py-1">
              {opts.map(o => (
                <button key={o} type="button"
                  onClick={() => { onPick(o); setOpen(false); }}
                  className={`w-full text-left px-3 py-2 text-sm transition-colors
                    ${o === val ? 'bg-primary text-primary-foreground font-bold' : 'hover:bg-muted text-foreground'}`}>
                  {label ? label(o) : o}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  const selected     = dateVal ? toISO(dateVal, hour, minute) : '';
  const displayTime  = `${hourLabel(hour)}:${minute}`;

  return (
    <div className="space-y-3">
      {/* ── Date ── */}
      <div>
        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">
          Select Date
        </label>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary pointer-events-none" />
          <input type="date" value={dateVal} min={today}
            onChange={e => { setDateVal(e.target.value); emit(e.target.value, hour, minute); }}
            className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-border bg-background text-foreground text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
        </div>
      </div>

      {/* ── Time dropdowns ── */}
      <div>
        <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 block">
          Select Time <span className="text-primary/70 normal-case font-normal">(9 AM – 7 PM)</span>
        </label>
        <div className="grid grid-cols-2 gap-2">
          {/* Hour */}
          <div>
            <p className="text-[10px] text-muted-foreground text-center mb-1">Hour</p>
            <Sel open={hOpen} setOpen={setHOpen} val={hour} opts={hours} label={hourLabel}
              onPick={v => { setHour(v); emit(dateVal, v, minute); }} />
          </div>
          {/* Minute */}
          <div>
            <p className="text-[10px] text-muted-foreground text-center mb-1">Minute</p>
            <Sel open={mOpen} setOpen={setMOpen} val={minute} opts={minutes}
              onPick={v => { setMinute(v); emit(dateVal, hour, v); }} />
          </div>
        </div>
      </div>

      {/* ── Available slot hints ── */}
      {slots && slots.length > 0 ? (
        <div className="rounded-xl bg-primary/5 border border-primary/20 px-3 py-2.5">
          <p className="text-[11px] font-semibold text-primary mb-2 flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> Doctor's Weekly Schedule
          </p>
          <div className="flex flex-wrap gap-1.5">
            {(() => {
              const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
              return slots.map(s => (
                <span key={s._id}
                  className={`inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium border
                    ${s.day === today
                      ? 'bg-primary text-primary-foreground border-primary font-bold'
                      : 'bg-background border-border text-foreground'}`}>
                  {s.day === today && <span className="w-1.5 h-1.5 rounded-full bg-primary-foreground animate-pulse" />}
                  <span className="font-bold">{s.day === today ? 'Today' : s.day}:</span>
                  {fmtSlotTime(s.start_time)}–{fmtSlotTime(s.end_time)}
                </span>
              ));
            })()}
          </div>
        </div>
      ) : (
        <div className="rounded-xl bg-orange-50 border border-orange-200 px-3 py-2.5">
          <p className="text-[11px] font-semibold text-orange-700 flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> No schedule set — you can still book any time
          </p>
        </div>
      )}

      {/* ── Selected preview ── */}
      {selected && (
        <div className="rounded-xl bg-green-50 border border-green-200 px-3 py-2.5 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
            <CheckCircle className="h-4 w-4 text-green-600" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-green-700 uppercase tracking-wide">Appointment Selected</p>
            <p className="text-sm font-bold text-green-800">
              {new Date(dateVal).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })}
              {' at '}{displayTime} IST
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Profile Edit Form (outside to prevent remount) ───────────────────────────
const ProfileForm = ({ form, setForm, errors, setErrors, saving, onSubmit }) => {
  const ic = (field) =>
    `w-full h-11 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-colors ${errors[field] ? 'border-destructive' : 'border-input'}`;

  const onChange = useCallback((field, val) => {
    setForm(p => ({ ...p, [field]: val }));
    setErrors(p => ({ ...p, [field]: '' }));
  }, [setForm, setErrors]);

  return (
    <div className="space-y-4">
      {/* Full Name */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Full Name</label>
        <div className="relative">
          <User className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="text" placeholder="Your full name" autoComplete="off"
            value={form.name ?? ''} onChange={e => onChange('name', e.target.value)}
            className={ic('name')} />
        </div>
        {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
      </div>

      {/* Email */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Email</label>
        <div className="relative">
          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="email" placeholder="your@email.com" autoComplete="off"
            value={form.email ?? ''} onChange={e => onChange('email', e.target.value)}
            className={ic('email')} />
        </div>
        {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
      </div>

      {/* Phone */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Phone</label>
        <div className="relative">
          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
          <input type="tel" placeholder="+91 98765 43210" autoComplete="off"
            value={form.phone ?? ''} maxLength={10} onChange={e => onChange('phone', e.target.value.replace(/\D/g,''))}
            className={ic('phone')} />
        </div>
        {errors.phone && <p className="text-xs text-destructive mt-1">{errors.phone}</p>}
      </div>

      {/* Divider */}
      <div className="border-t border-border pt-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">Change Password (optional)</p>

        {/* New Password */}
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <input type="password" placeholder="Leave blank to keep current" autoComplete="new-password"
                value={form.password ?? ''} onChange={e => onChange('password', e.target.value)}
                className={ic('password')} />
            </div>
            {errors.password && <p className="text-xs text-destructive mt-1">{errors.password}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Confirm New Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3.5 h-4 w-4 text-muted-foreground pointer-events-none" />
              <input type="password" placeholder="Repeat new password" autoComplete="new-password"
                value={form.confirm_password ?? ''} onChange={e => onChange('confirm_password', e.target.value)}
                className={ic('confirm_password')} />
            </div>
            {errors.confirm_password && <p className="text-xs text-destructive mt-1">{errors.confirm_password}</p>}
          </div>
        </div>
      </div>

      <button onClick={onSubmit} disabled={saving}
        className="w-full flex items-center justify-center gap-2 h-11 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 active:scale-[0.98] transition-all mt-2 disabled:opacity-60">
        {saving
          ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Saving…</>
          : <><Save className="h-4 w-4" /> Save Changes</>
        }
      </button>
    </div>
  );
};

// ─── Main ─────────────────────────────────────────────────────────────────────
const PatientDashboard = () => {
  const { user, logout, refreshUser } = useAuth();
  const { connected }    = useSocket();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [doctors, setDoctors] = useState([]);
  const [appointments, setAppointments] = useState([]);
  // Pre-populate from sessionStorage user so profile shows instantly
  const [patientProfile, setPatientProfile] = useState(user || null);
  const [activeTab, setActiveTab] = useState('doctors');
  const [initialLoading, setInitialLoading] = useState(true);
  const [doctorAvailability, setDoctorAvailability] = useState({}); // { doctorId: slots[] }
  const [search, setSearch] = useState('');
  const [specFilter, setSpecFilter] = useState('all');
  const [bookDate, setBookDate] = useState('');
  const [paying, setPaying] = useState(false);
  // Reschedule state
  const [rescheduleOpen, setRescheduleOpen] = useState(null); // appointment object
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduling, setRescheduling] = useState(false);
  // Review state
  const [submittingReview, setSubmittingReview] = useState(false);
  const [paymentStep, setPaymentStep] = useState(null);
  // Review states
  const [reviewOpen, setReviewOpen]       = useState(null); // appointment object
  const [reviewRating, setReviewRating]   = useState(5);
  const [reviewText, setReviewText]       = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewedIds, setReviewedIds]     = useState(new Set()); // null | 'select' | 'processing'
  const [selectedPayment, setSelectedPayment] = useState(null); // 'razorpay' | 'cod'
  const [conflictPopup, setConflictPopup] = useState(null); // { type: 'slot'|'patient', message: string }
  const [paymentHistory, setPaymentHistory] = useState([]);
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [bookOpen, setBookOpen] = useState(null);
  const [viewDoctorOpen, setViewDoctorOpen] = useState(null);
  const [viewDoctorSlots, setViewDoctorSlots] = useState([]);
  const [bookSlots, setBookSlots] = useState([]);
  const [apptSearch, setApptSearch] = useState('');
  const [apptStatusFilter, setApptStatusFilter] = useState('all');

  // Profile edit state
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileForm, setProfileForm] = useState({});
  const [profileErrors, setProfileErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const loadData = useCallback(async () => {
    try {
      // Run all 3 calls in parallel; use allSettled so one failure doesn't block others
      const [doctorsResult, apptResult, profileResult] = await Promise.allSettled([
        api.get('/doctors'),
        api.get('/patient/appointments'),
        api.get('/patient/profile'),
      ]);

      if (doctorsResult.status === 'fulfilled') {
        const d = doctorsResult.value.data;
        setDoctors(Array.isArray(d) ? d : (d.doctors || []));
      }
      if (apptResult.status === 'fulfilled') {
        const a = apptResult.value.data;
        setAppointments(Array.isArray(a) ? a : (a.appointments || []));
      }
      if (profileResult.status === 'fulfilled') {
        const p = profileResult.value.data;
        setPatientProfile(p.user || p);
      }

      // Fetch payment history
      try {
        const pr = await api.get('/patient/payments');
        setPaymentHistory(pr.data.payments || []);
      } catch { /* ignore */ }

      // Load already-reviewed appointments
      try {
        const rv = await api.get('/reviews/my');
        const ids = new Set((rv.data.reviews || []).map(r => r.appointment_id?._id || r.appointment_id));
        setReviewedIds(ids);
      } catch { /* non-blocking */ }

      // Fetch doctor availability slots
      if (doctorsResult.status === 'fulfilled') {
        const docList = (() => { const d = doctorsResult.value.data; return Array.isArray(d) ? d : (d.doctors || []); })();
        const availResults = await Promise.allSettled(
          docList.map(d => api.get(`/doctors/${d._id}/availability`))
        );
        const availMap = {};
        docList.forEach((d, i) => {
          const r = availResults[i];
          availMap[d._id] = r.status === 'fulfilled'
            ? (Array.isArray(r.value.data) ? r.value.data : (r.value.data.slots || []))
            : [];
        });
        setDoctorAvailability(availMap);
      }
    } catch (err) {
      console.error('PatientDashboard loadData error:', err?.message);
    } finally {
      setInitialLoading(false);
    }
  }, [user?._id]);

  // Real-time: refreshes instantly when server emits 'refresh' via Socket.io
  useRealtimeRefresh(loadData);

  const specializations = [...new Set(doctors.map(d => d.specialization))];

  const filteredDoctors = useMemo(() => doctors.filter(d => {
    const matchSearch = (d.name || '').toLowerCase().includes(search.toLowerCase()) || (d.specialization || '').toLowerCase().includes(search.toLowerCase());
    return matchSearch && (specFilter === 'all' || d.specialization === specFilter);
  }), [doctors, search, specFilter]);

  const filteredAppointments = useMemo(() => appointments.filter(a => {
    const matchSearch = !apptSearch || (a.doctor_id?.name || '').toLowerCase().includes(apptSearch.toLowerCase());
    return matchSearch && (apptStatusFilter === 'all' || a.status === apptStatusFilter);
  }), [appointments, apptSearch, apptStatusFilter]);

  const openBook = async (doc) => {
    setBookOpen(doc); setBookDate('');
    setBookSlots([]);  // reset first
    try {
      const r = await api.get(`/doctors/${doc._id}/availability`);
      // API returns { success, slots: [] } or plain array
      const slots = Array.isArray(r.data) ? r.data : (r.data.slots || []);
      setBookSlots(slots);
    } catch {
      setBookSlots([]);
    }
  };
  const openViewDoctor = async (doc) => {
    setViewDoctorOpen(doc);
    setViewDoctorSlots([]);  // reset first
    try {
      const r = await api.get(`/doctors/${doc._id}/availability`);
      // API returns { success, slots: [] } or plain array
      const slots = Array.isArray(r.data) ? r.data : (r.data.slots || []);
      setViewDoctorSlots(slots);
    } catch {
      setViewDoctorSlots([]);
    }
  };

  // Step 1: validate date → open payment selection modal
  const handleBook = (doctorId) => {
    if (!bookDate) {
      toast({ title: 'Error', description: 'Select a date and time', variant: 'destructive' });
      return;
    }
    if (new Date(bookDate) <= new Date()) {
      toast({ title: 'Error', description: 'Select a future date', variant: 'destructive' });
      return;
    }
    // Open payment method selection
    setPaymentStep('select');
  };

  // Step 2: user picks payment method → process booking
  // ── Razorpay script loader (singleton, safe to call multiple times) ──────
  const loadRazorpayScript = () =>
    new Promise((resolve, reject) => {
      // Already loaded
      if (window.Razorpay) { resolve(); return; }
      // Remove any stale/failed script tag
      const existing = document.getElementById('rzp-checkout-script');
      if (existing) existing.remove();
      const s    = document.createElement('script');
      s.id       = 'rzp-checkout-script';
      s.src      = 'https://checkout.razorpay.com/v1/checkout.js';
      s.async    = true;
      s.onload   = () => resolve();
      s.onerror  = () => reject(new Error('Could not load Razorpay. Please check your internet connection.'));
      document.head.appendChild(s);
    });

  // ── Reset all booking/payment state to clean slate ───────────────────────
  const resetBookingState = () => {
    setBookOpen(null);
    setBookDate('');
    setPaymentStep(null);
    setSelectedPayment(null);
    setPaying(false);
  };

  const processBooking = async (doctorId) => {
    // Snapshot mutable state IMMEDIATELY — before any async/state-change
    const snapDoctor  = bookOpen;
    const snapDate    = bookDate;

    setSelectedPayment('razorpay');
    setPaymentStep('processing');
    setPaying(true);

    // ── Razorpay path ─────────────────────────────────────────────────────
    try {
      // Step 1 — create backend order
      let orderRes;
      try {
        orderRes = await api.post('/payment/create-order', {
          doctor_id:        doctorId,
          appointment_date: snapDate,
        });
      } catch (orderErr) {
        const errCode = orderErr.response?.data?.errorCode;
        const errMsg  = orderErr.response?.data?.message || 'Could not create payment order. Try again.';

        if (errCode === 'SLOT_ALREADY_BOOKED') {
          setConflictPopup({ type: 'slot', message: errMsg });
          setPaymentStep('select');
          setPaying(false);
          return;
        }
        if (errCode === 'PATIENT_ALREADY_BOOKED') {
          setConflictPopup({ type: 'patient', message: errMsg });
          setPaymentStep('select');
          setPaying(false);
          return;
        }
        toast({
          title: '❌ Order Creation Failed',
          description: errMsg,
          variant: 'destructive',
        });
        setPaymentStep('select');
        setPaying(false);
        return;
      }

      const { order, appointment, key_id, prefill, notes } = orderRes.data;

      // Validate response shape before proceeding
      if (!order?.id || !appointment?._id || !key_id) {
        toast({ title: '❌ Invalid Response', description: 'Server returned unexpected data. Contact support.', variant: 'destructive' });
        setPaymentStep('select');
        setPaying(false);
        return;
      }

      // Step 2 — load Razorpay SDK
      try {
        await loadRazorpayScript();
      } catch (scriptErr) {
        toast({ title: '❌ Razorpay Load Failed', description: scriptErr.message, variant: 'destructive' });
        setPaymentStep('select');
        setPaying(false);
        return;
      }

      // Step 3 — build Razorpay options object (no state used — only snapshots)
      const rzpOptions = {
        key:         key_id,
        amount:      order.amount,
        currency:    order.currency || 'INR',
        order_id:    order.id,
        name:        'MediCare',
        description: `Appointment with Dr. ${snapDoctor?.name || 'Doctor'}`,
        image:       `${window.location.origin}/favicon.ico`,
        prefill:     prefill || {},
        notes:       notes   || {},
        theme:       { color: '#4f46e5' },
        retry:       { enabled: false },

        // ── SUCCESS ──────────────────────────────────────────────
        handler: async (response) => {
          setPaymentStep('razorpay_open');
          setPaying(true);
          try {
            const verifyRes = await api.post('/payment/verify', {
              razorpay_order_id:   response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature:  response.razorpay_signature,
              appointment_id:      appointment._id,
            });
            const appt = verifyRes.data?.appointment;
            toast({
              title: '🎉 Payment Successful!',
              description: `Appointment confirmed with Dr. ${appt?.doctor?.name || snapDoctor?.name || 'Doctor'}.`,
            });
            resetBookingState();
            loadData();
          } catch (verifyErr) {
            toast({
              title: '❌ Verification Failed',
              description: verifyErr.response?.data?.message || 'Payment done but verification failed. Contact support.',
              variant: 'destructive',
            });
            resetBookingState();
            loadData();
          }
        },

        // ── DISMISS / CLOSE ──────────────────────────────────────
        modal: {
          backdropclose: false,
          escape:        true,
          ondismiss: () => {
            api.post('/payment/fail', { appointment_id: appointment._id }).catch(() => {});
            toast({
              title: 'Payment Cancelled',
              description: 'No amount was charged.',
              variant: 'destructive',
            });
            resetBookingState();
            loadData();
          },
        },
      };

      // Step 4 — open Razorpay
      setPaymentStep('razorpay_open');
      await new Promise((r) => setTimeout(r, 50));

      const rzp = new window.Razorpay(rzpOptions);
      rzp.on('payment.failed', (resp) => {
        api.post('/payment/fail', { appointment_id: appointment._id }).catch(() => {});
        toast({
          title: '❌ Payment Failed',
          description: resp?.error?.description || 'Payment was declined. Please try again.',
          variant: 'destructive',
        });
        resetBookingState();
        loadData();
      });
      rzp.open();

    } catch (err) {
      console.error('processBooking unexpected error:', err);
      toast({ title: '❌ Unexpected Error', description: err.message || 'Something went wrong. Please try again.', variant: 'destructive' });
      setPaymentStep('select');
      setPaying(false);
    }
  };

  const cancelAppointment = async (id) => {
    if (!window.confirm('Are you sure you want to cancel this appointment?')) return;
    try {
      await api.put(`/patient/appointments/${id}/cancel`);
      toast({ title: 'Appointment Cancelled', description: 'Your appointment has been cancelled.' });
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to cancel', variant: 'destructive' });
    }
  };

  // ── NEW: Reschedule appointment ──
  const openReschedule = (appt) => {
    setRescheduleOpen(appt);
    setRescheduleDate('');
  };

  const handleReschedule = async () => {
    if (!rescheduleDate) {
      toast({ title: 'Error', description: 'Please select a new date and time.', variant: 'destructive' });
      return;
    }
    setRescheduling(true);
    try {
      await api.put(`/patient/appointments/${rescheduleOpen._id}/reschedule`, { new_date: rescheduleDate });
      toast({ title: '📅 Rescheduled!', description: 'Your appointment has been rescheduled successfully.' });
      setRescheduleOpen(null);
      setRescheduleDate('');
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to reschedule', variant: 'destructive' });
    } finally { setRescheduling(false); }
  };

  // ── Submit doctor review ──
  const handleSubmitReview = async () => {
    if (!reviewRating || !reviewOpen) return;
    setReviewLoading(true);
    try {
      await api.post('/reviews', {
        appointment_id: reviewOpen._id,
        rating: reviewRating,
        review: reviewText.trim(),
      });
      toast({ title: '⭐ Review Submitted!', description: `Thank you for rating Dr. ${reviewOpen.doctor_id?.name}!` });
      setReviewedIds(prev => new Set([...prev, reviewOpen._id]));
      setReviewOpen(null); setReviewRating(5); setReviewText('');
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to submit review', variant: 'destructive' });
    } finally { setReviewLoading(false); }
  };

  // ── Profile edit ──
  const openProfileEdit = () => {
    setProfileForm({
      name:             patientProfile?.name || patientProfile?.full_name || '',
      email:            patientProfile?.email || '',
      phone:            patientProfile?.phone || '',
      password:         '',
      confirm_password: '',
    });
    setProfileErrors({});
    setProfileOpen(true);
  };

  const validateProfile = () => {
    const e = {};
    if (!profileForm.name?.trim() || profileForm.name.trim().length < 2) e.name = 'Name required (min 2 chars)';
    if (!profileForm.email?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileForm.email)) e.email = 'Valid email required';
    if (!profileForm.phone?.trim() || !/^\d{10}$/.test(profileForm.phone.trim())) e.phone = 'Phone number must be exactly 10 digits';
    if (profileForm.password && profileForm.password.length < 6) e.password = 'Password must be at least 6 characters';
    if (profileForm.password && profileForm.password !== profileForm.confirm_password) e.confirm_password = 'Passwords do not match';
    setProfileErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSaveProfile = async () => {
    if (!validateProfile()) return;
    setSaving(true);
    try {
      const payload = {
        name:  profileForm.name?.trim(),
        email: profileForm.email?.trim(),
        phone: profileForm.phone?.trim(),
      };
      if (profileForm.password) payload.password = profileForm.password;
      const res = await api.put('/patient/profile', payload);
      const updated = res.data.user || res.data;
      setPatientProfile(updated);
      await refreshUser(); // update sessionStorage user
      toast({ title: 'Profile Updated!', description: 'Your profile has been saved.' });
      setProfileOpen(false);
      loadData();
    } catch (err) {
      toast({ title: 'Error', description: err.response?.data?.message || 'Failed to save', variant: 'destructive' });
    } finally { setSaving(false); }
  };

  const tabs = [
    { id: 'doctors',      label: 'Find Doctors' },
    { id: 'appointments', label: 'My Appointments' },
    { id: 'payments',     label: 'Payment History' },
    { id: 'profile',      label: 'My Profile' },
  ];


  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Heart className="h-6 w-6 text-primary" />
          <span className="font-heading font-bold text-lg text-foreground">MediCare</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setActiveTab('profile')}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <UserCircle className="h-5 w-5" />
            <span className="hidden sm:inline">{patientProfile?.name || user?.name}</span>
          </button>
          <button onClick={() => { logout(); navigate('/'); }} className="p-2 text-muted-foreground hover:text-foreground">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-3xl font-heading font-bold text-foreground">Welcome, {patientProfile?.name || user?.name} 👋</h1>
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold
              ${connected ? 'bg-green-100 border-green-200 text-green-700' : 'bg-gray-100 border-gray-200 text-gray-500'}`}>
              <span className="relative flex h-2 w-2">
                {connected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>}
                <span className={`relative inline-flex rounded-full h-2 w-2 ${connected ? 'bg-green-500' : 'bg-gray-400'}`}></span>
              </span>
              {connected ? 'Live — Real-time' : 'Connecting...'}
            </span>
          </div>
          <p className="text-muted-foreground mt-1">Find and book appointments with top doctors</p>
        </motion.div>

        {/* Initial loading overlay */}
        {initialLoading && (
          <div className="flex items-center justify-center py-16">
            <div className="text-center space-y-3">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground text-sm">Loading your dashboard…</p>
            </div>
          </div>
        )}

        {/* Stats */}
        {!initialLoading && <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total',    value: appointments.length,                                  icon: Calendar,    color: 'bg-blue-50 text-blue-600' },
            { label: 'Confirmed', value: appointments.filter(a=>a.status==='confirmed').length, icon: CheckCircle, color: 'bg-green-50 text-green-600' },
            { label: 'Pending',  value: appointments.filter(a=>a.status==='pending').length,  icon: Clock,       color: 'bg-yellow-50 text-yellow-600' },
            { label: 'Cancelled', value: appointments.filter(a=>a.status==='cancelled').length, icon: XCircle,     color: 'bg-red-50 text-red-600' },
          ].map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <div className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                <div className={`p-2 rounded-lg ${s.color}`}><s.icon className="h-4 w-4" /></div>
                <div><p className="text-xl font-bold text-foreground">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
              </div>
            </motion.div>
          ))}
        </div>}

        {/* Tabs */}
        {!initialLoading && (
          <div className="flex gap-1 bg-muted p-1 rounded-lg w-fit">
            {tabs.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === t.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                {t.label}
              </button>
            ))}
          </div>
        )}

        {!initialLoading && activeTab === 'doctors' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input placeholder="Search doctors..." value={search} onChange={e => setSearch(e.target.value)}
                  className="w-full h-10 pl-10 pr-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <select value={specFilter} onChange={e => setSpecFilter(e.target.value)}
                className="h-10 px-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring w-full sm:w-48">
                <option value="all">All Specializations</option>
                {specializations.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredDoctors.length === 0
                ? <p className="text-muted-foreground col-span-2">No doctors found.</p>
                : filteredDoctors.map((doc, i) => (
                  <motion.div key={doc._id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <div className="bg-card rounded-xl border border-border p-4 hover:shadow-md hover:border-primary/30 transition-all duration-200">
                      <div className="flex gap-3">
                        {/* Avatar */}
                        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Stethoscope className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-foreground text-sm leading-tight">{doc.name}</h3>
                          <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                            <span className="inline-block px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground text-xs font-medium">{doc.specialization}</span>
                            {/* Availability badge */}
                            {(() => {
                              const slots = doctorAvailability[doc._id] || [];
                              const hasSlots = slots.length > 0;
                              return hasSlots
                                ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-green-100 text-green-700 text-xs font-semibold"><span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse inline-block" /> Available</span>
                                : <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-gray-100 text-gray-500 text-xs font-medium"><span className="w-1.5 h-1.5 rounded-full bg-gray-400 inline-block" /> No Schedule</span>;
                            })()}
                          </div>
                          {/* Rating row */}
                          <div className="flex items-center gap-2 mt-1.5">
                            <StarRating rating={doc.rating || 4.0} size="sm" />
                            <span className="text-xs font-semibold text-amber-600">{(doc.rating || 4.0).toFixed(1)}</span>
                            <span className="text-xs text-muted-foreground">({doc.total_reviews || 0} reviews)</span>
                          </div>
                          {/* Stats row */}
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Award className="h-3 w-3 text-amber-500" />
                              <span className="font-medium text-foreground">{doc.experience_years || 0}+</span> yrs exp
                            </span>
                            <span className="flex items-center gap-1 text-xs text-muted-foreground">
                              <IndianRupee className="h-3 w-3 text-primary" />
                              <span className="font-semibold text-foreground">₹{doc.consultation_fee}</span>
                            </span>
                          </div>
                          {/* Today's availability slots */}
                          {(() => {
                            const slots = doctorAvailability[doc._id] || [];
                            const today = new Date().toLocaleDateString('en-US', { weekday: 'long' }); // e.g. "Monday"
                            const todaySlots = slots.filter(s => s.day === today);
                            if (todaySlots.length === 0) return null;
                            return (
                              <div className="mt-1.5 flex flex-wrap gap-1">
                                {todaySlots.map(s => (
                                  <span key={s._id} className="inline-flex items-center gap-1 bg-green-50 border border-green-200 rounded px-1.5 py-0.5 text-[10px] font-medium text-green-700">
                                    <Clock className="h-2.5 w-2.5" /> Today: {fmtSlotTime(s.start_time)}–{fmtSlotTime(s.end_time)}
                                  </span>
                                ))}
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                      {/* Action buttons */}
                      <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                        <button onClick={() => openViewDoctor(doc)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border hover:bg-muted transition-colors text-sm font-medium text-muted-foreground hover:text-foreground">
                          <Eye className="h-4 w-4" /> View Profile
                        </button>
                        <button onClick={() => openBook(doc)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity">
                          <Calendar className="h-4 w-4" /> Book
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              }
            </div>
          </div>
        )}

        {!initialLoading && activeTab === 'appointments' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <input placeholder="Search by doctor..." value={apptSearch} onChange={e => setApptSearch(e.target.value)}
                  className="w-full h-10 pl-10 pr-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <select value={apptStatusFilter} onChange={e => setApptStatusFilter(e.target.value)}
                className="h-10 px-3 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring w-40">
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            {filteredAppointments.length === 0
              ? <p className="text-muted-foreground text-center py-8">No appointments found.</p>
              : filteredAppointments.map((appt, i) => {
                  const doc = appt.doctor_id;
                  return (
                    <motion.div key={appt._id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}>
                      <div className="bg-card rounded-xl border border-border p-4 flex items-center justify-between flex-wrap gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                            <Stethoscope className="h-5 w-5 text-teal-600" />
                          </div>
                          <div>
                            <p className="font-semibold text-foreground">{doc?.name || 'Unknown'}</p>
                            <p className="text-sm text-muted-foreground">{doc?.specialization || '—'} • ₹{appt.fee_at_booking ?? doc?.consultation_fee ?? '—'}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="inline-flex items-center gap-1 text-xs bg-primary/5 text-primary px-2 py-0.5 rounded-full font-medium">
                                <Calendar className="h-3 w-3" /> {fmtDate(appt.appointment_date)}
                              </span>
                              <span className="inline-flex items-center gap-1 text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                                <Clock className="h-3 w-3" /> {fmtTime(appt.appointment_date)} IST
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <StatusBadge status={appt.status} />
                          {appt.paymentStatus && appt.paymentStatus !== 'pending' && (
                            <span className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
                              appt.paymentStatus === 'paid' ? 'bg-green-100 text-green-700' :
                              appt.paymentStatus === 'failed' ? 'bg-red-100 text-red-700' :
                              'bg-gray-100 text-gray-600'
                            }`}>₹ {appt.paymentStatus}</span>
                          )}
                          {/* Reschedule — only pending */}
                          {appt.status === 'pending' && (
                            <button onClick={() => openReschedule(appt)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-blue-200 text-sm text-blue-600 hover:bg-blue-50 transition-colors">
                              <Calendar className="h-4 w-4" /> Reschedule
                            </button>
                          )}
                          {/* Cancel — pending or confirmed */}
                          {['pending','confirmed'].includes(appt.status) && (
                            <button onClick={() => cancelAppointment(appt._id)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-border text-sm text-destructive hover:bg-muted transition-colors">
                              <XCircle className="h-4 w-4" /> Cancel
                            </button>
                          )}
                          {/* Review — confirmed/completed and not yet reviewed */}
                          {['confirmed','completed'].includes(appt.status) && !reviewedIds.has(appt._id) && (
                            <button onClick={() => { setReviewOpen(appt); setReviewRating(5); setReviewText(''); }}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-yellow-200 bg-yellow-50 text-sm text-yellow-700 hover:bg-yellow-100 transition-colors">
                              <Star className="h-4 w-4" /> Rate Doctor
                            </button>
                          )}
                          {reviewedIds.has(appt._id) && (
                            <span className="flex items-center gap-1 px-3 py-1.5 text-xs text-green-600 font-medium">
                              <CheckCircle className="h-3.5 w-3.5" /> Reviewed
                            </span>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })
            }
          </div>
        )}

        {/* ── MY PROFILE TAB ── */}
        {/* ── PAYMENT HISTORY TAB ── */}
        {!initialLoading && activeTab === 'payments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-heading font-bold text-foreground flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" /> Payment History
              </h2>
              <span className="text-sm text-muted-foreground">{paymentHistory.length} transaction{paymentHistory.length !== 1 ? 's' : ''}</span>
            </div>

            {paymentHistory.length === 0 ? (
              <div className="bg-card rounded-2xl border border-border p-12 text-center">
                <CreditCard className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-40" />
                <p className="text-muted-foreground font-medium">No payment records yet</p>
                <p className="text-sm text-muted-foreground mt-1">Your payment history will appear here after booking appointments</p>
              </div>
            ) : (
              <div className="bg-card rounded-2xl border border-border overflow-hidden">
                {/* Table header */}
                <div className="hidden md:grid grid-cols-6 gap-4 px-5 py-3 bg-muted/50 border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                  <div className="col-span-2">Transaction</div>
                  <div>Doctor</div>
                  <div>Amount</div>
                  <div>Method</div>
                  <div>Status</div>
                </div>
                <div className="divide-y divide-border">
                  {paymentHistory.map((pay, i) => (
                    <div key={pay._id} className="grid grid-cols-1 md:grid-cols-6 gap-2 md:gap-4 px-5 py-4 hover:bg-muted/30 transition-colors">
                      {/* Transaction info */}
                      <div className="col-span-2">
                        <p className="text-sm font-semibold text-foreground">
                          #{pay._id?.slice(-6).toUpperCase()}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {new Date(pay.createdAt).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}
                          {' '}{new Date(pay.createdAt).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' })}
                        </p>
                        {pay.appointment_id?.appointment_date && (
                          <p className="text-xs text-primary mt-0.5 flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Appt: {new Date(pay.appointment_id.appointment_date).toLocaleDateString('en-IN', { day:'2-digit', month:'short' })}
                          </p>
                        )}
                      </div>
                      {/* Doctor */}
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Stethoscope className="h-3.5 w-3.5 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{pay.doctor_id?.name || '—'}</p>
                          <p className="text-xs text-muted-foreground truncate">{pay.doctor_id?.specialization || ''}</p>
                        </div>
                      </div>
                      {/* Amount */}
                      <div className="flex items-center">
                        <span className="text-sm font-bold text-foreground flex items-center gap-0.5">
                          <IndianRupee className="h-3.5 w-3.5" />{pay.amount?.toLocaleString('en-IN')}
                        </span>
                      </div>
                      {/* Payment method */}
                      <div className="flex items-center">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border ${
                          pay.paymentMode === 'razorpay'
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : 'bg-teal-50 text-teal-700 border-teal-200'
                        }`}>
                          {pay.paymentMode === 'razorpay'
                            ? <><CreditCard className="h-3 w-3" /> Online</>
                            : <><CreditCard className="h-3 w-3" /> Online</>
                          }
                        </span>
                      </div>
                      {/* Status */}
                      <div className="flex items-center">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
                          pay.status === 'success'  ? 'bg-green-100 text-green-700' :
                          pay.status === 'pending'  ? 'bg-yellow-100 text-yellow-700' :
                          pay.status === 'failed'   ? 'bg-red-100 text-red-700' :
                          pay.status === 'refunded' ? 'bg-purple-100 text-purple-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {pay.status === 'success'  ? '✓ Paid' :
                           pay.status === 'pending'  ? '⏳ Pending' :
                           pay.status === 'failed'   ? '✗ Failed' :
                           pay.status === 'refunded' ? '↩ Refunded' :
                           (pay.status || '—')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary row */}
                <div className="px-5 py-3 bg-muted/30 border-t border-border flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                      {paymentHistory.filter(p => p.status === 'success').length} Paid
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-yellow-400 inline-block" />
                      {paymentHistory.filter(p => p.status === 'pending').length} Pending
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
                      {paymentHistory.filter(p => p.status === 'failed').length} Failed
                    </span>
                  </div>
                  <div className="text-sm font-bold text-foreground flex items-center gap-1">
                    Total paid: <IndianRupee className="h-3.5 w-3.5 text-primary" />
                    {paymentHistory.filter(p => p.status === 'success').reduce((sum, p) => sum + (p.amount || 0), 0).toLocaleString('en-IN')}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

                {!initialLoading && activeTab === 'profile' && !patientProfile && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center space-y-3">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground text-sm">Loading profile…</p>
            </div>
          </div>
        )}
        {!initialLoading && activeTab === 'profile' && patientProfile && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">

            {/* Profile card */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <UserCircle className="h-9 w-9 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-heading font-bold text-foreground">{patientProfile.name}</h2>
                    <p className="text-sm text-muted-foreground">{patientProfile.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <StatusBadge status={patientProfile.status} />
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full capitalize">Patient</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={openProfileEdit}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity">
                    <Edit className="h-4 w-4" /> Edit Profile
                  </button>
                  <a href="/login" onClick={(e) => { e.preventDefault(); logout(); navigate('/login?forgot=true'); }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors">
                    <Lock className="h-4 w-4" /> Forgot Password
                  </a>
                </div>
              </div>

              {/* Info grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { icon: User,  label: 'Full Name', value: patientProfile.name,  color: 'bg-blue-50 text-blue-600' },
                  { icon: Mail,  label: 'Email',     value: patientProfile.email,       color: 'bg-purple-50 text-purple-600' },
                  { icon: Phone, label: 'Phone',     value: patientProfile.phone || '—', color: 'bg-teal-50 text-teal-600' },
                ].map((item, i) => (
                  <div key={i} className="bg-muted/50 rounded-xl p-4 flex items-center gap-3 border border-border">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${item.color}`}>
                      <item.icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground">{item.label}</p>
                      <p className="text-sm font-semibold text-foreground truncate">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Appointment summary */}
            <div className="bg-card rounded-2xl border border-border p-6">
              <h3 className="font-heading font-bold text-foreground mb-4 flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" /> Appointment Summary
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                {[
                  { label: 'Total',    value: appointments.length,                                  color: 'bg-blue-50 text-blue-600' },
                  { label: 'Confirmed', value: appointments.filter(a=>a.status==='confirmed').length, color: 'bg-green-50 text-green-600' },
                  { label: 'Pending',  value: appointments.filter(a=>a.status==='pending').length,  color: 'bg-yellow-50 text-yellow-600' },
                  { label: 'Cancelled', value: appointments.filter(a=>a.status==='cancelled').length, color: 'bg-red-50 text-red-600' },
                ].map((s, i) => (
                  <div key={i} className={`rounded-xl p-4 text-center ${s.color}`}>
                    <p className="text-2xl font-bold">{s.value}</p>
                    <p className="text-xs font-medium mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Recent appointments */}
              {appointments.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-foreground mb-2">Recent Appointments</p>
                  {appointments.slice(0, 4).map(appt => (
                    <div key={appt._id} className="flex items-center justify-between p-3 bg-muted rounded-xl">
                      <div>
                        <p className="text-sm font-medium text-foreground">{appt.doctor_id?.name || 'Unknown Doctor'}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" /> {fmtDate(appt.appointment_date)}
                          </span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {fmtTime(appt.appointment_date)} IST
                          </span>
                        </div>
                      </div>
                      <StatusBadge status={appt.status} />
                    </div>
                  ))}
                </div>
              )}
            </div>

          </motion.div>
        )}
      </div>

      {/* ── EDIT PROFILE MODAL ── */}
      <Modal open={profileOpen} onClose={() => setProfileOpen(false)} title="Edit Profile & Security">
        <ProfileForm
          form={profileForm}
          setForm={setProfileForm}
          errors={profileErrors}
          setErrors={setProfileErrors}
          saving={saving}
          onSubmit={handleSaveProfile}
        />
      </Modal>

      {/* ── RESCHEDULE MODAL ── */}
      <Modal
        open={!!rescheduleOpen}
        onClose={() => { setRescheduleOpen(null); setRescheduleDate(''); }}
        title="📅 Reschedule Appointment"
      >
        <div className="space-y-4 mt-2">
          {rescheduleOpen && (
            <div className="bg-muted/40 rounded-xl p-4 border border-border">
              <p className="text-sm font-semibold text-foreground">Dr. {rescheduleOpen.doctor_id?.name}</p>
              <p className="text-xs text-muted-foreground mt-1">
                Current: {new Date(rescheduleOpen.appointment_date).toLocaleString('en-IN', { timeZone:'Asia/Kolkata', day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })}
              </p>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Select New Date & Time</label>
            <TimePicker
              key={rescheduleOpen?._id + '-reschedule'}
              onChange={setRescheduleDate}
              slots={rescheduleOpen ? (doctorAvailability[rescheduleOpen.doctor_id?._id] || []) : []}
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              onClick={handleReschedule}
              disabled={rescheduling || !rescheduleDate}
              className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-50">
              {rescheduling ? 'Rescheduling...' : 'Confirm Reschedule'}
            </button>
            <button
              onClick={() => { setRescheduleOpen(null); setRescheduleDate(''); }}
              className="flex-1 h-11 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-colors">
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      {/* ── REVIEW MODAL ── */}
      <Modal
        open={!!reviewOpen}
        onClose={() => setReviewOpen(null)}
        title="⭐ Rate Your Doctor"
      >
        <div className="space-y-5 mt-2">
          {reviewOpen && (
            <div className="bg-muted/40 rounded-xl p-4 border border-border">
              <p className="text-sm font-semibold text-foreground">Dr. {reviewOpen.doctor_id?.name}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{reviewOpen.doctor_id?.specialization}</p>
            </div>
          )}
          {/* Star picker */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Your Rating</label>
            <div className="flex gap-2">
              {[1,2,3,4,5].map(n => (
                <button key={n} onClick={() => setReviewRating(n)}
                  className={`w-12 h-12 rounded-xl border-2 text-2xl transition-all ${
                    reviewRating >= n
                      ? 'border-yellow-400 bg-yellow-50 scale-110'
                      : 'border-border bg-muted/30 hover:border-yellow-300'
                  }`}>
                  ⭐
                </button>
              ))}
            </div>
            {reviewRating > 0 && (
              <p className="text-sm text-yellow-600 font-medium mt-2">
                {['','Poor','Fair','Good','Very Good','Excellent'][reviewRating]} ({reviewRating}/5)
              </p>
            )}
          </div>
          {/* Comment */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Comment <span className="text-muted-foreground">(optional)</span></label>
            <textarea
              value={reviewText}
              onChange={e => setReviewText(e.target.value)}
              rows={3}
              maxLength={500}
              placeholder="Share your experience with this doctor..."
              className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
            <p className="text-xs text-muted-foreground mt-1 text-right">{reviewText.length}/500</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleSubmitReview}
              disabled={submittingReview || !reviewRating}
              className="flex-1 h-11 rounded-xl bg-yellow-500 text-white font-semibold text-sm hover:bg-yellow-600 transition-colors disabled:opacity-50">
              {submittingReview ? 'Submitting...' : 'Submit Review'}
            </button>
            <button
              onClick={() => setReviewOpen(null)}
              className="flex-1 h-11 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-colors">
              Skip
            </button>
          </div>
        </div>
      </Modal>

      {/* ── BOOK MODAL ── */}
      <Modal
        open={!!bookOpen && paymentStep !== 'razorpay_open'}
        onClose={() => { setBookOpen(null); setBookDate(''); setPaymentStep(null); setSelectedPayment(null); }}
        title={
          paymentStep === 'select' ? '💳 Book Appointment' :
          paymentStep === 'processing' ? '⏳ Processing...' :
          '📅 Book Appointment'
        }
      >
        <div className="space-y-4 mt-1">

          {/* ── STEP 1: Pick date & time ── */}
          {!paymentStep && (<>
            {bookOpen && <DoctorReviewCard doctor={bookOpen} />}
            <div className="flex items-center gap-2 my-1">
              <div className="h-px flex-1 bg-border" />
              <span className="text-xs text-muted-foreground font-medium px-2">Pick your slot</span>
              <div className="h-px flex-1 bg-border" />
            </div>
            {/* Clinic hours notice */}
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2">
              <span className="text-amber-500 text-sm">🕐</span>
              <p className="text-xs text-amber-700 font-medium">Clinic Hours: 9 AM – 7 PM IST only. Last booking slot is 7:00 PM.</p>
            </div>

            <TimePicker key={bookOpen?._id} onChange={setBookDate} slots={bookSlots} />
            <button
              onClick={() => {
                if (!bookDate) { toast({ title: 'Select date & time', variant: 'destructive' }); return; }
                if (new Date(bookDate) <= new Date()) { toast({ title: 'Select a future date', variant: 'destructive' }); return; }
                setPaymentStep('select');
              }}
              className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-sm">
              <Calendar className="h-4 w-4" /> Continue to Payment →
            </button>
          </>)}

          {/* ── STEP 2: Payment method selection ── */}
          {paymentStep === 'select' && (<>
            {/* Appointment summary card */}
            <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-xl border border-primary/20 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Stethoscope className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-foreground">{bookOpen?.name}</p>
                    <p className="text-xs text-muted-foreground">{bookOpen?.specialization}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-primary flex items-center gap-0.5">
                    <IndianRupee className="h-4 w-4" />{bookOpen?.consultation_fee}
                  </p>
                  <p className="text-xs text-muted-foreground">consultation fee</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-primary/10 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1 font-medium text-foreground">
                  <Calendar className="h-3.5 w-3.5 text-primary" />
                  {bookDate ? new Date(bookDate).toLocaleDateString('en-IN', { weekday:'short', day:'2-digit', month:'short', year:'numeric' }) : ''}
                </span>
                <span className="flex items-center gap-1 font-medium text-foreground">
                  <Clock className="h-3.5 w-3.5 text-primary" />
                  {bookDate ? new Date(bookDate).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true, timeZone:'Asia/Kolkata' }) + ' IST' : ''}
                </span>
              </div>
            </div>

            <p className="text-sm font-semibold text-foreground">Confirm Payment</p>

            {/* Razorpay card */}
            <button
              onClick={() => bookOpen && processBooking(bookOpen._id)}
              disabled={paying}
              className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-blue-200 bg-blue-50 hover:bg-blue-100 hover:border-blue-400 transition-all text-left disabled:opacity-60">
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center flex-shrink-0 shadow-md">
                <CreditCard className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-foreground text-sm">Pay Online via Razorpay</p>
                <p className="text-xs text-muted-foreground mt-0.5">Credit/Debit Card • UPI • Net Banking • Wallets</p>
                <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                  {['Visa','Mastercard','UPI','GPay','Paytm'].map(m => (
                    <span key={m} className="text-[10px] font-semibold bg-white border border-blue-200 text-blue-700 px-1.5 py-0.5 rounded">{m}</span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                <span className="text-xs font-bold text-green-700 bg-green-100 border border-green-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                  🔒 Secure
                </span>
                <span className="text-[10px] text-muted-foreground">Instant confirm</span>
              </div>
            </button>

            {/* Security note */}
            <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-green-500" />
              Your data is encrypted and secure
            </p>

            <button
              onClick={() => setPaymentStep(null)}
              className="w-full h-9 rounded-xl border border-border text-muted-foreground text-sm hover:bg-muted transition-colors">
              ← Back to date selection
            </button>
          </>)}

          {/* ── STEP 3: Processing spinner ── */}
          {paymentStep === 'processing' && (
            <div className="text-center py-10 space-y-4">
              <div className="w-14 h-14 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <div className="space-y-1">
                <p className="text-sm font-semibold text-foreground">
                  Opening Razorpay payment gateway…
                </p>
                <p className="text-xs text-muted-foreground">Please wait, do not close this window</p>
              </div>
              <p className="text-xs text-muted-foreground bg-blue-50 border border-blue-100 rounded-lg px-3 py-2">
                💡 A payment popup will appear shortly. Please complete the payment there.
              </p>
            </div>
          )}
        </div>
      </Modal>

      {/* ── SLOT CONFLICT POPUP (doctor already booked at this time) ── */}
      <AnimatePresence>
        {conflictPopup && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.85, y: 30 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.85, y: 30 }}
              className="bg-card rounded-3xl border border-border shadow-2xl p-8 w-full max-w-sm text-center space-y-5">
              <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center mx-auto">
                <AlertCircle className="h-10 w-10 text-red-500" />
              </div>
              <div>
                <h2 className="text-xl font-heading font-bold text-foreground mb-2">
                  {conflictPopup.type === 'slot' ? 'Time Slot Already Booked!' : 'Appointment Already Exists!'}
                </h2>
                <p className="text-sm text-muted-foreground leading-relaxed">{conflictPopup.message}</p>
              </div>
              {conflictPopup.type === 'slot' && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm text-amber-800">
                  ⚠️ Another patient has already reserved this time slot with this doctor. Please choose a different time.
                </div>
              )}
              {conflictPopup.type === 'patient' && (
                <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 text-sm text-blue-800">
                  ℹ️ You already have an appointment booked with this doctor on the same day. Please check your appointments.
                </div>
              )}
              <button
                onClick={() => { setConflictPopup(null); setPaymentStep(null); }}
                className="w-full h-12 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors text-sm">
                Choose a Different Time
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── RAZORPAY OPEN OVERLAY ── */}
      {/* Shows a small toast-like indicator when Razorpay popup is open */}
      {paymentStep === 'razorpay_open' && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[999] bg-card border border-border rounded-2xl shadow-2xl px-5 py-3 flex items-center gap-3 animate-in slide-in-from-bottom-4">
          <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin flex-shrink-0" />
          <div>
            <p className="text-sm font-semibold text-foreground">Razorpay Payment Open</p>
            <p className="text-xs text-muted-foreground">Complete your payment in the popup window</p>
          </div>
        </div>
      )}

      {/* ── VIEW DOCTOR MODAL ── */}
      <Modal open={!!viewDoctorOpen} onClose={() => setViewDoctorOpen(null)} title="Doctor Profile">
        {viewDoctorOpen && (
          <div className="space-y-4 mt-2">
            {/* Doctor Review Card */}
            <DoctorReviewCard doctor={viewDoctorOpen} />

            {/* Availability Slots */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-2 flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-primary" />
                Available Slots
                <span className="text-xs text-muted-foreground font-normal">(IST)</span>
              </p>
              {viewDoctorSlots.length === 0
                ? (
                  <div className="rounded-xl bg-muted border border-border px-4 py-3 text-center">
                    <p className="text-xs text-muted-foreground">No availability set yet</p>
                  </div>
                )
                : (
                  <div className="space-y-2">
                    {viewDoctorSlots.map(s => <SlotRow key={s._id} slot={s} />)}
                  </div>
                )
              }
            </div>

            {/* Book button */}
            <button
              onClick={() => {
                const doc = viewDoctorOpen;
                setViewDoctorOpen(null);
                setPaymentStep(null);
                openBook(doc);
              }}
              className="w-full h-11 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
              <Calendar className="h-4 w-4" />
              Book Appointment
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default PatientDashboard;
