import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import {
  Heart, Mail, Lock, ArrowRight, User, Stethoscope, ShieldCheck,
  Eye, EyeOff, SendHorizonal, CheckCircle,
} from 'lucide-react';
import { useToast } from '../hooks/use-toast';
import api from '../lib/api';

const roleConfig = {
  patient: {
    label: 'Patient', icon: User,
    gradient: 'from-[hsl(174,62%,38%)] to-[hsl(199,89%,48%)]',
    bgPattern: 'radial-gradient(circle at 20% 80%, hsl(174 62% 38% / 0.15) 0%, transparent 50%)',
    accent: 'hsl(174 62% 38%)',
    description: 'Access your appointments & health records',
  },
  doctor: {
    label: 'Doctor', icon: Stethoscope,
    gradient: 'from-[hsl(262,80%,50%)] to-[hsl(280,70%,60%)]',
    bgPattern: 'radial-gradient(circle at 30% 70%, hsl(262 80% 50% / 0.15) 0%, transparent 50%)',
    accent: 'hsl(262 80% 50%)',
    description: 'Manage your patients & schedule',
  },
  admin: {
    label: 'Admin', icon: ShieldCheck,
    gradient: 'from-[hsl(0,72%,51%)] to-[hsl(25,95%,53%)]',
    bgPattern: 'radial-gradient(circle at 25% 75%, hsl(0 72% 51% / 0.15) 0%, transparent 50%)',
    accent: 'hsl(0 72% 51%)',
    description: 'Platform administration access',
  },
};

const Login = () => {
  const [searchParams]    = useSearchParams();
  const initialRole = ['patient','doctor','admin'].includes(searchParams.get('role'))
    ? searchParams.get('role') : 'patient';

  const [role, setRole]   = useState(initialRole);
  const [view, setView]   = useState('login'); // 'login' | 'forgot'
  const [loading, setLoading] = useState(false);

  // Login fields
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [errors, setErrors]     = useState({});

  // Forgot password fields
  const [fpEmail, setFpEmail]   = useState('');
  const [fpError, setFpError]   = useState('');
  const [fpSent, setFpSent]     = useState(false);


  const { login: doLogin, user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const config = roleConfig[role];

  useEffect(() => {
    if (user) {
      const paths = { patient: '/patient/dashboard', doctor: '/doctor/dashboard', admin: '/admin/dashboard' };
      navigate(paths[user.role] || '/', { replace: true });
    }
  }, [user, navigate]);

  useEffect(() => {
    setEmail(''); setPassword(''); setErrors({});
    setFpEmail(''); setFpError(''); setFpSent(false);
    setView('login');
  }, [role]);

  const ic = (err) =>
    `w-full h-10 pl-10 pr-3 rounded-lg border bg-background text-foreground text-sm ` +
    `placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring ` +
    `transition-colors ${err ? 'border-destructive' : 'border-input'}`;

  // ── LOGIN ─────────────────────────────────────────────────────
  const handleLogin = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!email.trim()) errs.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = 'Invalid email format';
    if (!password) errs.password = 'Password is required';
    else if (password.length < 6) errs.password = 'Minimum 6 characters';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setLoading(true);
    try {
      const u = await doLogin(email.trim(), password, role);
      const paths = { patient: '/patient/dashboard', doctor: '/doctor/dashboard', admin: '/admin/dashboard' };
      navigate(paths[u.role]);
    } catch (err) {
      toast({
        title: 'Login Failed',
        description: err.response?.data?.message || 'Invalid email or password',
        variant: 'destructive',
      });
    } finally { setLoading(false); }
  };

  // ── FORGOT PASSWORD — Send Reset Link ─────────────────────────
  const handleForgot = async (e) => {
    e.preventDefault();
    if (!fpEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fpEmail)) {
      setFpError('Enter a valid email address'); return;
    }
    setFpError(''); setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email: fpEmail.trim() });
      setFpSent(true);
      toast({
        title: '📧 Reset Link Sent!',
        description: 'Check your inbox and spam folder for the password reset link.',
      });
    } catch (err) {
      const msg = err.response?.data?.message || 'Something went wrong. Please try again.';
      toast({ title: 'Failed to Send Reset Link', description: msg, variant: 'destructive' });
    } finally { setLoading(false); }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 transition-all duration-700"
      data-theme={role === 'patient' ? undefined : role}
      style={{ background: config.bgPattern, backgroundColor: 'hsl(var(--background))' }}>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-lg">

        {/* Logo */}
        <div className="text-center mb-6">
          <Link to="/" className="inline-flex items-center gap-2 mb-3">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-2xl font-heading font-bold text-foreground">MediCare</span>
          </Link>
          <h1 className="text-3xl font-heading font-bold text-foreground">
            {view === 'login' ? 'Welcome Back' : 'Forgot Password'}
          </h1>
          <AnimatePresence mode="wait">
            <motion.p key={view + role} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }} className="text-muted-foreground mt-1 text-sm">
              {view === 'login' ? config.description : 'Enter your email to receive a password reset link'}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Role tabs — only on login */}
        {view === 'login' && (
          <div className="flex gap-2 mb-6 justify-center flex-wrap">
            {Object.keys(roleConfig).map((r) => {
              const Icon = roleConfig[r].icon;
              return (
                <motion.button key={r} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  onClick={() => setRole(r)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium text-sm transition-all duration-300 border-2
                    ${role === r
                      ? `bg-gradient-to-r ${roleConfig[r].gradient} text-white border-transparent shadow-lg`
                      : 'bg-card text-muted-foreground border-border hover:border-primary/30'}`}>
                  <Icon className="h-4 w-4" />{roleConfig[r].label}
                </motion.button>
              );
            })}
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div key={view + role}
            initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.22 }}
            className="glass rounded-2xl p-8"
            style={{ borderTop: `3px solid ${config.accent}` }}>

            {/* ── LOGIN FORM ──────────────────────────────────── */}
            {view === 'login' && (
              <form onSubmit={handleLogin} className="space-y-5" noValidate autoComplete="off">
                <input type="text" name="fk_u" style={{ display: 'none' }} readOnly />
                <input type="password" name="fk_p" style={{ display: 'none' }} readOnly />

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input type="email" placeholder="Enter your email" value={email} autoComplete="off"
                      onChange={e => { setEmail(e.target.value); setErrors(p => ({ ...p, email: '' })); }}
                      className={ic(errors.email)} />
                  </div>
                  {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-foreground">Password</label>
                    <button type="button"
                      onClick={() => { setFpEmail(email); setView('forgot'); setFpSent(false); }}
                      className="text-xs text-primary hover:underline font-medium transition-colors">
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      placeholder="Enter your password" value={password}
                      autoComplete="new-password"
                      onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: '' })); }}
                      className={ic(errors.password) + ' pr-10'} />
                    <button type="button" onClick={() => setShowPass(p => !p)}
                      className="absolute right-3 top-3 text-muted-foreground hover:text-foreground">
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
                </div>

                <button type="submit" disabled={loading}
                  className={`w-full flex items-center justify-center gap-2 h-11 rounded-lg font-medium text-white bg-gradient-to-r ${config.gradient} hover:opacity-90 transition-opacity disabled:opacity-60`}>
                  {loading ? 'Logging in…' : <><span>Login as {config.label}</span><ArrowRight className="h-4 w-4" /></>}
                </button>
              </form>
            )}

            {/* ── FORGOT PASSWORD FORM ─────────────────────────── */}
            {view === 'forgot' && !fpSent && (
              <form onSubmit={handleForgot} className="space-y-5" noValidate>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Registered Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <input type="email" placeholder="Enter your email" value={fpEmail} autoComplete="off"
                      onChange={e => { setFpEmail(e.target.value); setFpError(''); }}
                      className={ic(fpError)} />
                  </div>
                  {fpError && <p className="text-sm text-destructive">{fpError}</p>}
                </div>

                <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-3 flex items-start gap-2">
                  <SendHorizonal className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-blue-700 leading-relaxed">
                    We'll send a secure reset link to your email.
                    The link expires in <strong>15 minutes</strong>.
                    Check your spam folder if you don't see it.
                  </p>
                </div>

                <button type="submit" disabled={loading}
                  className={`w-full flex items-center justify-center gap-2 h-11 rounded-lg font-medium text-white bg-gradient-to-r ${config.gradient} hover:opacity-90 transition-opacity disabled:opacity-60`}>
                  {loading
                    ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Sending…</>
                    : <><SendHorizonal className="h-4 w-4" /><span>Send Reset Link</span></>}
                </button>

                <button type="button" onClick={() => setView('login')}
                  className="w-full h-9 rounded-lg border border-border text-muted-foreground text-sm hover:bg-muted transition-colors">
                  ← Back to Login
                </button>
              </form>
            )}

            {/* ── SUCCESS STATE ────────────────────────────────── */}
            {view === 'forgot' && fpSent && (
              <div className="space-y-5 text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground text-lg">Check Your Email!</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    We've sent a password reset link to <strong>{fpEmail}</strong>.
                    The link expires in 15 minutes.
                  </p>
                </div>

                <div className="flex flex-col gap-2">
                  <button onClick={() => { setFpSent(false); setFpEmail(''); }}
                    className="w-full h-9 rounded-lg border border-border text-muted-foreground text-sm hover:bg-muted transition-colors">
                    ← Send Another Link
                  </button>
                  <button onClick={() => setView('login')}
                    className="w-full h-9 rounded-lg border border-border text-muted-foreground text-sm hover:bg-muted transition-colors">
                    Back to Login
                  </button>
                </div>
              </div>
            )}

            {/* Register link — login view only, hide for admin */}
            {view === 'login' && role !== 'admin' && (
              <p className="text-center text-sm text-muted-foreground mt-6">
                Don't have an account?{' '}
                <Link to={`/register?role=${role}`} className="text-primary font-medium hover:underline">
                  Register
                </Link>
              </p>
            )}
          </motion.div>
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default Login;
