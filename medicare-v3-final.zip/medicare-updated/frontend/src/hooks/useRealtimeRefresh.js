import { useEffect, useCallback, useRef } from 'react';
import { useSocket } from '../contexts/SocketContext';

/**
 * useRealtimeRefresh
 *
 * Calls loadFn IMMEDIATELY when:
 *  1. Component mounts
 *  2. Server emits 'refresh' via Socket.io           ← instant
 *  3. Server emits 'refresh_doctors' (for patient)   ← instant
 *  4. User switches back to this browser tab         ← instant
 *  5. Window regains focus                           ← instant
 *
 * Zero polling — purely event-driven.
 */
const useRealtimeRefresh = (loadFn) => {
  const { socket } = useSocket();
  const fnRef      = useRef(loadFn);
  const activeRef  = useRef(true);

  useEffect(() => { fnRef.current = loadFn; }, [loadFn]);

  const run = useCallback(async () => {
    if (!activeRef.current) return;
    try { await fnRef.current(); } catch { /* silently ignore */ }
  }, []);

  // 1. Mount load
  useEffect(() => {
    activeRef.current = true;
    run();
    return () => { activeRef.current = false; };
  }, [run]);

  // 2 & 3. Socket events → instant reload
  useEffect(() => {
    if (!socket) return;
    socket.on('refresh', run);
    socket.on('refresh_doctors', run); // patient dashboard doctor list update
    return () => {
      socket.off('refresh', run);
      socket.off('refresh_doctors', run);
    };
  }, [socket, run]);

  // 4 & 5. Tab visibility + window focus → instant reload
  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') run(); };
    const onFocus   = () => run();
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onFocus);
    };
  }, [run]);
};

export default useRealtimeRefresh;
