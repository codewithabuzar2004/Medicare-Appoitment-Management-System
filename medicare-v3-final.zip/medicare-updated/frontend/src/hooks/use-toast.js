import { useState, useCallback, useRef } from 'react';

let toastId = 0;
const listeners = new Set();
let globalToasts = [];

export function toast({ title, description, variant = 'default' }) {
  const id = ++toastId;
  const newToast = { id, title, description, variant };
  globalToasts = [...globalToasts, newToast];
  listeners.forEach((l) => l([...globalToasts]));
  // Auto-dismiss after 4 seconds
  setTimeout(() => {
    globalToasts = globalToasts.filter((t) => t.id !== id);
    listeners.forEach((l) => l([...globalToasts]));
  }, 4000);
}

export function dismissToast(id) {
  globalToasts = globalToasts.filter((t) => t.id !== id);
  listeners.forEach((l) => l([...globalToasts]));
}

export function useToast() {
  return { toast };
}

export function useToastListener() {
  const [toasts, setToasts] = useState([]);
  const subscribed = useRef(false);

  const subscribe = useCallback(() => {
    if (subscribed.current) return () => {};
    subscribed.current = true;
    listeners.add(setToasts);
    return () => {
      listeners.delete(setToasts);
      subscribed.current = false;
    };
  }, []);

  return { toasts, subscribe };
}
