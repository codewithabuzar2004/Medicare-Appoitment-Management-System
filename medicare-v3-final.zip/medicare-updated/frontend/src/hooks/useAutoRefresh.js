import { useEffect, useRef, useCallback } from 'react';

/**
 * useAutoRefresh — keeps dashboards live without logout/reload.
 *
 * Triggers a silent data reload:
 *   1. On component mount
 *   2. Every `interval` ms  (default 5 seconds)
 *   3. When user switches back to this browser tab
 *   4. When the browser window regains focus
 */
const useAutoRefresh = (loadFn, interval = 5000) => {
  const timerRef  = useRef(null);
  const fnRef     = useRef(loadFn);
  const activeRef = useRef(true);

  // always keep fnRef pointing to latest loadFn without restarting the effect
  useEffect(() => { fnRef.current = loadFn; }, [loadFn]);

  const run = useCallback(async () => {
    if (!activeRef.current) return;
    try { await fnRef.current(); } catch { /* ignore background errors */ }
  }, []);

  const startTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(run, interval);
  }, [run, interval]);

  useEffect(() => {
    activeRef.current = true;
    run();         // immediate first load
    startTimer();  // start polling

    const onVisible = () => {
      if (document.visibilityState === 'visible') { run(); startTimer(); }
    };
    const onFocus = () => { run(); startTimer(); };

    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);

    return () => {
      activeRef.current = false;
      clearInterval(timerRef.current);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onFocus);
    };
  }, [run, startTimer]);
};

export default useAutoRefresh;
