import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToastListener, dismissToast } from '../hooks/use-toast';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';

const iconMap = {
  default:     { Icon: CheckCircle, bg: 'bg-green-500',  ring: 'ring-green-300',  text: 'text-white' },
  destructive: { Icon: AlertCircle, bg: 'bg-red-500',    ring: 'ring-red-300',    text: 'text-white' },
  warning:     { Icon: AlertTriangle, bg: 'bg-amber-500',ring: 'ring-amber-300',  text: 'text-white' },
  info:        { Icon: Info,         bg: 'bg-blue-500',  ring: 'ring-blue-300',   text: 'text-white' },
};

const ToastContainer = () => {
  const { toasts, subscribe } = useToastListener();

  useEffect(() => {
    return subscribe();
  }, [subscribe]);

  return (
    /* Full-screen overlay — each notification is a centred big popup */
    <AnimatePresence>
      {toasts.map((t, index) => {
        const { Icon, bg, ring, text } = iconMap[t.variant] || iconMap.default;
        return (
          <motion.div
            key={t.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            /* Dim backdrop for each toast — stacked by index */
            style={{ zIndex: 9000 + index }}
            className="fixed inset-0 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            onClick={() => dismissToast(t.id)}
          >
            <motion.div
              initial={{ scale: 0.8, y: 40, opacity: 0 }}
              animate={{ scale: 1,   y: 0,  opacity: 1 }}
              exit={{    scale: 0.8, y: 40, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 340, damping: 26 }}
              onClick={e => e.stopPropagation()}
              className="relative w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl overflow-hidden"
            >
              {/* Coloured top strip */}
              <div className={`${bg} h-2 w-full`} />

              <div className="px-8 py-8 flex flex-col items-center text-center gap-5">
                {/* Big icon circle */}
                <div className={`w-20 h-20 rounded-full ${bg} bg-opacity-15 flex items-center justify-center ring-4 ${ring} ring-opacity-30`}>
                  <Icon className={`h-10 w-10 ${bg.replace('bg-', 'text-')}`} />
                </div>

                {/* Title */}
                <p className="text-xl font-bold text-gray-900 dark:text-white leading-tight">
                  {t.title}
                </p>

                {/* Description */}
                {t.description && (
                  <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed max-w-xs">
                    {t.description}
                  </p>
                )}

                {/* Dismiss button */}
                <button
                  onClick={() => dismissToast(t.id)}
                  className={`mt-1 w-full h-12 rounded-2xl ${bg} ${text} font-semibold text-sm hover:opacity-90 active:scale-95 transition-all shadow-md`}
                >
                  OK, Got It
                </button>
              </div>

              {/* Close X */}
              <button
                onClick={() => dismissToast(t.id)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <X className="h-4 w-4 text-gray-500" />
              </button>
            </motion.div>
          </motion.div>
        );
      })}
    </AnimatePresence>
  );
};

export default ToastContainer;
