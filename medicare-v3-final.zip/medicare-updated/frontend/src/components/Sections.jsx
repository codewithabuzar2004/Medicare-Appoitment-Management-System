import { motion } from 'framer-motion';
import { Calendar, UserCheck, ShieldCheck, Clock, Search, Activity } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const features = [
  { icon: Search, title: 'Find Doctors', description: 'Search doctors by specialization, location, and availability.' },
  { icon: Calendar, title: 'Easy Booking', description: 'Book appointments online with preferred date and time slots.' },
  { icon: UserCheck, title: 'Verified Profiles', description: 'All doctors are verified with experience and qualifications.' },
  { icon: Clock, title: 'Real-time Status', description: 'Track your appointment status — pending, approved, or completed.' },
  { icon: ShieldCheck, title: 'Secure & Private', description: 'Your health data is encrypted and fully protected.' },
  { icon: Activity, title: 'Admin Dashboard', description: 'Powerful analytics and management tools for administrators.' },
];

export const FeaturesSection = () => (
  <section className="py-24 bg-background">
    <div className="container mx-auto px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
        <span className="text-sm font-semibold text-primary uppercase tracking-wider">Features</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">Everything You Need</h2>
        <p className="text-muted-foreground mt-3 max-w-lg mx-auto">A complete healthcare appointment solution for patients, doctors, and administrators.</p>
      </motion.div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <motion.div key={feature.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="group bg-card rounded-xl p-6 border border-border hover-lift cursor-default">
            <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center mb-4 group-hover:bg-primary transition-colors">
              <feature.icon className="w-6 h-6 text-secondary-foreground group-hover:text-primary-foreground transition-colors" />
            </div>
            <h3 className="text-lg font-heading font-semibold text-foreground mb-2">{feature.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

import { useState, useEffect } from 'react';
import api from '../lib/api';

export const StatsSection = () => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get('/stats')
      .then(res => setStats(res.data.stats))
      .catch(() => {}); // silently ignore — show nothing if fails
  }, []);

  if (!stats) return null;

  const items = [
    { value: stats.totalDoctors,        label: 'Verified Doctors' },
    { value: stats.totalAppointments,   label: 'Appointments Completed' },
    { value: stats.totalSpecializations,label: 'Specializations' },
    { value: stats.totalPatients,       label: 'Registered Patients' },
  ];

  // Only render if at least one stat > 0
  if (items.every(i => !i.value)) return null;

  return (
    <section className="py-20 bg-primary">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {items.map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, scale: 0.8 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="text-center">
              <p className="text-3xl md:text-4xl font-heading font-extrabold text-primary-foreground">{stat.value}</p>
              <p className="text-sm text-primary-foreground/70 mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

import { UserPlus, CalendarCheck, ThumbsUp } from 'lucide-react';

const steps = [
  { icon: UserPlus, step: '01', title: 'Create Account', description: 'Sign up as a patient or doctor in seconds.' },
  { icon: Search, step: '02', title: 'Find a Doctor', description: 'Browse by specialization and check availability.' },
  { icon: CalendarCheck, step: '03', title: 'Book Appointment', description: 'Select date, time, and confirm your booking.' },
  { icon: ThumbsUp, step: '04', title: 'Get Treated', description: 'Visit the doctor and track your health journey.' },
];

export const HowItWorksSection = () => (
  <section className="py-24 bg-secondary/50">
    <div className="container mx-auto px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
        <span className="text-sm font-semibold text-primary uppercase tracking-wider">How It Works</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">Simple 4-Step Process</h2>
      </motion.div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((item, i) => (
          <motion.div key={item.step} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15 }} className="relative text-center">
            <div className="w-16 h-16 rounded-2xl bg-primary mx-auto flex items-center justify-center mb-4">
              <item.icon className="w-7 h-7 text-primary-foreground" />
            </div>
            <span className="text-xs font-bold text-primary uppercase">Step {item.step}</span>
            <h3 className="text-lg font-heading font-semibold text-foreground mt-1">{item.title}</h3>
            <p className="text-sm text-muted-foreground mt-2">{item.description}</p>
            {i < steps.length - 1 && <div className="hidden lg:block absolute top-8 left-[calc(50%+40px)] w-[calc(100%-80px)] h-px bg-border" />}
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

import { ArrowRight } from 'lucide-react';

export const CTASection = () => {
  const { user } = useAuth();
  const navigate  = useNavigate();
  const dash = user ? ({ patient:'/patient/dashboard', doctor:'/doctor/dashboard', admin:'/admin/dashboard' }[user.role] || '/') : null;
  return (
  <section className="py-24 bg-background">
    <div className="container mx-auto px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="relative rounded-2xl bg-gradient-to-br from-primary to-accent p-12 md:p-16 text-center overflow-hidden">
        <div className="absolute top-0 left-0 w-40 h-40 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-60 h-60 bg-white/5 rounded-full translate-x-1/3 translate-y-1/3" />
        <div className="relative z-10">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary-foreground">Ready to Get Started?</h2>
          <p className="text-primary-foreground/80 mt-3 max-w-md mx-auto">Join thousands of patients who trust MediCare for their healthcare needs.</p>
          <div className="flex flex-wrap justify-center gap-3 mt-8">
            <Link to={dash || "/register"} onClick={dash ? (e)=>{e.preventDefault();navigate(dash);} : undefined} className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-secondary text-secondary-foreground font-medium hover:opacity-90 transition-opacity">
              Create Account <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/contact" className="inline-flex items-center px-6 py-3 rounded-lg border border-white/30 text-primary-foreground font-medium hover:bg-white/10 transition-colors">
              Contact Us
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  </section>
  );
};
