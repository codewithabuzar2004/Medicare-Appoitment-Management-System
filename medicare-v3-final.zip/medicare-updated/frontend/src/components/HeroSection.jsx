import { motion } from 'framer-motion';
import { ArrowRight, Calendar, Shield, Clock } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import heroImage from '../assets/hero-doctor.png';

const DASHBOARDS = {
  patient: '/patient/dashboard',
  doctor:  '/doctor/dashboard',
  admin:   '/admin/dashboard',
};

const HeroSection = () => {
  const { user } = useAuth();
  const navigate  = useNavigate();

  const handleBookClick = (e) => {
    if (user) {
      e.preventDefault();
      navigate(DASHBOARDS[user.role] || '/');
    }
  };

  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-secondary via-background to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }} className="flex flex-col gap-6">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="inline-flex items-center gap-2 bg-secondary rounded-full px-4 py-1.5 w-fit">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-medium text-secondary-foreground">#1 Doctor Appointment Platform</span>
            </motion.div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-extrabold leading-tight text-foreground">
              Your Health, <span className="text-gradient">Our Priority</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg">
              Book appointments with top doctors in just a few clicks. Fast, reliable, and secure healthcare at your fingertips.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to={user ? (DASHBOARDS[user.role] || '/') : '/register'}
                onClick={handleBookClick}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 transition-opacity"
              >
                {user ? 'Go to Dashboard' : 'Book Appointment'} <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/doctors" className="inline-flex items-center px-6 py-3 rounded-lg border border-border text-foreground font-medium hover:bg-muted transition-colors">
                Find Doctors
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 pt-4">
              {[{ icon: Calendar, label: 'Easy Booking' }, { icon: Shield, label: '100% Secure' }, { icon: Clock, label: '24/7 Support' }].map((item, i) => (
                <motion.div key={item.label} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + i * 0.1 }} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <item.icon className="w-4 h-4 text-primary" />
                  {item.label}
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.3 }} className="relative hidden lg:block">
            <div className="relative">
              <img src={heroImage} alt="Doctor consulting with patient" className="w-full max-w-lg mx-auto animate-float" />
              <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.8 }} className="absolute -left-4 bottom-20 glass rounded-xl p-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center"><Shield className="w-5 h-5 text-white" /></div>
                  <div><p className="text-xs font-semibold text-foreground">Verified Doctors</p><p className="text-xs text-muted-foreground">500+ Specialists</p></div>
                </div>
              </motion.div>
              <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1 }} className="absolute -right-4 top-20 glass rounded-xl p-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center"><Calendar className="w-5 h-5 text-primary-foreground" /></div>
                  <div><p className="text-xs font-semibold text-foreground">Appointments</p><p className="text-xs text-muted-foreground">10K+ Booked</p></div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
