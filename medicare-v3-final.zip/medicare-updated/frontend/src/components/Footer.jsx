import { Link } from 'react-router-dom';
import { Stethoscope } from 'lucide-react';

const Footer = () => (
  <footer className="bg-card border-t border-border py-12">
    <div className="container mx-auto px-4">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <div>
          <Link to="/" className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Stethoscope className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="text-lg font-heading font-bold text-foreground">
              Medi<span className="text-primary">Care</span>
            </span>
          </Link>
          <p className="text-sm text-muted-foreground">Your trusted partner for healthcare appointments and medical consultations.</p>
        </div>
        <div>
          <h4 className="font-heading font-semibold text-foreground mb-3">Quick Links</h4>
          <div className="flex flex-col gap-2">
            {['Doctors', 'Services', 'About', 'Contact'].map((item) => (
              <Link key={item} to={`/${item.toLowerCase()}`} className="text-sm text-muted-foreground hover:text-primary transition-colors">{item}</Link>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-heading font-semibold text-foreground mb-3">For Users</h4>
          <div className="flex flex-col gap-2">
            {['Patient Login', 'Doctor Login', 'Admin Login', 'Register'].map((item) => (
              <Link key={item} to="/login" className="text-sm text-muted-foreground hover:text-primary transition-colors">{item}</Link>
            ))}
          </div>
        </div>
        <div>
          <h4 className="font-heading font-semibold text-foreground mb-3">Contact</h4>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <p>support@medicare.com</p>
            <p>+91 98765 43210</p>
            <p>Mumbai, India</p>
          </div>
        </div>
      </div>
      <div className="border-t border-border mt-8 pt-6 text-center">
        <p className="text-xs text-muted-foreground">© 2026 MediCare. All rights reserved. Built with ❤️</p>
      </div>
    </div>
  </footer>
);

export default Footer;
