import { useAuth } from '../contexts/AuthContext';
import { Navigate, useNavigate } from 'react-router-dom';
import { ShieldCheck, Heart, LogOut } from 'lucide-react';

const ROLE_DASHBOARDS = {
  admin: '/admin/dashboard',
  doctor: '/doctor/dashboard',
  patient: '/patient/dashboard',
};

const ROLE_LABELS = {
  admin:   { label: 'Admin',   color: 'text-red-600 bg-red-50 border-red-100' },
  doctor:  { label: 'Doctor',  color: 'text-teal-600 bg-teal-50 border-teal-100' },
  patient: { label: 'Patient', color: 'text-blue-600 bg-blue-50 border-blue-100' },
};

const AccessDenied = ({ user }) => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const dashboard = ROLE_DASHBOARDS[user.role];
  const roleInfo = ROLE_LABELS[user.role] || { label: user.role, color: 'text-gray-600 bg-gray-50 border-gray-100' };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="bg-card rounded-3xl border border-border p-8 max-w-sm w-full text-center shadow-xl space-y-5">
        <div className="w-14 h-14 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
          <ShieldCheck className="h-7 w-7 text-destructive" />
        </div>
        <div>
          <h2 className="text-xl font-heading font-bold text-foreground">Access Denied</h2>
          <p className="text-sm text-muted-foreground mt-1">You don't have permission to view this page.</p>
        </div>
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-semibold ${roleInfo.color}`}>
          <Heart className="h-3.5 w-3.5" />
          Logged in as {roleInfo.label}
        </div>
        <div className="space-y-2">
          {dashboard && (
            <button onClick={() => navigate(dashboard)}
              className="w-full h-11 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:opacity-90 transition-opacity">
              Go to {roleInfo.label} Dashboard
            </button>
          )}
          <button onClick={() => { logout(); navigate('/login'); }}
            className="w-full h-11 rounded-xl border border-border text-foreground font-medium text-sm hover:bg-muted transition-colors flex items-center justify-center gap-2">
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </div>
    </div>
  );
};

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-3">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-muted-foreground text-sm">Checking access…</p>
      </div>
    </div>
  );

  if (!user) return <Navigate to="/login" replace />;
  if (!allowedRoles.includes(user.role)) return <AccessDenied user={user} />;

  return <>{children}</>;
};

export default ProtectedRoute;
