/**
 * Unified User Model
 * Single model for all 3 roles: admin | doctor | patient
 * Doctor-specific fields are optional (validated in controller)
 */
const mongoose = require("mongoose");
const bcrypt   = require("bcryptjs");

const SPECIALIZATIONS = [
  "Cardiologist","Dermatologist","Orthopedic","Pediatrician",
  "Neurologist","ENT Specialist","Gynecologist","General Physician",
  "Psychiatrist","Dentist",
];

const userSchema = new mongoose.Schema(
  {
    // ── Common fields (all roles) ──────────────────────────────
    name: {
      type: String, required: [true, "Name is required"],
      trim: true, minlength: [2, "Name must be at least 2 characters"],
    },
    email: {
      type: String, required: [true, "Email is required"],
      unique: true, lowercase: true, trim: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Invalid email format"],
    },
    password: {
      type: String, required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false, // never returned in queries by default
    },
    role: {
      type: String, required: true,
      enum: { values: ["admin","doctor","patient"], message: "{VALUE} is not a valid role" },
    },
    // Status per role:
    // admin   → always "active"
    // doctor  → pending (after register) → active (admin approved) | rejected | blocked
    // patient → active (after register) | blocked (by admin)
    status: {
      type: String, default: "active",
      enum: { values: ["active","pending","rejected","blocked"], message: "{VALUE} is not a valid status" },
    },

    // ── Patient fields ─────────────────────────────────────────
    phone: {
      type: String, trim: true,
      match: [/^\d{10}$/, "Phone must be exactly 10 digits"],
    },

    // ── Doctor fields (optional — validated in controller) ─────
    specialization: {
      type: String,
      enum: { values: SPECIALIZATIONS, message: "{VALUE} is not a valid specialization" },
    },
    consultation_fee: { type: Number, min: [1, "Fee must be at least Rs.1"] },
    experience_years: { type: Number, default: 0, min: [0, "Cannot be negative"], max: [70, "Max 70 years"] },
    rating:           { type: Number, default: 4.0, min: [0, "Min 0"], max: [5, "Max 5"] },
    total_reviews:    { type: Number, default: 0, min: [0, "Min 0"] },
    about:            { type: String, default: "", maxlength: [500, "Max 500 chars"] },

    // ── Password Reset (Token-based) ──────────────────────────
    resetPasswordToken:   { type: String, default: null },  // hashed token stored in DB
    resetPasswordExpires: { type: Date,   default: null },  // 15-min expiry
  },
  { timestamps: true }
);

// Compound index for fast role + status queries
userSchema.index({ role: 1, status: 1 });
userSchema.index({ email: 1 });

// Hash password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Instance method: compare entered password with hash
userSchema.methods.matchPassword = async function (entered) {
  return bcrypt.compare(entered, this.password);
};

module.exports = mongoose.model("User", userSchema);
module.exports.SPECIALIZATIONS = SPECIALIZATIONS;