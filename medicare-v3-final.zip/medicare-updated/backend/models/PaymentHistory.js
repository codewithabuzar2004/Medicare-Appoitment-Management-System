/**
 * PaymentHistory Model
 * Separate table for all payment transactions — both Razorpay and COD
 * One record per payment attempt/completion
 */
const mongoose = require("mongoose");

const paymentHistorySchema = new mongoose.Schema(
  {
    // References
    appointment_id: {
      type: mongoose.Schema.Types.ObjectId, ref: "Appointment",
      required: true,
    },
    patient_id: {
      type: mongoose.Schema.Types.ObjectId, ref: "User",
      required: true,
    },
    doctor_id: {
      type: mongoose.Schema.Types.ObjectId, ref: "User",
      required: true,
    },

    // Payment details
    amount:       { type: Number, required: true },              // in rupees
    currency:     { type: String, default: "INR" },
    paymentMode:  { type: String, enum: ["razorpay","cod"], required: true },
    status:       { type: String, enum: ["pending","success","failed","refunded"], default: "pending" },

    // Razorpay specific (null for COD)
    razorpay_order_id:   { type: String, default: null },
    razorpay_payment_id: { type: String, default: null },

    // Transaction metadata
    description:  { type: String, default: "" },
    failureReason:{ type: String, default: null },
  },
  { timestamps: true }
);

paymentHistorySchema.index({ patient_id: 1, createdAt: -1 });
paymentHistorySchema.index({ appointment_id: 1 });
paymentHistorySchema.index({ razorpay_order_id: 1 });

module.exports = mongoose.model("PaymentHistory", paymentHistorySchema);