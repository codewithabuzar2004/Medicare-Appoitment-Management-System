const mongoose = require("mongoose");

const activityLogSchema = new mongoose.Schema(
  {
    admin_id:  { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    action:    { type: String, required: true },   // e.g. "APPROVED_DOCTOR"
    target_id: { type: mongoose.Schema.Types.ObjectId, default: null },
    target_type: { type: String, default: null },  // "user" | "appointment"
    details:   { type: String, default: "" },
    ip:        { type: String, default: "" },
  },
  { timestamps: true }
);

activityLogSchema.index({ admin_id: 1, createdAt: -1 });

module.exports = mongoose.model("ActivityLog", activityLogSchema);