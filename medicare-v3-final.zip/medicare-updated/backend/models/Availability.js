const mongoose = require("mongoose");

const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];

const availabilitySchema = new mongoose.Schema(
  {
    doctor_id: {
      type: mongoose.Schema.Types.ObjectId, ref: "User",
      required: [true, "Doctor ID is required"],
    },
    day: {
      type: String, required: [true, "Day is required"],
      enum: { values: DAYS, message: "{VALUE} is not a valid day" },
    },
    start_time: {
      type: String, required: [true, "Start time is required"],
      match: [/^\d{2}:\d{2}$/, "Time must be HH:MM format"],
    },
    end_time: {
      type: String, required: [true, "End time is required"],
      match: [/^\d{2}:\d{2}$/, "Time must be HH:MM format"],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Availability", availabilitySchema);