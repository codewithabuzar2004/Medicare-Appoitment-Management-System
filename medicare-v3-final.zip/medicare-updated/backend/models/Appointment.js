const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema(
  {
    patient_id: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: [true, "Patient is required"] },
    doctor_id:  { type: mongoose.Schema.Types.ObjectId, ref: "User", required: [true, "Doctor is required"] },
    appointment_date: { type: Date, required: [true, "Appointment date is required"] },

    status: {
      type: String, default: "pending",
      enum: { values: ["pending","confirmed","completed","cancelled"], message: "{VALUE} is not valid" },
    },
    paymentMode:   { type: String, default: "cod",     enum: { values: ["razorpay","cod"], message: "{VALUE} is not a valid payment mode" } },
    paymentStatus: { type: String, default: "pending", enum: { values: ["pending","paid","failed","refunded"], message: "{VALUE} is not valid" } },

    razorpay_order_id:   { type: String, default: null },
    razorpay_payment_id: { type: String, default: null },
    razorpay_signature:  { type: String, default: null },
    fee_at_booking: { type: Number, default: null },
    notes: { type: String, default: "", maxlength: [300, "Max 300 chars"] },

    // ── Review (patient submits after appointment completed) ──────
    review: {
      rating:    { type: Number, min: 1, max: 5, default: null },
      comment:   { type: String, default: "", maxlength: [500, "Max 500 chars"] },
      createdAt: { type: Date, default: null },
    },
    isReviewed: { type: Boolean, default: false },
  },
  { timestamps: true }
);

appointmentSchema.index({ doctor_id: 1, appointment_date: 1, status: 1 });
appointmentSchema.index({ patient_id: 1, createdAt: -1 });
appointmentSchema.index({ razorpay_order_id: 1 });

module.exports = mongoose.model("Appointment", appointmentSchema);
