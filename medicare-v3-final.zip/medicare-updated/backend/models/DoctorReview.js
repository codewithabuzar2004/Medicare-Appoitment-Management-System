/**
 * DoctorReview Model
 * Patients rate and review doctors after confirmed/completed appointments
 * One review per appointment only — prevents spam
 */
const mongoose = require("mongoose");

const doctorReviewSchema = new mongoose.Schema({
  doctor_id: {
    type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true,
  },
  patient_id: {
    type: mongoose.Schema.Types.ObjectId, ref: "User", required: true,
  },
  appointment_id: {
    type: mongoose.Schema.Types.ObjectId, ref: "Appointment",
    required: true, unique: true,  // ONE review per appointment
  },
  rating: {
    type: Number, required: [true, "Rating is required"],
    min: [1, "Min rating is 1"], max: [5, "Max rating is 5"],
  },
  review: {
    type: String, default: "", trim: true,
    maxlength: [500, "Review cannot exceed 500 characters"],
  },
  isVisible: { type: Boolean, default: true }, // admin can hide inappropriate reviews
}, { timestamps: true });

doctorReviewSchema.index({ doctor_id: 1, createdAt: -1 });
doctorReviewSchema.index({ patient_id: 1 });

module.exports = mongoose.model("DoctorReview", doctorReviewSchema);