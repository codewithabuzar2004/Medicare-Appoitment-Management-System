const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema(
  {
    name:    { type: String, required: [true, "Name is required"], trim: true, minlength: [2, "Min 2 chars"] },
    email:   { type: String, required: [true, "Email is required"], trim: true, match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Invalid email"] },
    subject: { type: String, required: [true, "Subject is required"], trim: true, minlength: [3, "Min 3 chars"] },
    message: { type: String, required: [true, "Message is required"], trim: true, minlength: [10, "Min 10 chars"] },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Contact", contactSchema);