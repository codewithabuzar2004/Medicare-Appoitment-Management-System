const mongoose = require("mongoose");

const medicalRecordSchema = new mongoose.Schema({
  patient_id: {
    type: mongoose.Schema.Types.ObjectId, ref: "User",
    required: true, unique: true, // one health profile per patient
  },

  // Basic health info
  blood_group:  { type: String, default: "", enum: ["A+","A-","B+","B-","AB+","AB-","O+","O-",""] },
  height_cm:    { type: Number, default: null },
  weight_kg:    { type: Number, default: null },
  date_of_birth:{ type: Date,   default: null },

  // Medical history (arrays of strings for simplicity)
  allergies:         { type: [String], default: [] }, // e.g. ["Penicillin","Peanuts"]
  chronic_conditions:{ type: [String], default: [] }, // e.g. ["Diabetes","Hypertension"]
  past_surgeries:    { type: [String], default: [] }, // e.g. ["Appendectomy 2019"]
  current_medicines: { type: [String], default: [] }, // e.g. ["Metformin 500mg"]

  // Emergency contact
  emergency_name:    { type: String, default: "" },
  emergency_phone:   { type: String, default: "" },
  emergency_relation:{ type: String, default: "" }, // e.g. "Spouse", "Parent"

  // Extra notes from doctor
  doctor_notes:      { type: String, default: "", maxlength: 2000 },

  // Last updated by
  last_updated_by:   { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
}, { timestamps: true });

module.exports = mongoose.model("MedicalRecord", medicalRecordSchema);