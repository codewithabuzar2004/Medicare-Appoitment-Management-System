const express = require("express");
const router  = express.Router();
const {
  getProfile, updateProfile,
  getMyAppointments, bookAppointment, cancelAppointment,
  rescheduleAppointment, submitReview,
  getPaymentHistory,
} = require("../controllers/patientController");
const { createReview, getMyReviews, checkReviewed } = require("../controllers/reviewController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.use(protect, authorize("patient"));

router.get ("/profile",  getProfile);
router.put ("/profile",  updateProfile);

router.get ("/appointments",                        getMyAppointments);
router.post("/appointments",                        bookAppointment);
router.put ("/appointments/:id/cancel",             cancelAppointment);
router.put ("/appointments/:id/reschedule",         rescheduleAppointment);
router.post("/appointments/:id/review",             submitReview);

// Also support /api/patient/review (used by some frontend calls)
router.post("/review",                              createReview);
router.get ("/reviews",                             getMyReviews);
router.get ("/review/check/:appointmentId",         checkReviewed);

router.get("/payments", getPaymentHistory);

module.exports = router;
