const express = require("express");
const router  = express.Router();
const { getMyRecord, updateMyRecord, getPatientRecord, addDoctorNotes } = require("../controllers/medicalRecordController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Patient
router.get("/my",                               protect, authorize("patient"), getMyRecord);
router.put("/my",                               protect, authorize("patient"), updateMyRecord);

// Doctor
router.get("/patient/:patientId",               protect, authorize("doctor"),  getPatientRecord);
router.put("/patient/:patientId/notes",         protect, authorize("doctor"),  addDoctorNotes);

module.exports = router;