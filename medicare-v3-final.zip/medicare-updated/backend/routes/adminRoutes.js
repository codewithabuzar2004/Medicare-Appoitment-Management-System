const express = require("express");
const router  = express.Router();
const { getActivityLogs } = require("../controllers/activityLogController");
const { getAllPaymentHistory } = require("../controllers/paymentController");
const {
  getStats,
  getAllPatients, getAllDoctors, getAllAppointments,
  approveDoctor, rejectDoctor,
  toggleUserStatus,
  updateDoctor, updatePatient,
  deleteUser,
  createDoctor, createPatient,
  updateAppointmentStatus,
} = require("../controllers/adminController");
const { protect, adminOnly } = require("../middleware/authMiddleware");

// All admin routes require authentication + admin role
router.use(protect, adminOnly);

// Dashboard
router.get("/stats", getStats);

// Doctors
router.get   ("/doctors",              getAllDoctors);
router.post  ("/doctors",              createDoctor);
router.put   ("/doctors/:id",          updateDoctor);
router.put   ("/doctors/:id/approve",  approveDoctor);   // ← dedicated approve
router.put   ("/doctors/:id/reject",   rejectDoctor);    // ← dedicated reject
router.delete("/doctors/:id",          deleteUser);

// Patients
router.get   ("/patients",             getAllPatients);
router.post  ("/patients",             createPatient);
router.put   ("/patients/:id",         updatePatient);
router.delete("/patients/:id",         deleteUser);

// Any user: block/unblock toggle
router.put("/users/:id/toggle-status", toggleUserStatus);

// Appointments
router.get("/appointments",                     getAllAppointments);
router.put("/appointments/:id/status",          updateAppointmentStatus);

// Activity logs
router.get("/activity-logs", getActivityLogs);

// Payment history (all)
router.get("/payments", getAllPaymentHistory);


// Reviews (all + toggle)
const { getAllReviews, toggleVisibility } = require("../controllers/reviewController");
router.get("/reviews",           getAllReviews);
router.put("/reviews/:id/toggle", toggleVisibility);

module.exports = router;