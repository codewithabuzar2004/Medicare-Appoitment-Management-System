const express = require("express");
const router  = express.Router();
const {
  login, registerPatient, registerDoctor, getMe,
  forgotPassword, resetPassword, verifyResetToken,
} = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");
const validate    = require("../middleware/validate");
const { loginRules, registerPatientRules, registerDoctorRules } = require("../middleware/validationRules");

// ── Public routes ────────────────────────────────────────────────
router.post("/login",            loginRules,           validate, login);
router.post("/register/patient", registerPatientRules, validate, registerPatient);
router.post("/register/doctor",  registerDoctorRules,  validate, registerDoctor);

// ── Forgot Password (token-based reset link) ─────────────────────
// Step 1: User submits email → reset link sent to inbox
router.post("/forgot-password", forgotPassword);
// Step 2: Frontend verifies token validity when reset page loads
router.get ("/reset-password/:token/verify", verifyResetToken);
// Step 3: User submits new password with token
router.post("/reset-password/:token", resetPassword);

// ── Protected ────────────────────────────────────────────────────
router.get("/me", protect, getMe);

module.exports = router;