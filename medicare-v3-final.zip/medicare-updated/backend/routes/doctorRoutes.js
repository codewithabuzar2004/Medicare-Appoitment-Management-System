const express = require("express");
const router  = express.Router();
const {
  getDoctorProfile, updateDoctorProfile,
  getDoctorAppointments, updateAppointmentStatus,
  getAvailability, addAvailability, deleteAvailability,
} = require("../controllers/doctorController");
const { protect, authorize } = require("../middleware/authMiddleware");

// All doctor routes require authentication + doctor role
router.use(protect, authorize("doctor"));

// Profile
router.get("/profile", getDoctorProfile);
router.put("/profile", updateDoctorProfile);

// Appointments
router.get("/appointments",                      getDoctorAppointments);
router.put("/appointments/:id/status",           updateAppointmentStatus);

// Availability
router.get   ("/availability",     getAvailability);
router.post  ("/availability",     addAvailability);
router.delete("/availability/:id", deleteAvailability);

module.exports = router;