const express = require("express");
const router  = express.Router();
const {
  getActiveDoctors, getDoctorById, getDoctorAvailability,
} = require("../controllers/doctorController");

// Public endpoints — no auth required
router.get("/",                    getActiveDoctors);      // search & filter
router.get("/:id",                 getDoctorById);         // single doctor profile
router.get("/:id/availability",    getDoctorAvailability); // doctor's schedule

module.exports = router;