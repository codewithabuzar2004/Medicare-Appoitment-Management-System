const express = require("express");
const router  = express.Router();
const { createReview, getDoctorReviews, getMyReviews, checkReviewed } = require("../controllers/reviewController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public
router.get("/doctor/:doctorId",          getDoctorReviews);

// Patient only
router.post("/",                         protect, authorize("patient"), createReview);
router.get("/my",                        protect, authorize("patient"), getMyReviews);
router.get("/check/:appointmentId",      protect, authorize("patient"), checkReviewed);

module.exports = router;