const express = require("express");
const router  = express.Router();
const {
  createOrder, verifyPayment, paymentFailed,
  getPaymentStatus, getAllPaymentHistory,
} = require("../controllers/paymentController");
const { protect, authorize, adminOnly } = require("../middleware/authMiddleware");

// Patient payment routes
router.post("/create-order",          protect, authorize("patient"), createOrder);
router.post("/verify",                protect, authorize("patient"), verifyPayment);
router.post("/fail",                  protect, authorize("patient"), paymentFailed);
router.get ("/status/:appointmentId", protect, authorize("patient"), getPaymentStatus);

// Admin — all transactions
router.get("/history/all", protect, adminOnly, getAllPaymentHistory);

module.exports = router;