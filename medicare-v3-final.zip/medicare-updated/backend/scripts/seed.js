require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") });
const mongoose = require("mongoose");
const bcrypt   = require("bcryptjs");
const User     = require("../models/User");

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("DB connected");

    // ── ONE Admin ────────────────────────────────────────────────
    const adminExists = await User.findOne({ role: "admin" });
    if (!adminExists) {
      // Plain password — User.create() triggers pre-save hook which hashes it
      await User.create({
        name:     "Admin",
        email:    process.env.ADMIN_EMAIL    || "admin@medicare.com",
        password: process.env.ADMIN_PASSWORD || "admin123",
        role:     "admin",
        status:   "active",
      });
      console.log("✅ Admin created");
      console.log("   Email:   ", process.env.ADMIN_EMAIL    || "admin@medicare.com");
      console.log("   Password:", process.env.ADMIN_PASSWORD || "admin123");
    } else {
      console.log("ℹ️  Admin already exists");
    }

    // ── Sample Doctors ───────────────────────────────────────────
    // insertMany bypasses pre-save, so we hash manually
    const doctorCount = await User.countDocuments({ role: "doctor" });
    if (doctorCount === 0) {
      const hash = (pw) => bcrypt.hash(pw, 12);
      await User.insertMany([
        { name: "Dr. Rajesh Sharma", email: "rajesh@medicare.com", password: await hash("doctor123"), role: "doctor", status: "active", specialization: "Cardiologist",  consultation_fee: 500, experience_years: 12, rating: 4.8, total_reviews: 124, about: "Senior cardiologist." },
        { name: "Dr. Priya Patel",   email: "priya@medicare.com",  password: await hash("doctor123"), role: "doctor", status: "active", specialization: "Dermatologist", consultation_fee: 400, experience_years: 8,  rating: 4.6, total_reviews: 89,  about: "Skin disorder specialist." },
        { name: "Dr. Amit Kumar",    email: "amit@medicare.com",   password: await hash("doctor123"), role: "doctor", status: "active", specialization: "Orthopedic",    consultation_fee: 600, experience_years: 15, rating: 4.9, total_reviews: 201, about: "Bone & joint expert." },
        { name: "Dr. Sneha Gupta",   email: "sneha@medicare.com",  password: await hash("doctor123"), role: "doctor", status: "active", specialization: "Pediatrician",  consultation_fee: 350, experience_years: 6,  rating: 4.7, total_reviews: 67,  about: "Pediatric specialist." },
      ]);
      console.log("✅ 4 sample doctors created");
    } else {
      console.log("ℹ️  Doctors already exist");
    }

    console.log("\n✅ Seed complete!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Seed error:", error.message);
    process.exit(1);
  }
};

seed();