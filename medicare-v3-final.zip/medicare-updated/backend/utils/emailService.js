/**
 * MediCare Email Service
 * Nodemailer + Gmail SMTP
 *
 * Gmail App Password Setup:
 * 1. myaccount.google.com → Security → 2-Step Verification ON
 * 2. Search "App Passwords" → Select Mail → Generate
 * 3. Add to .env:
 *    EMAIL_USER=yourname@gmail.com
 *    EMAIL_PASS=abcd efgh ijkl mnop   ← 16-char app password
 */
const nodemailer = require("nodemailer");

const SITE = () => process.env.FRONTEND_URL || "http://localhost:5173";
const FROM = () =>
  process.env.EMAIL_FROM ||
  `MediCare <${process.env.EMAIL_USER || "noreply@medicare.com"}>`;

// ── Singleton transporter (verify ONCE, reuse forever) ────────────
let _transporter = null;
let _verified    = false;

const getTransporter = async () => {
  if (_transporter && _verified) return _transporter;

  console.log("[Email] Initialising transporter for:", process.env.EMAIL_USER);

  _transporter = nodemailer.createTransport({
    service: "gmail",           // use Gmail service (handles host/port automatically)
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    tls: { rejectUnauthorized: false },
  });

  try {
    await _transporter.verify();
    _verified = true;
    console.log("✅ [Email] Connected successfully →", process.env.EMAIL_USER);
  } catch (err) {
    console.error("❌ [Email] Connection FAILED:", err.message);
    console.error("   Possible causes:");
    console.error("   1. EMAIL_USER or EMAIL_PASS not set correctly in .env");
    console.error("   2. Gmail 2-Step Verification is OFF (must be ON)");
    console.error("   3. Not using App Password (use App Password, not Gmail password)");
    console.error("   4. 'Less secure apps' - irrelevant if using App Password");
    _transporter = null;
    _verified    = false;
  }

  return _transporter;
};

// ── Main send function ────────────────────────────────────────────
const sendEmail = async ({ to, subject, html }) => {
  // Guard: credentials not set (default placeholder values)
  const user = process.env.EMAIL_USER || "";
  const pass = process.env.EMAIL_PASS || "";
  if (
    !user || !pass ||
    user === "your_gmail@gmail.com" ||
    user === "your-email@gmail.com" ||
    pass === "xxxx xxxx xxxx xxxx" ||
    pass === "your-app-password"
  ) {
    console.log(`[Email] SKIPPED (credentials not configured) → ${to} | ${subject}`);
    return { skipped: true };
  }

  try {
    const transporter = await getTransporter();
    if (!transporter) {
      console.error(`[Email] FAILED (transporter unavailable) → ${to}`);
      return { success: false, error: "Email transporter could not connect. Check credentials." };
    }

    console.log(`[Email] Sending → ${to} | ${subject}`);
    const info = await transporter.sendMail({ from: FROM(), to, subject, html });
    console.log(`✅ [Email] Sent → ${to} | MessageId: ${info.messageId}`);
    return { success: true, messageId: info.messageId };

  } catch (err) {
    console.error(`❌ [Email] Send FAILED → ${to}:`, err.message);
    // Reset so next call re-verifies
    _transporter = null;
    _verified    = false;
    return { success: false, error: err.message };
  }
};

// ── Shared HTML helpers ───────────────────────────────────────────
const baseWrap = (body) => `<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#f4f6f8;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:32px 16px;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0"
      style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
      <!-- HEADER -->
      <tr><td style="background:linear-gradient(135deg,#4f46e5,#7c3aed);padding:28px 32px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:22px;font-weight:700;letter-spacing:-0.5px;">🏥 MediCare</h1>
        <p style="color:rgba(255,255,255,0.8);margin:4px 0 0;font-size:13px;">Your Health, Our Priority</p>
      </td></tr>
      <!-- BODY -->
      <tr><td style="padding:32px;">${body}</td></tr>
      <!-- FOOTER -->
      <tr><td style="background:#f8fafc;padding:20px 32px;border-top:1px solid #e8ecf0;text-align:center;">
        <p style="color:#94a3b8;font-size:12px;margin:0;">
          © ${new Date().getFullYear()} MediCare. This is an automated email — please do not reply.
        </p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`;

const btn = (href, label, color = "#4f46e5") =>
  `<div style="text-align:center;margin:24px 0;">
    <a href="${href}"
      style="display:inline-block;background:${color};color:#fff;padding:13px 32px;
             border-radius:8px;text-decoration:none;font-size:15px;font-weight:600;">
      ${label}
    </a>
  </div>`;

const infoCard = (rows) =>
  `<div style="background:#f1f5f9;border-radius:8px;padding:16px 20px;margin:16px 0;">
    <table width="100%" cellpadding="0" cellspacing="0">
      ${rows.map(([k, v]) =>
        `<tr>
          <td style="padding:5px 0;color:#64748b;font-size:14px;width:140px;">${k}</td>
          <td style="padding:5px 0;color:#1e293b;font-size:14px;font-weight:600;">${v}</td>
        </tr>`
      ).join("")}
    </table>
  </div>`;

// ── Email Templates ───────────────────────────────────────────────
const emailTemplates = {

  // 1. Patient welcome
  welcomePatient: (name) => ({
    subject: "👋 Welcome to MediCare!",
    html: baseWrap(`
      <h2 style="color:#1e293b;margin:0 0 12px;">Welcome, ${name}! 🎉</h2>
      <p style="color:#475569;line-height:1.6;">Your MediCare patient account is ready. You can now:</p>
      <ul style="color:#475569;line-height:2;padding-left:20px;">
        <li>Browse and book appointments with verified doctors</li>
        <li>Pay online via Razorpay or pay at clinic</li>
        <li>Track appointments in real-time</li>
      </ul>
      ${btn(SITE() + "/patient/dashboard", "Go to Dashboard")}
    `),
  }),

  // 2. Doctor registration received
  doctorRegistered: (name) => ({
    subject: "📋 Registration Received — MediCare",
    html: baseWrap(`
      <h2 style="color:#1e293b;margin:0 0 12px;">Thank you, Dr. ${name}!</h2>
      <p style="color:#475569;line-height:1.6;">
        Your registration is <strong>pending admin review</strong>. You will receive an email once approved (usually 1–2 business days).
      </p>
      ${infoCard([["Status", "⏳ Pending Review"], ["Next Step", "Wait for approval email"]])}
    `),
  }),

  // 3. Doctor approved
  doctorApproved: (name) => ({
    subject: "🎉 Account Approved — MediCare",
    html: baseWrap(`
      <h2 style="color:#16a34a;margin:0 0 12px;">Congratulations, Dr. ${name}! 🎉</h2>
      <p style="color:#475569;line-height:1.6;">
        Your doctor account has been <strong style="color:#16a34a;">approved!</strong>
        You can now login and accept patient appointments.
      </p>
      ${btn(SITE() + "/login?role=doctor", "Login to Dashboard", "#16a34a")}
    `),
  }),

  // 4. Doctor rejected
  doctorRejected: (name, reason = "") => ({
    subject: "MediCare — Registration Update",
    html: baseWrap(`
      <h2 style="color:#dc2626;margin:0 0 12px;">Registration Not Approved</h2>
      <p style="color:#475569;line-height:1.6;">Dear Dr. ${name},</p>
      <p style="color:#475569;line-height:1.6;">
        After reviewing your application, we are unable to approve it at this time.
        ${reason ? `<br><strong>Reason:</strong> ${reason}` : ""}
      </p>
      <p style="color:#475569;">Please contact our support team for assistance.</p>
    `),
  }),

  // 5. Appointment confirmed (Razorpay)
  appointmentConfirmed: (patientName, doctorName, date, fee) => ({
    subject: "✅ Appointment Confirmed — MediCare",
    html: baseWrap(`
      <h2 style="color:#16a34a;margin:0 0 12px;">Appointment Confirmed ✅</h2>
      <p style="color:#475569;">Dear <strong>${patientName}</strong>, your appointment is confirmed.</p>
      ${infoCard([
        ["Doctor", "Dr. " + doctorName],
        ["Date & Time", date],
        ["Fee Paid", "₹" + fee],
        ["Payment", "✓ Online — Confirmed"],
      ])}
      <p style="color:#475569;font-size:13px;">📍 Please arrive <strong>10 minutes early</strong>.</p>
      ${btn(SITE() + "/patient/dashboard", "View Appointment")}
    `),
  }),

  // 6. Appointment booked (COD)
  appointmentBookedCOD: (patientName, doctorName, date, fee) => ({
    subject: "📅 Appointment Booked — MediCare",
    html: baseWrap(`
      <h2 style="color:#4f46e5;margin:0 0 12px;">Appointment Booked 📅</h2>
      <p style="color:#475569;">Dear <strong>${patientName}</strong>, your appointment is booked.</p>
      ${infoCard([
        ["Doctor", "Dr. " + doctorName],
        ["Date & Time", date],
        ["Fee", "₹" + fee],
        ["Payment", "💵 Pay at Clinic"],
      ])}
      <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px;margin:12px 0;">
        <p style="margin:0;color:#92400e;font-size:13px;">⚠️ Please carry <strong>₹${fee}</strong> to pay at the clinic on appointment day.</p>
      </div>
      ${btn(SITE() + "/patient/dashboard", "View Dashboard")}
    `),
  }),

  // 7. Appointment cancelled
  appointmentCancelled: (patientName, doctorName, date) => ({
    subject: "❌ Appointment Cancelled — MediCare",
    html: baseWrap(`
      <h2 style="color:#dc2626;margin:0 0 12px;">Appointment Cancelled</h2>
      <p style="color:#475569;">Dear <strong>${patientName}</strong>, your appointment has been cancelled.</p>
      ${infoCard([["Doctor", "Dr. " + doctorName], ["Date", date], ["Status", "Cancelled"]])}
      <p style="color:#475569;font-size:13px;">If you paid online, a refund will be processed within 5–7 business days.</p>
      ${btn(SITE() + "/patient/dashboard", "Book New Appointment", "#dc2626")}
    `),
  }),

  // 8. Appointment rescheduled
  appointmentRescheduled: (patientName, doctorName, oldDate, newDate) => ({
    subject: "📅 Appointment Rescheduled — MediCare",
    html: baseWrap(`
      <h2 style="color:#f59e0b;margin:0 0 12px;">Appointment Rescheduled 📅</h2>
      <p style="color:#475569;">Dear <strong>${patientName}</strong>, your appointment has been rescheduled.</p>
      ${infoCard([
        ["Doctor", "Dr. " + doctorName],
        ["Previous Date", "<s style=\"color:#94a3b8;\">" + oldDate + "</s>"],
        ["New Date", "<strong style=\"color:#16a34a;\">" + newDate + "</strong>"],
      ])}
      ${btn(SITE() + "/patient/dashboard", "View Appointment", "#f59e0b")}
    `),
  }),

  // 9. Appointment status updated by doctor
  appointmentStatusUpdate: (patientName, doctorName, date, status) => ({
    subject: `Appointment ${status.charAt(0).toUpperCase() + status.slice(1)} — MediCare`,
    html: baseWrap(`
      <h2 style="color:#4f46e5;margin:0 0 12px;">Appointment Update</h2>
      <p style="color:#475569;">Dear <strong>${patientName}</strong>, your appointment status has been updated.</p>
      ${infoCard([
        ["Doctor", "Dr. " + doctorName],
        ["Date", date],
        ["Status", "<strong style=\"text-transform:capitalize;\">" + status + "</strong>"],
      ])}
      ${btn(SITE() + "/patient/dashboard", "View Dashboard")}
    `),
  }),

  // 10. Contact form — to sender
  contactFormSent: (name) => ({
    subject: "✉️ Message Received — MediCare",
    html: baseWrap(`
      <h2 style="color:#1e293b;margin:0 0 12px;">Message Received, ${name}!</h2>
      <p style="color:#475569;line-height:1.6;">
        Thank you for reaching out. Our team will respond within 24 hours.
      </p>
    `),
  }),

  // 11. Contact form — to admin
  contactFormAdmin: (name, email, subject, message) => ({
    subject: `📩 Contact: ${subject}`,
    html: baseWrap(`
      <h2 style="color:#1e293b;margin:0 0 12px;">New Contact Message</h2>
      ${infoCard([["From", name], ["Email", email], ["Subject", subject]])}
      <div style="background:#f8fafc;border-left:4px solid #4f46e5;border-radius:4px;padding:12px 16px;margin:12px 0;">
        <p style="color:#374151;font-size:14px;line-height:1.6;margin:0;">${message}</p>
      </div>
    `),
  }),

    // 12. Password Reset — secure link
  resetPasswordLink: (name, resetUrl, expiresMin = 15) => ({
    subject: "🔐 Reset Your MediCare Password",
    html: baseWrap(`
      <h2 style="color:#1e293b;margin:0 0 8px;">Password Reset Request</h2>
      <p style="color:#475569;margin:0 0 24px;">
        Hi <strong>${name}</strong>, we received a request to reset your MediCare password.
        Click the button below to set a new password.
      </p>
      ${btn(resetUrl, "Reset My Password")}
      <div style="background:#f1f5f9;border-radius:8px;padding:14px 16px;margin:20px 0;text-align:center;">
        <p style="margin:0;color:#64748b;font-size:13px;">
          ⏱ This link expires in <strong>${expiresMin} minutes</strong>
        </p>
        <p style="margin:6px 0 0;color:#94a3b8;font-size:11px;word-break:break-all;">${resetUrl}</p>
      </div>
      <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:14px 16px;">
        <p style="margin:0;color:#991b1b;font-size:13px;line-height:1.5;">
          🚨 <strong>Didn't request this?</strong> Ignore this email —
          your password will not change and the link will expire automatically.
        </p>
      </div>
    `),
  }),

};

module.exports = { sendEmail, emailTemplates };
