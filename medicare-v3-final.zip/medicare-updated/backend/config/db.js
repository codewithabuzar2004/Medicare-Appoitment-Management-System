const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      // Keep connection alive — prevents "registration failed after 5-10 min"
      serverSelectionTimeoutMS: 10000,   // 10s to find a server
      socketTimeoutMS:          45000,   // 45s socket idle before closing
      connectTimeoutMS:         10000,   // 10s to establish initial connection
      maxPoolSize:              10,      // max 10 concurrent connections
      minPoolSize:              2,       // keep 2 connections always warm
      heartbeatFrequencyMS:    10000,   // ping server every 10s to stay alive
      retryWrites:              true,
      retryReads:               true,
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

    // Auto-reconnect on disconnect
    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️  MongoDB disconnected — attempting reconnect...');
      setTimeout(() => connectDB(), 3000);
    });

    mongoose.connection.on('error', (err) => {
      console.error('❌ MongoDB error:', err.message);
    });

  } catch (error) {
    console.error(`❌ MongoDB connection failed: ${error.message}`);
    // Retry after 5 seconds instead of killing the process
    console.log('🔄 Retrying in 5 seconds...');
    setTimeout(() => connectDB(), 5000);
  }
};

module.exports = connectDB;
