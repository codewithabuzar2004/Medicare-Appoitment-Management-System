const { body } = require("express-validator");
const { SPECIALIZATIONS } = require("../models/User");

const loginRules = [
  body("email").isEmail().withMessage("Valid email is required").normalizeEmail(),
  body("password").notEmpty().withMessage("Password is required"),
  body("role").isIn(["admin","doctor","patient"]).withMessage("Role must be admin, doctor or patient"),
];

const registerPatientRules = [
  body("name").trim().isLength({ min: 2 }).withMessage("Name must be at least 2 characters"),
  body("email").isEmail().withMessage("Valid email is required").normalizeEmail(),
  body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  body("phone").matches(/^\d{10}$/).withMessage("Phone must be exactly 10 digits"),
];

const registerDoctorRules = [
  body("name").trim().isLength({ min: 2 }).withMessage("Doctor name must be at least 2 characters"),
  body("email").isEmail().withMessage("Valid email is required").normalizeEmail(),
  body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  body("specialization").isIn(SPECIALIZATIONS).withMessage("Invalid specialization"),
  body("consultation_fee").isInt({ min: 1 }).withMessage("Consultation fee must be at least Rs.1"),
  body("experience_years").optional().isInt({ min: 0, max: 70 }).withMessage("Experience must be 0-70 years"),
];

module.exports = { loginRules, registerPatientRules, registerDoctorRules };