const jwt  = require("jsonwebtoken");
const User = require("../models/User");

/**
 * protect — verifies JWT and attaches user to req.user
 * Blocks: expired tokens, pending doctors, blocked accounts
 */
const protect = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ success: false, message: "Not authorized, no token" });
  }

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch fresh user from DB (ensures status changes are reflected immediately)
    const user = await User.findById(decoded.id).select("-password");
    if (!user) {
      return res.status(401).json({ success: false, message: "User not found, token invalid" });
    }

    // Doctor must be approved before any API access
    if (user.role === "doctor" && user.status === "pending") {
      return res.status(403).json({
        success: false,
        message: "Your account is pending admin approval. You cannot access this resource yet.",
      });
    }
    if (user.role === "doctor" && user.status === "rejected") {
      return res.status(403).json({
        success: false,
        message: "Your registration has been rejected. Please contact admin.",
      });
    }

    // Blocked accounts: no API access regardless of role
    if (user.status === "blocked") {
      return res.status(403).json({
        success: false,
        message: "Your account has been blocked. Please contact admin.",
      });
    }

    req.user = user; // user object (no password) with role attached
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({ success: false, message: "Session expired, please login again" });
    }
    res.status(401).json({ success: false, message: "Not authorized, token invalid" });
  }
};

/**
 * authorize(...roles) — role-based access control middleware
 * Usage: authorize("admin"), authorize("admin","doctor")
 */
const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({
      success: false,
      message: `Access denied. This action requires role: ${roles.join(" or ")}`,
    });
  }
  next();
};

/**
 * adminOnly — shorthand for authorize("admin")
 */
const adminOnly = authorize("admin");

module.exports = { protect, authorize, adminOnly };