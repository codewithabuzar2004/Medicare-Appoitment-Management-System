/**
 * Converts raw Mongoose/MongoDB errors into user-friendly messages
 */
const parseError = (error) => {
  // Duplicate key (E11000)
  if (error.code === 11000) {
    const field = Object.keys(error.keyValue || {})[0] || "field";
    const value = error.keyValue?.[field];
    return `${field.charAt(0).toUpperCase() + field.slice(1)} "${value}" is already registered`;
  }
  // Validation error
  if (error.name === "ValidationError") {
    const messages = Object.values(error.errors).map((e) => e.message);
    return messages[0] || "Validation failed";
  }
  // CastError (bad ObjectId)
  if (error.name === "CastError") return "Invalid ID format";

  return error.message || "Something went wrong";
};

module.exports = parseError;