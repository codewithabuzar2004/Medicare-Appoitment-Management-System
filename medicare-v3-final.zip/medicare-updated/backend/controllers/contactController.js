const Contact    = require("../models/Contact");
const parseError = require("../middleware/parseError");
const { sendEmail, emailTemplates } = require("../utils/emailService");

const createMessage = async (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ success: false, message: "All fields are required" });
  }
  try {
    await Contact.create({ name, email, subject, message });

    // Email 1: confirmation to sender (fire-and-forget)
    sendEmail({ to: email, ...emailTemplates.contactFormSent(name) });

    // Email 2: notify admin (fire-and-forget)
    if (process.env.ADMIN_EMAIL) {
      sendEmail({ to: process.env.ADMIN_EMAIL, ...emailTemplates.contactFormAdmin(name, email, subject, message) });
    }

    res.status(201).json({ success: true, message: "Message sent successfully! We'll get back to you within 24 hours." });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

module.exports = { createMessage };
