const ActivityLog = require("../models/ActivityLog");

// Log an admin action (called internally from adminController)
const logAction = async ({ admin_id, action, target_id = null, target_type = null, details = "", ip = "" }) => {
  try {
    await ActivityLog.create({ admin_id, action, target_id, target_type, details, ip });
  } catch { /* silently ignore logging errors */ }
};

// GET /api/admin/activity-logs
const getActivityLogs = async (req, res) => {
  try {
    const { page = 1, limit = 30 } = req.query;
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await ActivityLog.countDocuments();
    const logs  = await ActivityLog.find()
      .populate("admin_id", "name email")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));
    res.json({ success: true, total, page: Number(page), logs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { logAction, getActivityLogs };