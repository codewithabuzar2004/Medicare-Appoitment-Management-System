const MedicalRecord = require("../models/MedicalRecord");
const parseError    = require("../middleware/parseError");

// ── Patient: Get own medical record ─────────────────────────────
// GET /api/medical-records/my
const getMyRecord = async (req, res) => {
  try {
    let record = await MedicalRecord.findOne({ patient_id: req.user._id });
    if (!record) {
      // Auto-create empty record on first fetch
      record = await MedicalRecord.create({ patient_id: req.user._id });
    }
    res.json({ success: true, record });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Patient: Update own medical record ──────────────────────────
// PUT /api/medical-records/my
const updateMyRecord = async (req, res) => {
  const allowed = [
    "blood_group","height_cm","weight_kg","date_of_birth",
    "allergies","chronic_conditions","past_surgeries","current_medicines",
    "emergency_name","emergency_phone","emergency_relation",
  ];
  const update = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) update[k] = req.body[k]; });

  try {
    const record = await MedicalRecord.findOneAndUpdate(
      { patient_id: req.user._id },
      { ...update, last_updated_by: req.user._id },
      { new: true, upsert: true, runValidators: true }
    );
    res.json({ success: true, record, message: "Medical record updated successfully" });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── Doctor: View patient medical record (for appointed patients) ─
// GET /api/medical-records/patient/:patientId
const getPatientRecord = async (req, res) => {
  try {
    const Appointment = require("../models/Appointment");
    // Verify doctor has/had appointment with this patient
    const hasAppt = await Appointment.findOne({
      doctor_id:  req.user._id,
      patient_id: req.params.patientId,
      status:     { $in: ["confirmed", "completed", "pending"] },
    });
    if (!hasAppt) {
      return res.status(403).json({
        success: false,
        message: "You can only view medical records of your appointed patients.",
      });
    }

    let record = await MedicalRecord.findOne({ patient_id: req.params.patientId });
    if (!record) {
      return res.json({ success: true, record: null, message: "Patient has not set up their medical record yet." });
    }
    res.json({ success: true, record });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Doctor: Add notes to patient record ─────────────────────────
// PUT /api/medical-records/patient/:patientId/notes
const addDoctorNotes = async (req, res) => {
  const { doctor_notes } = req.body;
  if (!doctor_notes?.trim()) {
    return res.status(400).json({ success: false, message: "Notes are required" });
  }
  try {
    const record = await MedicalRecord.findOneAndUpdate(
      { patient_id: req.params.patientId },
      { doctor_notes: doctor_notes.trim(), last_updated_by: req.user._id },
      { new: true, upsert: true }
    );
    res.json({ success: true, record, message: "Notes saved" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Admin: Get all medical records ──────────────────────────────
// GET /api/admin/medical-records
const getAllRecords = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await MedicalRecord.countDocuments();
    const records = await MedicalRecord.find()
      .populate("patient_id", "name email phone")
      .sort({ updatedAt: -1 })
      .skip(skip)
      .limit(Number(limit));
    res.json({ success: true, total, page: Number(page), records });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { getMyRecord, updateMyRecord, getPatientRecord, addDoctorNotes, getAllRecords };