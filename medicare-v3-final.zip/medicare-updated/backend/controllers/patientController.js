/**
 * Patient Controller
 * Routes: /api/patient/* (requires role: patient)
 */
const User           = require("../models/User");
const Appointment    = require("../models/Appointment");
const PaymentHistory = require("../models/PaymentHistory");
const parseError     = require("../middleware/parseError");
const { sendEmail, emailTemplates } = require("../utils/emailService");

const IST_OFFSET = 5.5 * 60 * 60 * 1000;
const getISTHour     = (date) => new Date(date.getTime() + IST_OFFSET).getUTCHours();
const fmtIST         = (date) => new Date(date).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day:"2-digit", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit" });
const getISTDayBounds = (date) => {
  const s = new Date(date.getTime() + IST_OFFSET).toISOString().split("T")[0];
  return { dayStart: new Date(`${s}T00:00:00+05:30`), dayEnd: new Date(`${s}T23:59:59+05:30`) };
};

// GET /api/patient/profile
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password");
    res.json({ success: true, user });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// PUT /api/patient/profile
const updateProfile = async (req, res) => {
  try {
    const { password, role, status, ...updateData } = req.body;
    if (password) {
      updateData.password = await require("bcryptjs").hash(password, 12);
    }
    const user = await User.findByIdAndUpdate(req.user._id, updateData, { new: true, runValidators: true }).select("-password");
    res.json({ success: true, user });
  } catch (e) { res.status(400).json({ success: false, message: parseError(e) }); }
};

// GET /api/patient/appointments
const getMyAppointments = async (req, res) => {
  try {
    const { status } = req.query;
    const query = { patient_id: req.user._id };
    if (status) query.status = status;
    const appointments = await Appointment.find(query)
      .populate("doctor_id", "name specialization consultation_fee email experience_years rating")
      .sort({ createdAt: -1 });
    res.json({ success: true, appointments });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// POST /api/patient/appointments  (Online payment only — COD removed)
const bookAppointment = async (req, res) => {
  const { doctor_id, appointment_date } = req.body;
  const patient_id = req.user._id.toString();
  if (!doctor_id || !appointment_date)
    return res.status(400).json({ success: false, message: "doctor_id and appointment_date are required" });

  const apptDate = new Date(appointment_date);
  if (apptDate <= new Date())
    return res.status(400).json({ success: false, message: "Appointment date must be in the future" });
  const istHour = getISTHour(apptDate);
  // Clinic hours: 9:00 AM – 7:00 PM IST only
  if (istHour < 9 || istHour >= 19) {
    return res.status(400).json({
      success: false,
      message: "Appointments can only be booked between 9:00 AM and 7:00 PM IST.",
    });
  }

  try {
    const doctor = await User.findOne({ _id: doctor_id, role: "doctor", status: "active" });
    if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found or not available" });
    const patient = await User.findById(patient_id);

    // Check if this patient already has an appointment with this doctor on this day
    const { dayStart, dayEnd } = getISTDayBounds(apptDate);
    const dup = await Appointment.findOne({ patient_id, doctor_id, status: { $in: ["pending","confirmed"] }, appointment_date: { $gte: dayStart, $lte: dayEnd } });
    if (dup) return res.status(400).json({
      success: false,
      errorCode: "PATIENT_ALREADY_BOOKED",
      message: "You already have an appointment with this doctor on this day.",
    });

    // Check if another patient already booked this exact time slot with this doctor
    const conflict = await Appointment.findOne({ doctor_id, status: { $in: ["pending","confirmed"] }, appointment_date: apptDate });
    if (conflict) {
      return res.status(400).json({
        success: false,
        errorCode: "SLOT_ALREADY_BOOKED",
        message: "This time slot is already booked by another patient. Please select a different time.",
      });
    }

    // This route is used only for online payment — redirect to /api/payment/create-order for Razorpay
    return res.status(400).json({
      success: false,
      message: "Please use online payment to book appointments.",
    });
  } catch (e) { res.status(500).json({ success: false, message: parseError(e) }); }
};

// PUT /api/patient/appointments/:id/cancel
const cancelAppointment = async (req, res) => {
  try {
    const appt = await Appointment.findOne({ _id: req.params.id, patient_id: req.user._id })
      .populate("doctor_id", "name email");
    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });
    if (!["pending","confirmed"].includes(appt.status))
      return res.status(400).json({ success: false, message: "This appointment cannot be cancelled." });

    appt.status        = "cancelled";
    appt.paymentStatus = appt.paymentStatus === "paid" ? "refunded" : "failed";
    await appt.save();

    // Update PaymentHistory — mark as refunded if was paid
    await PaymentHistory.findOneAndUpdate(
      { appointment_id: appt._id },
      {
        status:        appt.paymentStatus,
        failureReason: "Cancelled by patient",
      }
    );

    const patient = await User.findById(req.user._id);
    if (patient && appt.doctor_id) {
      sendEmail({ to: patient.email, ...emailTemplates.appointmentCancelled(patient.name, appt.doctor_id.name, fmtIST(appt.appointment_date)) });
    }

    const io = req.app.get("io");
    if (io) {
      io.to(`doctor_${appt.doctor_id._id}`).emit("refresh", { reason: "appointment_cancelled" });
      io.to("admin").emit("refresh", { reason: "appointment_cancelled" });
    }
    res.json({ success: true, appointment: appt });
  } catch (e) { res.status(500).json({ success: false, message: parseError(e) }); }
};

// ── NEW FEATURE 1: Reschedule Appointment ────────────────────────
// PUT /api/patient/appointments/:id/reschedule
const rescheduleAppointment = async (req, res) => {
  const { new_date } = req.body;
  if (!new_date) return res.status(400).json({ success: false, message: "new_date is required" });

  const newDate = new Date(new_date);
  if (isNaN(newDate)) return res.status(400).json({ success: false, message: "Invalid date format" });
  if (newDate <= new Date()) return res.status(400).json({ success: false, message: "New date must be in the future" });

  const istHour = getISTHour(newDate);
  if (istHour < 9 || istHour >= 19) {
    return res.status(400).json({
      success: false,
      message: "Appointments can only be rescheduled between 9:00 AM and 7:00 PM IST.",
    });
  }

  try {
    const appt = await Appointment.findOne({ _id: req.params.id, patient_id: req.user._id })
      .populate("doctor_id", "name email");
    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });
    if (appt.status !== "pending")
      return res.status(400).json({ success: false, message: "Only pending appointments can be rescheduled." });

    // Check new slot is not already taken
    const conflict = await Appointment.findOne({
      doctor_id: appt.doctor_id._id,
      status: { $in: ["pending","confirmed"] },
      appointment_date: newDate,
      _id: { $ne: appt._id },
    });
    if (conflict) return res.status(400).json({ success: false, message: "This new time slot is already booked. Please choose another." });

    const oldDate = appt.appointment_date;
    appt.appointment_date = newDate;
    await appt.save();

    // Send reschedule email
    const patient = await User.findById(req.user._id);
    if (patient && appt.doctor_id) {
      sendEmail({ to: patient.email, ...emailTemplates.appointmentRescheduled(patient.name, appt.doctor_id.name, fmtIST(oldDate), fmtIST(newDate)) });
    }

    const io = req.app.get("io");
    if (io) {
      io.to(`doctor_${appt.doctor_id._id}`).emit("refresh", { reason: "appointment_rescheduled" });
      io.to("admin").emit("refresh", { reason: "appointment_rescheduled" });
    }
    res.json({ success: true, message: "Appointment rescheduled successfully.", appointment: appt });
  } catch (e) { res.status(500).json({ success: false, message: parseError(e) }); }
};

// ── NEW FEATURE 2: Submit Doctor Review ──────────────────────────
// POST /api/patient/appointments/:id/review
const submitReview = async (req, res) => {
  const { rating, comment } = req.body;
  if (!rating || rating < 1 || rating > 5)
    return res.status(400).json({ success: false, message: "Rating must be between 1 and 5" });

  try {
    const appt = await Appointment.findOne({ _id: req.params.id, patient_id: req.user._id });
    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });
    if (appt.status !== "completed")
      return res.status(400).json({ success: false, message: "You can only review completed appointments." });
    if (appt.isReviewed)
      return res.status(400).json({ success: false, message: "You have already reviewed this appointment." });

    appt.review    = { rating: Number(rating), comment: comment?.trim() || "", createdAt: new Date() };
    appt.isReviewed = true;
    await appt.save();

    // Recalculate doctor's average rating
    const reviews = await Appointment.find({ doctor_id: appt.doctor_id, isReviewed: true, "review.rating": { $exists: true, $ne: null } });
    const avgRating    = reviews.reduce((s, r) => s + r.review.rating, 0) / reviews.length;
    await User.findByIdAndUpdate(appt.doctor_id, { rating: Math.round(avgRating * 10) / 10, total_reviews: reviews.length });

    const io = req.app.get("io");
    if (io) {
      io.to(`doctor_${appt.doctor_id}`).emit("refresh", { reason: "new_review" });
      io.to("admin").emit("refresh", { reason: "new_review" });
    }
    res.json({ success: true, message: "Review submitted successfully. Thank you!" });
  } catch (e) { res.status(500).json({ success: false, message: parseError(e) }); }
};

// GET /api/patient/payments
const getPaymentHistory = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await PaymentHistory.countDocuments({ patient_id: req.user._id });
    const payments = await PaymentHistory.find({ patient_id: req.user._id })
      .populate("appointment_id", "appointment_date status paymentStatus paymentMode")
      .populate("doctor_id", "name specialization")
      .sort({ createdAt: -1 })
      .skip(skip).limit(Number(limit));
    res.json({ success: true, total, page: Number(page), payments });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

module.exports = {
  getProfile, updateProfile,
  getMyAppointments, bookAppointment, cancelAppointment,
  rescheduleAppointment, submitReview,
  getPaymentHistory,
};
