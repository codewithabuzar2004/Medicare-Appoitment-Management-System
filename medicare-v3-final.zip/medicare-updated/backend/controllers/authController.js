const jwt        = require("jsonwebtoken");
const User       = require("../models/User");
const parseError = require("../middleware/parseError");
const { sendEmail, emailTemplates } = require("../utils/emailService");

const generateToken = (id, role) =>
  jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: "7d" });

const sendAuthResponse = (res, statusCode, user, token) => {
  const u = user.toObject ? user.toObject() : { ...user };
  delete u.password;
  res.status(statusCode).json({
    success: true, token,
    user: {
      _id: u._id, name: u.name, email: u.email, role: u.role, status: u.status,
      phone: u.phone, specialization: u.specialization,
      consultation_fee: u.consultation_fee, experience_years: u.experience_years,
      rating: u.rating, total_reviews: u.total_reviews, about: u.about,
    },
  });
};

// POST /api/auth/login
const login = async (req, res) => {
  const { email, password, role } = req.body;
  try {
    const user = await User.findOne({ email: email.toLowerCase().trim(), role }).select("+password");
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ success: false, message: "Invalid email or password" });
    }
    if (role === "doctor" && user.status === "pending") {
      return res.status(403).json({ success: false, message: "Your registration is pending admin approval." });
    }
    if (role === "doctor" && user.status === "rejected") {
      return res.status(403).json({ success: false, message: "Your registration has been rejected. Contact admin." });
    }
    if (user.status === "blocked") {
      return res.status(403).json({ success: false, message: "Your account has been blocked. Contact admin." });
    }
    sendAuthResponse(res, 200, user, generateToken(user._id, user.role));
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// POST /api/auth/register/patient
const registerPatient = async (req, res) => {
  const { name, email, password, phone } = req.body;
  try {
    const exists = await User.findOne({ email: email.toLowerCase().trim() });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });

    const user  = await User.create({ name, email, password, phone, role: "patient", status: "active" });
    const token = generateToken(user._id, "patient");

    // Welcome email (fire-and-forget)
    sendEmail({ to: user.email, ...emailTemplates.welcomePatient(user.name) });

    const io = req.app.get("io");
    if (io) io.to("admin").emit("refresh", { reason: "new_patient_registered" });

    sendAuthResponse(res, 201, user, token);
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// POST /api/auth/register/doctor
const registerDoctor = async (req, res) => {
  const { name, email, password, specialization, consultation_fee, experience_years, about } = req.body;
  try {
    const exists = await User.findOne({ email: email.toLowerCase().trim() });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });

    const doctor = await User.create({
      name, email, password, role: "doctor", status: "pending",
      specialization, consultation_fee: Number(consultation_fee),
      experience_years: Number(experience_years) || 0,
      about: about?.trim() || "",
    });

    // Notify doctor: registration received
    sendEmail({ to: doctor.email, ...emailTemplates.doctorRegistered(doctor.name) });

    const io = req.app.get("io");
    if (io) io.to("admin").emit("refresh", { reason: "new_doctor_registered" });

    res.status(201).json({
      success: true, pending: true,
      message: "Registration submitted! Your account is pending admin approval. You will receive an email once approved.",
    });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// GET /api/auth/me
const getMe = async (req, res) => {
  const u = req.user;
  res.json({
    success: true,
    user: {
      _id: u._id, name: u.name, email: u.email, role: u.role, status: u.status,
      phone: u.phone, specialization: u.specialization,
      consultation_fee: u.consultation_fee, experience_years: u.experience_years,
      rating: u.rating, total_reviews: u.total_reviews, about: u.about,
    },
  });
};

// ── FORGOT PASSWORD ─────────────────────────────────────────────
// POST /api/auth/forgot-password
// User enters email → generate secure token → send reset link via email
const forgotPassword = async (req, res) => {
  const { email } = req.body;

  if (!email?.trim()) {
    return res.status(400).json({ success: false, message: "Email is required" });
  }

  try {
    const user = await User.findOne({ email: email.toLowerCase().trim() });

    // Always return success — don't reveal if email is registered
    if (!user) {
      return res.json({
        success: true,
        message: "If this email is registered, a password reset link has been sent.",
      });
    }

    // ── Generate secure random token ─────────────────────────
    const crypto = require("crypto");
    const rawToken    = crypto.randomBytes(32).toString("hex");   // 64-char hex
    const hashedToken = crypto.createHash("sha256").update(rawToken).digest("hex");
    const expires     = new Date(Date.now() + 15 * 60 * 1000);  // 15 minutes

    // Save hashed token in DB
    user.resetPasswordToken   = hashedToken;
    user.resetPasswordExpires = expires;
    await user.save({ validateBeforeSave: false });

    // ── Build reset URL ───────────────────────────────────────
    const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";
    const resetUrl    = `${frontendUrl}/reset-password/${rawToken}`;

    // ── Send email ────────────────────────────────────────────
    const tpl = emailTemplates.resetPasswordLink(user.name, resetUrl, 15);
    const emailResult = await sendEmail({ to: user.email, ...tpl });

    console.log(`[ForgotPassword] Token sent for ${user.email} | emailResult:`, emailResult);

    if (emailResult.skipped) {
      // Email credentials not configured in .env
      // Clean up token so user can retry after configuring email
      user.resetPasswordToken   = null;
      user.resetPasswordExpires = null;
      await user.save({ validateBeforeSave: false });
      return res.status(503).json({
        success: false,
        message: "Email service is not configured. Please set EMAIL_USER and EMAIL_PASS (Gmail App Password) in the backend .env file.",
      });
    }

    if (!emailResult.success) {
      // Email failed — clean up token so user can retry
      user.resetPasswordToken   = null;
      user.resetPasswordExpires = null;
      await user.save({ validateBeforeSave: false });
      return res.status(500).json({
        success: false,
        message: `Could not send reset email: ${emailResult.error}. Please check your email configuration in .env.`,
      });
    }

    res.json({
      success: true,
      message: `Password reset link sent to ${user.email.replace(/(.{2})(.*)(@.*)/, "$1***$3")}. Valid for 15 minutes. Check spam folder too.`,
    });
  } catch (error) {
    console.error("[ForgotPassword] Error:", error.message);
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── RESET PASSWORD ───────────────────────────────────────────────
// POST /api/auth/reset-password/:token
// User opens reset link → submits new password → token verified → password updated
const resetPassword = async (req, res) => {
  const { token }       = req.params;
  const { newPassword, confirmPassword } = req.body;

  if (!token) {
    return res.status(400).json({ success: false, message: "Reset token is missing" });
  }
  if (!newPassword) {
    return res.status(400).json({ success: false, message: "New password is required" });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ success: false, message: "Password must be at least 6 characters" });
  }
  if (confirmPassword && newPassword !== confirmPassword) {
    return res.status(400).json({ success: false, message: "Passwords do not match" });
  }

  try {
    // Hash the raw token to compare with stored hashed token
    const crypto      = require("crypto");
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      resetPasswordToken:   hashedToken,
      resetPasswordExpires: { $gt: new Date() },  // not expired
    });

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Reset link is invalid or has expired. Please request a new one.",
      });
    }

    // ── Update password ───────────────────────────────────────
    // Assign plain — pre-save hook (bcrypt) hashes it automatically
    user.password             = newPassword;
    user.resetPasswordToken   = null;
    user.resetPasswordExpires = null;
    await user.save();

    console.log(`[ResetPassword] Password updated for ${user.email}`);

    res.json({
      success: true,
      message: "Password reset successful! You can now login with your new password.",
    });
  } catch (error) {
    console.error("[ResetPassword] Error:", error.message);
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── VERIFY RESET TOKEN ───────────────────────────────────────────
// GET /api/auth/reset-password/:token/verify
// Called by frontend when page loads — checks if token is still valid
const verifyResetToken = async (req, res) => {
  const { token } = req.params;
  try {
    const crypto      = require("crypto");
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");
    const user        = await User.findOne({
      resetPasswordToken:   hashedToken,
      resetPasswordExpires: { $gt: new Date() },
    }).select("name email");

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "This reset link is invalid or has expired.",
      });
    }

    res.json({
      success: true,
      message: "Token is valid.",
      email:   user.email.replace(/(.{2})(.*)(@.*)/, "$1***$3"),
      name:    user.name,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

module.exports = {
  login, registerPatient, registerDoctor, getMe,
  forgotPassword, resetPassword, verifyResetToken,
};