const DoctorReview = require("../models/DoctorReview");
const Appointment  = require("../models/Appointment");
const User         = require("../models/User");
const parseError   = require("../middleware/parseError");

// Helper: recalculate doctor average rating
const updateDoctorRating = async (doctorId) => {
  const reviews = await DoctorReview.find({ doctor_id: doctorId, isVisible: true });
  if (reviews.length === 0) return;
  const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;
  await User.findByIdAndUpdate(doctorId, {
    rating:        Math.round(avg * 10) / 10,
    total_reviews: reviews.length,
  });
};

// ── Patient: Submit Review ───────────────────────────────────────
// POST /api/reviews
const createReview = async (req, res) => {
  const { appointment_id, rating, review = "" } = req.body;
  const patient_id = req.user._id;

  if (!appointment_id || !rating) {
    return res.status(400).json({ success: false, message: "appointment_id and rating are required" });
  }
  if (Number(rating) < 1 || Number(rating) > 5) {
    return res.status(400).json({ success: false, message: "Rating must be between 1 and 5" });
  }

  try {
    // Only allow review for confirmed/completed appointments of THIS patient
    const appt = await Appointment.findOne({
      _id: appointment_id, patient_id,
      status: { $in: ["confirmed", "completed"] },
    }).populate("doctor_id", "name");

    if (!appt) {
      return res.status(403).json({
        success: false,
        message: "You can only review confirmed or completed appointments.",
      });
    }

    // Check already reviewed
    const existing = await DoctorReview.findOne({ appointment_id });
    if (existing) {
      return res.status(400).json({ success: false, message: "You have already reviewed this appointment." });
    }

    const newReview = await DoctorReview.create({
      doctor_id: appt.doctor_id._id,
      patient_id,
      appointment_id,
      rating:  Number(rating),
      review:  review.trim(),
    });

    // Update doctor average rating
    await updateDoctorRating(appt.doctor_id._id);

    res.status(201).json({
      success: true,
      review:  newReview,
      message: `Thank you for reviewing Dr. ${appt.doctor_id.name}!`,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── Public: Get doctor reviews ───────────────────────────────────
// GET /api/reviews/doctor/:doctorId
const getDoctorReviews = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip   = (Number(page) - 1) * Number(limit);
    const query  = { doctor_id: req.params.doctorId, isVisible: true };
    const total  = await DoctorReview.countDocuments(query);
    const reviews = await DoctorReview.find(query)
      .populate("patient_id", "name")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    // Rating breakdown: { 5: count, 4: count, ... }
    const all = await DoctorReview.find(query).select("rating");
    const breakdown = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    all.forEach(r => { breakdown[r.rating] = (breakdown[r.rating] || 0) + 1; });
    const avgRating = all.length
      ? (all.reduce((s, r) => s + r.rating, 0) / all.length).toFixed(1)
      : "0.0";

    res.json({ success: true, total, page: Number(page), avgRating, breakdown, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Patient: Get own reviews ─────────────────────────────────────
// GET /api/reviews/my
const getMyReviews = async (req, res) => {
  try {
    const reviews = await DoctorReview.find({ patient_id: req.user._id })
      .populate("doctor_id",      "name specialization")
      .populate("appointment_id", "appointment_date status")
      .sort({ createdAt: -1 });
    res.json({ success: true, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Patient: Check if appointment already reviewed ────────────────
// GET /api/reviews/check/:appointmentId
const checkReviewed = async (req, res) => {
  try {
    const review = await DoctorReview.findOne({
      appointment_id: req.params.appointmentId,
      patient_id:     req.user._id,
    });
    res.json({ success: true, reviewed: !!review, review: review || null });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Admin: Get all reviews ───────────────────────────────────────
// GET /api/admin/reviews
const getAllReviews = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await DoctorReview.countDocuments();
    const reviews = await DoctorReview.find()
      .populate("patient_id", "name email")
      .populate("doctor_id",  "name specialization")
      .populate("appointment_id", "appointment_date")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));
    res.json({ success: true, total, page: Number(page), reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Admin: Toggle review visibility ─────────────────────────────
// PUT /api/admin/reviews/:id/toggle
const toggleVisibility = async (req, res) => {
  try {
    const review = await DoctorReview.findById(req.params.id);
    if (!review) return res.status(404).json({ success: false, message: "Review not found" });
    review.isVisible = !review.isVisible;
    await review.save();
    await updateDoctorRating(review.doctor_id);
    res.json({ success: true, isVisible: review.isVisible });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { createReview, getDoctorReviews, getMyReviews, checkReviewed, getAllReviews, toggleVisibility };