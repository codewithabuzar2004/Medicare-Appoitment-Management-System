/**
 * Payment Controller — Razorpay Integration (Production Ready)
 * Keys: rzp_test_SbfqNZxtS5shtQ
 *
 * Flow:
 *  1. Patient selects "Pay Online" → POST /api/payment/create-order
 *  2. Backend creates Razorpay order, saves pending appointment
 *  3. Frontend opens Razorpay checkout with real keys
 *  4. Payment success → POST /api/payment/verify → HMAC verify → confirmed
 *  5. Payment fail/dismiss → POST /api/payment/fail → cancelled
 */
const crypto         = require("crypto");
const Appointment    = require("../models/Appointment");
const PaymentHistory = require("../models/PaymentHistory");
const { sendEmail, emailTemplates } = require("../utils/emailService");
const User           = require("../models/User");
const parseError     = require("../middleware/parseError");

// Singleton Razorpay instance
let _razorpayInstance = null;
const getRazorpay = () => {
  if (_razorpayInstance) return _razorpayInstance;
  const Razorpay = require("razorpay");
  _razorpayInstance = new Razorpay({
    key_id:     process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });
  return _razorpayInstance;
};

// IST helpers
const IST_OFFSET = 5.5 * 60 * 60 * 1000;
const getISTHour = (d) => new Date(d.getTime() + IST_OFFSET).getUTCHours();
const getISTDayBounds = (date) => {
  const s = new Date(date.getTime() + IST_OFFSET).toISOString().split("T")[0];
  return {
    dayStart: new Date(`${s}T00:00:00+05:30`),
    dayEnd:   new Date(`${s}T23:59:59+05:30`),
  };
};

// ── 1. CREATE RAZORPAY ORDER ─────────────────────────────────────
// POST /api/payment/create-order
const createOrder = async (req, res) => {
  const { doctor_id, appointment_date, notes = "" } = req.body;
  const patient_id = req.user._id.toString();

  if (!doctor_id || !appointment_date) {
    return res.status(400).json({ success: false, message: "doctor_id and appointment_date are required" });
  }

  const apptDate = new Date(appointment_date);

  if (isNaN(apptDate.getTime())) {
    return res.status(400).json({ success: false, message: "Invalid appointment date format" });
  }
  if (apptDate <= new Date()) {
    return res.status(400).json({ success: false, message: "Appointment date must be in the future" });
  }
  const istHour = getISTHour(apptDate);
  if (istHour < 9 || istHour >= 19) {
    return res.status(400).json({
      success: false,
      message: "Appointments can only be booked between 9:00 AM and 7:00 PM IST.",
    });
  }

  try {
    const doctor = await User.findOne({ _id: doctor_id, role: "doctor", status: "active" });
    if (!doctor) {
      return res.status(404).json({ success: false, message: "Doctor not found or not available" });
    }

    const patient = await User.findById(patient_id);
    if (!patient) {
      return res.status(404).json({ success: false, message: "Patient not found" });
    }

    // Duplicate appointment check (same patient + same doctor + same day)
    const { dayStart, dayEnd } = getISTDayBounds(apptDate);
    const duplicate = await Appointment.findOne({
      patient_id,
      doctor_id,
      status: { $in: ["pending", "confirmed"] },
      appointment_date: { $gte: dayStart, $lte: dayEnd },
    });
    if (duplicate) {
      return res.status(400).json({
        success: false,
        errorCode: "PATIENT_ALREADY_BOOKED",
        message: "You already have an appointment with this doctor on this day.",
      });
    }

    // Slot conflict check (exact datetime)
    const conflict = await Appointment.findOne({
      doctor_id,
      status: { $in: ["pending", "confirmed"] },
      appointment_date: apptDate,
    });
    if (conflict) {
      return res.status(400).json({
        success: false,
        errorCode: "SLOT_ALREADY_BOOKED",
        message: "This time slot is already booked by another patient. Please select a different time.",
      });
    }

    const fee = doctor.consultation_fee || 100; // minimum ₹1 for Razorpay
    const amountInPaise = Math.round(fee * 100);

    // Create Razorpay order
    const razorpay = getRazorpay();
    const order = await razorpay.orders.create({
      amount:   amountInPaise,
      currency: "INR",
      receipt:  `rcpt_${patient_id.slice(-6)}_${Date.now()}`,
      notes: {
        patient_name:     patient.name,
        patient_email:    patient.email,
        doctor_name:      doctor.name,
        specialization:   doctor.specialization,
        appointment_date: apptDate.toISOString(),
      },
    });

    // Save appointment with pending status
    const appointment = await Appointment.create({
      patient_id,
      doctor_id,
      appointment_date:  apptDate,
      fee_at_booking:    fee,
      notes:             notes.trim(),
      status:            "pending",
      paymentStatus:     "pending",
      paymentMode:       "razorpay",
      razorpay_order_id: order.id,
    });

    // Create PaymentHistory record
    await PaymentHistory.create({
      appointment_id:    appointment._id,
      patient_id,
      doctor_id,
      amount:            fee,
      paymentMode:       "razorpay",
      status:            "pending",
      razorpay_order_id: order.id,
      description:       `Online payment for appointment with Dr. ${doctor.name} on ${apptDate.toLocaleDateString("en-IN")}`,
    });

    // Respond with everything frontend needs for Razorpay checkout
    res.status(201).json({
      success: true,
      order: {
        id:       order.id,
        amount:   order.amount,
        currency: order.currency,
      },
      appointment: {
        _id:              appointment._id,
        appointment_date: appointment.appointment_date,
        fee_at_booking:   appointment.fee_at_booking,
      },
      // Send key directly so frontend doesn't need to hardcode
      key_id: process.env.RAZORPAY_KEY_ID,
      prefill: {
        name:    patient.name,
        email:   patient.email,
        contact: patient.phone || "",
      },
      notes: {
        doctor:  doctor.name,
        date:    apptDate.toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata" }),
        fee:     `Rs. ${fee}`,
      },
    });
  } catch (error) {
    console.error("Razorpay createOrder error:", error.message);
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── 2. VERIFY PAYMENT (HMAC signature) ──────────────────────────
// POST /api/payment/verify
const verifyPayment = async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, appointment_id } = req.body;

  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !appointment_id) {
    return res.status(400).json({ success: false, message: "All payment fields are required" });
  }

  try {
    // Verify HMAC-SHA256 signature
    const body      = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expected  = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    if (expected !== razorpay_signature) {
      // Signature mismatch — mark failed
      await Appointment.findByIdAndUpdate(appointment_id, {
        paymentStatus: "failed",
        status:        "cancelled",
      });
      await PaymentHistory.findOneAndUpdate(
        { razorpay_order_id },
        { status: "failed", failureReason: "Signature verification failed" }
      );
      return res.status(400).json({ success: false, message: "Payment verification failed. Please contact support." });
    }

    // Signature valid — confirm appointment
    const appointment = await Appointment.findByIdAndUpdate(
      appointment_id,
      {
        paymentStatus:       "paid",
        status:              "confirmed",
        razorpay_payment_id,
        razorpay_signature,
      },
      { new: true }
    )
      .populate("doctor_id",  "name specialization consultation_fee email")
      .populate("patient_id", "name email phone");

    if (!appointment) {
      return res.status(404).json({ success: false, message: "Appointment not found" });
    }

    // Update PaymentHistory
    await PaymentHistory.findOneAndUpdate(
      { razorpay_order_id },
      {
        status:              "success",
        razorpay_payment_id,
        description:         `Payment successful — Dr. ${appointment.doctor_id.name}`,
      }
    );

    // Real-time notifications
    const io = req.app.get("io");
    if (io) {
      io.to(`doctor_${appointment.doctor_id._id}`).emit("refresh", { reason: "new_appointment_paid" });
      io.to("admin").emit("refresh", { reason: "payment_success" });
    }

    // Send confirmation email
    try {
      const dateStr = new Date(appointment.appointment_date).toLocaleString("en-IN", {
        timeZone: "Asia/Kolkata",
        day: "2-digit", month: "long", year: "numeric",
        hour: "2-digit", minute: "2-digit",
      });
      const tpl = emailTemplates.appointmentConfirmed(
        appointment.patient_id?.name || req.user.name,
        appointment.doctor_id.name,
        dateStr,
        appointment.fee_at_booking
      );
      sendEmail({ to: appointment.patient_id?.email || req.user.email, ...tpl });
    } catch { /* email failure should never break the response */ }

    res.json({
      success: true,
      message: "Payment verified! Your appointment is confirmed.",
      appointment: {
        _id:              appointment._id,
        appointment_date: appointment.appointment_date,
        status:           appointment.status,
        paymentStatus:    appointment.paymentStatus,
        fee_at_booking:   appointment.fee_at_booking,
        doctor:           { name: appointment.doctor_id.name, specialization: appointment.doctor_id.specialization },
      },
    });
  } catch (error) {
    console.error("verifyPayment error:", error.message);
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── 3. PAYMENT FAILED / DISMISSED ───────────────────────────────
// POST /api/payment/fail
const paymentFailed = async (req, res) => {
  const { appointment_id, razorpay_order_id } = req.body;
  try {
    const query = appointment_id ? { _id: appointment_id } : { razorpay_order_id };
    const appt  = await Appointment.findOneAndUpdate(query, {
      paymentStatus: "failed",
      status:        "cancelled",
    });

    if (appt?.razorpay_order_id) {
      await PaymentHistory.findOneAndUpdate(
        { razorpay_order_id: appt.razorpay_order_id },
        { status: "failed", failureReason: "Payment cancelled or dismissed by user" }
      );
    }

    const io = req.app.get("io");
    if (io) io.to("admin").emit("refresh", { reason: "payment_failed" });

    res.json({ success: true, message: "Payment marked as failed." });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── 4. GET PAYMENT STATUS ────────────────────────────────────────
// GET /api/payment/status/:appointmentId
const getPaymentStatus = async (req, res) => {
  try {
    const appt = await Appointment.findOne({
      _id:        req.params.appointmentId,
      patient_id: req.user._id,
    }).select("status paymentStatus paymentMode fee_at_booking razorpay_order_id razorpay_payment_id");

    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });
    res.json({ success: true, payment: appt });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── 5. GET ALL PAYMENT HISTORY (admin) ──────────────────────────
// GET /api/payment/history/all  OR  GET /api/admin/payments
const getAllPaymentHistory = async (req, res) => {
  try {
    const { page = 1, limit = 20, status, paymentMode } = req.query;
    const query = {};
    if (status)      query.status = status;
    if (paymentMode) query.paymentMode = paymentMode;

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await PaymentHistory.countDocuments(query);
    const payments = await PaymentHistory.find(query)
      .populate("patient_id",     "name email phone")
      .populate("doctor_id",      "name specialization")
      .populate("appointment_id", "appointment_date status")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    const totalRevenue = await PaymentHistory.aggregate([
      { $match: { status: "success" } },
      { $group: { _id: null, total: { $sum: "$amount" } } },
    ]);

    res.json({
      success: true,
      total,
      page: Number(page),
      totalPages: Math.ceil(total / limit),
      totalRevenue: totalRevenue[0]?.total || 0,
      payments,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  createOrder,
  verifyPayment,
  paymentFailed,
  getPaymentStatus,
  getAllPaymentHistory,
};