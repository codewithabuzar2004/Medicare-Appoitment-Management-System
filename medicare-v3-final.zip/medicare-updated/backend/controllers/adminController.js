/**
 * Admin Controller
 * All functions here require role: admin (enforced in routes)
 * Routes: /api/admin/*
 */
const User        = require("../models/User");
const ActivityLog = require("../models/ActivityLog");
const { logAction } = require("./activityLogController");
const { sendEmail, emailTemplates } = require("../utils/emailService");
const Appointment = require("../models/Appointment");
const Availability = require("../models/Availability");
const parseError  = require("../middleware/parseError");

// ── DASHBOARD STATS ──────────────────────────────────────────────
// GET /api/admin/stats
const getStats = async (req, res) => {
  try {
    const [
      totalPatients, totalDoctors, pendingDoctors,
      activeDoctors, blockedDoctors, totalAppointments,
      pendingAppts, confirmedAppts, cancelledAppts,
    ] = await Promise.all([
      User.countDocuments({ role: "patient" }),
      User.countDocuments({ role: "doctor" }),
      User.countDocuments({ role: "doctor", status: "pending" }),
      User.countDocuments({ role: "doctor", status: "active" }),
      User.countDocuments({ role: "doctor", status: "blocked" }),
      Appointment.countDocuments(),
      Appointment.countDocuments({ status: "pending" }),
      Appointment.countDocuments({ status: "confirmed" }),
      Appointment.countDocuments({ status: "cancelled" }),
    ]);

    res.json({
      success: true,
      stats: {
        patients:     { total: totalPatients },
        doctors:      { total: totalDoctors, pending: pendingDoctors, active: activeDoctors, blocked: blockedDoctors },
        appointments: { total: totalAppointments, pending: pendingAppts, confirmed: confirmedAppts, cancelled: cancelledAppts },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── GET ALL PATIENTS ─────────────────────────────────────────────
// GET /api/admin/patients?search=&page=1&limit=20
const getAllPatients = async (req, res) => {
  try {
    const { search = "", page = 1, limit = 20 } = req.query;
    const query = { role: "patient" };
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
      ];
    }
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await User.countDocuments(query);
    const users = await User.find(query).select("-password").sort({ createdAt: -1 }).skip(skip).limit(Number(limit));
    res.json({ success: true, total, page: Number(page), totalPages: Math.ceil(total / limit), users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── GET ALL DOCTORS ──────────────────────────────────────────────
// GET /api/admin/doctors?status=pending&search=&specialization=
const getAllDoctors = async (req, res) => {
  try {
    const { status, search = "", specialization, page = 1, limit = 20 } = req.query;
    const query = { role: "doctor" };
    if (status)         query.status = status;
    if (specialization) query.specialization = specialization;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }
    const skip  = (Number(page) - 1) * Number(limit);
    const total = await User.countDocuments(query);
    const doctors = await User.find(query).select("-password").sort({ createdAt: -1 }).skip(skip).limit(Number(limit));
    res.json({ success: true, total, page: Number(page), totalPages: Math.ceil(total / limit), doctors });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── APPROVE DOCTOR ───────────────────────────────────────────────
// PUT /api/admin/doctors/:id/approve
const approveDoctor = async (req, res) => {
  try {
    const doctor = await User.findOne({ _id: req.params.id, role: "doctor" });
    if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });
    if (doctor.status === "active") {
      return res.status(400).json({ success: false, message: "Doctor is already approved" });
    }
    doctor.status = "active";
    await doctor.save();

    // Real-time: notify doctor they are approved
    const io = req.app.get("io");
    if (io) {
      io.to(`doctor_${doctor._id}`).emit("refresh", { reason: "doctor_approved" });
      io.emit("refresh_doctors", { reason: "doctor_approved" });
    }

    // Log admin action
    await logAction({
      admin_id:    req.user._id,
      action:      "APPROVED_DOCTOR",
      target_id:   doctor._id,
      target_type: "user",
      details:     `Approved Dr. ${doctor.name} (${doctor.email})`,
      ip:          req.ip,
    });

    // Send approval email (async — don't await so it doesn't delay response)
    const tpl = emailTemplates.doctorApproved(doctor.name);
    sendEmail({ to: doctor.email, ...tpl });

    res.json({
      success: true,
      message: `Dr. ${doctor.name} has been approved and can now login.`,
      doctor:  { _id: doctor._id, name: doctor.name, email: doctor.email, status: doctor.status },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── REJECT DOCTOR ────────────────────────────────────────────────
// PUT /api/admin/doctors/:id/reject
const rejectDoctor = async (req, res) => {
  try {
    const doctor = await User.findOne({ _id: req.params.id, role: "doctor" });
    if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });
    doctor.status = "rejected";
    await doctor.save();

    await logAction({
      admin_id:    req.user._id,
      action:      "REJECTED_DOCTOR",
      target_id:   doctor._id,
      target_type: "user",
      details:     `Rejected Dr. ${doctor.name} (${doctor.email})`,
      ip:          req.ip,
    });

    const tplR = emailTemplates.doctorRejected(doctor.name);
    sendEmail({ to: doctor.email, ...tplR });
    res.json({ success: true, message: `Dr. ${doctor.name} has been rejected.` });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── TOGGLE USER STATUS (block/unblock) ───────────────────────────
// PUT /api/admin/users/:id/toggle-status
const toggleUserStatus = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    if (user.role === "admin") {
      return res.status(403).json({ success: false, message: "Cannot modify admin status" });
    }

    // Doctor: toggle between active and blocked (not pending)
    // Patient: toggle between active and blocked
    user.status = user.status === "blocked" ? "active" : "blocked";
    await user.save();

    const io = req.app.get("io");
    if (io) {
      io.to(`${user.role}_${user._id}`).emit("refresh", { reason: "status_changed" });
      io.to("admin").emit("refresh", { reason: "user_status_changed" });
    }

    res.json({
      success: true,
      message: `${user.name} has been ${user.status === "blocked" ? "blocked" : "activated"}.`,
      status: user.status,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── UPDATE DOCTOR (admin edits doctor profile) ───────────────────
// PUT /api/admin/doctors/:id
const updateDoctor = async (req, res) => {
  try {
    const { password, role, ...updateData } = req.body; // prevent role change
    if (password) {
      const bcrypt = require("bcryptjs");
      updateData.password = await bcrypt.hash(password, 12);
    }
    const doctor = await User.findOneAndUpdate(
      { _id: req.params.id, role: "doctor" },
      updateData,
      { new: true, runValidators: true }
    ).select("-password");
    if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });

    const io = req.app.get("io");
    if (io) io.emit("refresh_doctors", { reason: "doctor_updated" });

    res.json({ success: true, doctor });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── UPDATE PATIENT (admin edits patient) ─────────────────────────
// PUT /api/admin/patients/:id
const updatePatient = async (req, res) => {
  try {
    const { password, role, ...updateData } = req.body;
    if (password) {
      const bcrypt = require("bcryptjs");
      updateData.password = await bcrypt.hash(password, 12);
    }
    const user = await User.findOneAndUpdate(
      { _id: req.params.id, role: "patient" },
      updateData,
      { new: true, runValidators: true }
    ).select("-password");
    if (!user) return res.status(404).json({ success: false, message: "Patient not found" });
    res.json({ success: true, user });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── DELETE USER (cascade delete) ─────────────────────────────────
// DELETE /api/admin/users/:id
const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    if (user.role === "admin") {
      return res.status(403).json({ success: false, message: "Cannot delete admin" });
    }

    // Cascade delete
    if (user.role === "doctor") {
      await Promise.all([
        Appointment.deleteMany({ doctor_id: user._id }),
        Availability.deleteMany({ doctor_id: user._id }),
      ]);
    } else if (user.role === "patient") {
      await Appointment.deleteMany({ patient_id: user._id });
    }

    await user.deleteOne();

    const io = req.app.get("io");
    if (io) io.to("admin").emit("refresh", { reason: "user_deleted" });

    await logAction({
      admin_id:    req.user._id,
      action:      "DELETED_USER",
      target_id:   user._id,
      target_type: "user",
      details:     `Deleted ${user.role}: ${user.name} (${user.email})`,
      ip:          req.ip,
    });

    res.json({ success: true, message: `${user.name} and all related data deleted.` });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── GET ALL APPOINTMENTS ─────────────────────────────────────────
// GET /api/admin/appointments?status=&page=1
const getAllAppointments = async (req, res) => {
  try {
    const { status, search = "", page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await Appointment.countDocuments(query);
    const appointments = await Appointment.find(query)
      .populate("patient_id", "name email phone")
      .populate("doctor_id",  "name specialization consultation_fee")
      .sort({ createdAt: -1 }).skip(skip).limit(Number(limit));

    res.json({ success: true, total, page: Number(page), totalPages: Math.ceil(total / limit), appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── UPDATE APPOINTMENT STATUS ────────────────────────────────────
// PUT /api/admin/appointments/:id/status
const updateAppointmentStatus = async (req, res) => {
  try {
    const { status } = req.body;
    if (!["pending","confirmed","completed","cancelled"].includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid status" });
    }
    const appt = await Appointment.findByIdAndUpdate(req.params.id, { status }, { new: true });
    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });

    const io = req.app.get("io");
    if (io) {
      io.to(`patient_${appt.patient_id}`).emit("refresh", { reason: "appointment_status_changed" });
      io.to(`doctor_${appt.doctor_id}`).emit("refresh",  { reason: "appointment_status_changed" });
    }
    res.json({ success: true, appointment: appt });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── ADD DOCTOR (admin creates doctor directly, status: active) ────
// POST /api/admin/doctors
const createDoctor = async (req, res) => {
  const { name, email, password, specialization, consultation_fee, experience_years, about, rating } = req.body;
  try {
    const exists = await User.findOne({ email: email?.toLowerCase().trim() });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });

    const doctor = await User.create({
      name, email, password, specialization,
      consultation_fee: Number(consultation_fee),
      experience_years: Number(experience_years) || 0,
      about: about || "",
      rating: rating || 4.0,
      role: "doctor",
      status: "active", // Admin-created doctors are immediately active
    });

    const io = req.app.get("io");
    if (io) io.emit("refresh_doctors", { reason: "doctor_created" });

    const { password: _, ...safe } = doctor.toObject();
    res.status(201).json({ success: true, doctor: safe });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── ADD PATIENT (admin creates patient) ──────────────────────────
// POST /api/admin/patients
const createPatient = async (req, res) => {
  const { name, email, password, phone } = req.body;
  try {
    const exists = await User.findOne({ email: email?.toLowerCase().trim() });
    if (exists) return res.status(400).json({ success: false, message: "Email already registered" });
    const user = await User.create({ name, email, password, phone, role: "patient", status: "active" });
    const { password: _, ...safe } = user.toObject();
    res.status(201).json({ success: true, user: safe });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

module.exports = {
  getStats,
  getAllPatients, getAllDoctors, getAllAppointments,
  approveDoctor, rejectDoctor,
  toggleUserStatus,
  updateDoctor, updatePatient,
  deleteUser,
  createDoctor, createPatient,
  updateAppointmentStatus,
};