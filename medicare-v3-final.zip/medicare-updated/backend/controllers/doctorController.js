/**
 * Doctor Controller
 * Routes: /api/doctor/*  (requires role: doctor)
 *         /api/doctors/* (public for patient/visitor)
 */
const User           = require("../models/User");
const PaymentHistory = require("../models/PaymentHistory");
const Appointment  = require("../models/Appointment");
const Availability = require("../models/Availability");
const parseError   = require("../middleware/parseError");
const { sendEmail, emailTemplates } = require("../utils/emailService");

// ── PUBLIC: Get all active doctors ──────────────────────────────
// GET /api/doctors/active
const getActiveDoctors = async (req, res) => {
  try {
    const { search = "", specialization } = req.query;
    const query = { role: "doctor", status: "active" };
    if (specialization) query.specialization = specialization;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { specialization: { $regex: search, $options: "i" } },
      ];
    }
    const doctors = await User.find(query).select("-password").sort({ rating: -1 });
    res.json({ success: true, doctors });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── PUBLIC: Get single doctor ────────────────────────────────────
// GET /api/doctors/:id
const getDoctorById = async (req, res) => {
  try {
    const doctor = await User.findOne({ _id: req.params.id, role: "doctor" }).select("-password");
    if (!doctor) return res.status(404).json({ success: false, message: "Doctor not found" });
    res.json({ success: true, doctor });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── DOCTOR: Get own profile ──────────────────────────────────────
// GET /api/doctor/profile
const getDoctorProfile = async (req, res) => {
  try {
    const doctor = await User.findById(req.user._id).select("-password");
    res.json({ success: true, doctor });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── DOCTOR: Update own profile ───────────────────────────────────
// PUT /api/doctor/profile
const updateDoctorProfile = async (req, res) => {
  try {
    const { password, role, status, ...updateData } = req.body; // prevent role/status change
    if (password) {
      const bcrypt = require("bcryptjs");
      updateData.password = await bcrypt.hash(password, 12);
    }
    const doctor = await User.findByIdAndUpdate(
      req.user._id,
      updateData,
      { new: true, runValidators: true }
    ).select("-password");

    const io = req.app.get("io");
    if (io) io.emit("refresh_doctors", { reason: "doctor_updated" });

    res.json({ success: true, doctor });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// ── DOCTOR: Get own appointments ─────────────────────────────────
// GET /api/doctor/appointments?status=&search=
const getDoctorAppointments = async (req, res) => {
  try {
    const { status, search = "" } = req.query;
    const query = { doctor_id: req.user._id };
    if (status) query.status = status;

    let appointments = await Appointment.find(query)
      .populate("patient_id", "name email phone")
      .sort({ createdAt: -1 });

    if (search) {
      appointments = appointments.filter(a =>
        a.patient_id?.name?.toLowerCase().includes(search.toLowerCase()) ||
        a.patient_id?.email?.toLowerCase().includes(search.toLowerCase())
      );
    }

    res.json({ success: true, appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── DOCTOR: Update appointment status ────────────────────────────
// PUT /api/doctor/appointments/:id/status
// Allowed transitions: pending→confirmed, confirmed→completed, any→cancelled
const updateAppointmentStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const allowed = ["confirmed", "completed", "cancelled"];
    if (!allowed.includes(status)) {
      return res.status(400).json({ success: false, message: `Status must be one of: ${allowed.join(", ")}` });
    }

    const appt = await Appointment.findOne({ _id: req.params.id, doctor_id: req.user._id })
      .populate("patient_id", "name email");
    if (!appt) return res.status(404).json({ success: false, message: "Appointment not found" });

    // Guard illogical transitions
    if (status === "completed" && appt.status !== "confirmed") {
      return res.status(400).json({ success: false, message: "Only confirmed appointments can be marked as completed." });
    }

    appt.status = status;
    // If cancelling — update payment status to refunded or failed
    if (status === "cancelled") {
      appt.paymentStatus = appt.paymentStatus === "paid" ? "refunded" : "failed";
      try {
        await PaymentHistory.findOneAndUpdate(
          { appointment_id: appt._id },
          { status: appt.paymentStatus, failureReason: "Cancelled by doctor" }
        );
      } catch { /* non-blocking */ }
    }
    await appt.save();

    // Email patient about status change
    const fmtIST = (d) => new Date(d).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day:"2-digit", month:"long", year:"numeric", hour:"2-digit", minute:"2-digit" });
    if (appt.patient_id?.email) {
      const doctorUser = await require("../models/User").findById(req.user._id).select("name");
      sendEmail({ to: appt.patient_id.email, ...emailTemplates.appointmentStatusUpdate(appt.patient_id.name, doctorUser?.name || "Doctor", fmtIST(appt.appointment_date), status) });
    }

    const io = req.app.get("io");
    if (io) {
      io.to(`patient_${appt.patient_id._id}`).emit("refresh", { reason: "appointment_status_changed", status });
      io.to("admin").emit("refresh", { reason: "appointment_status_changed" });
    }

    res.json({ success: true, appointment: appt });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── DOCTOR: Manage availability slots ────────────────────────────
// GET /api/doctor/availability
const getAvailability = async (req, res) => {
  try {
    const slots = await Availability.find({ doctor_id: req.user._id }).sort({ day: 1 });
    res.json({ success: true, slots });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/doctor/availability
const addAvailability = async (req, res) => {
  const { day, start_time, end_time } = req.body;
  if (!day || !start_time || !end_time) {
    return res.status(400).json({ success: false, message: "day, start_time and end_time are required" });
  }
  if (start_time >= end_time) {
    return res.status(400).json({ success: false, message: "End time must be after start time" });
  }

  // Night shift restriction
  const startHour = parseInt(start_time.split(":")[0]);
  const endHour   = parseInt(end_time.split(":")[0]);
  if (startHour < 7 || startHour >= 20) {
    return res.status(400).json({ success: false, message: "Slots must start between 7:00 AM and 8:00 PM" });
  }
  if (endHour > 20) {
    return res.status(400).json({ success: false, message: "Slots must end by 8:00 PM" });
  }

  try {
    const exists = await Availability.findOne({ doctor_id: req.user._id, day, start_time, end_time });
    if (exists) return res.status(400).json({ success: false, message: "This slot already exists" });

    const slot = await Availability.create({ doctor_id: req.user._id, day, start_time, end_time });

    const io = req.app.get("io");
    if (io) {
      io.emit("refresh_doctors", { reason: "slot_added" });
      io.to("admin").emit("refresh", { reason: "slot_added" });
    }

    res.status(201).json({ success: true, slot });
  } catch (error) {
    res.status(400).json({ success: false, message: parseError(error) });
  }
};

// DELETE /api/doctor/availability/:id
const deleteAvailability = async (req, res) => {
  try {
    const slot = await Availability.findOne({ _id: req.params.id, doctor_id: req.user._id });
    if (!slot) return res.status(404).json({ success: false, message: "Slot not found" });
    await slot.deleteOne();

    const io = req.app.get("io");
    if (io) io.emit("refresh_doctors", { reason: "slot_deleted" });

    res.json({ success: true, message: "Slot deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: parseError(error) });
  }
};

// ── PUBLIC: Get doctor availability ─────────────────────────────
// GET /api/doctors/:id/availability
const getDoctorAvailability = async (req, res) => {
  try {
    const slots = await Availability.find({ doctor_id: req.params.id }).sort({ day: 1 });
    res.json({ success: true, slots });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getActiveDoctors, getDoctorById, getDoctorAvailability,
  getDoctorProfile, updateDoctorProfile,
  getDoctorAppointments, updateAppointmentStatus,
  getAvailability, addAvailability, deleteAvailability,
};