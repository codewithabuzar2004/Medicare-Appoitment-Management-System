require("dotenv").config();
const express    = require("express");
const cors       = require("cors");
const http       = require("http");
const { Server } = require("socket.io");
const connectDB  = require("./config/db");

const app    = express();
const server = http.createServer(app);

// ── Security middleware ───────────────────────────────────────────
try {
  const helmet = require("helmet");
  app.use(helmet());
} catch { console.log("ℹ️  Run: npm install (helmet not found)"); }

try {
  const morgan = require("morgan");
  if (process.env.NODE_ENV !== "production") app.use(morgan("dev"));
} catch { console.log("ℹ️  Run: npm install (morgan not found)"); }

// ── Rate limiting ─────────────────────────────────────────────────
try {
  const rateLimit = require("express-rate-limit");

  const skipLocalhost = (req) =>
    req.ip === '127.0.0.1' || req.ip === '::1' || req.ip === '::ffff:127.0.0.1';

  // Auth routes: prevent brute force (skip localhost in dev)
  app.use("/api/auth", rateLimit({
    windowMs: 15 * 60 * 1000,
    max: process.env.NODE_ENV === 'production' ? 20 : 200,
    skip: skipLocalhost,
    message: { success: false, message: "Too many login attempts. Please try again after 15 minutes." },
    standardHeaders: true,
    legacyHeaders: false,
  }));

  // General API limit
  app.use("/api", rateLimit({
    windowMs: 15 * 60 * 1000,
    max: process.env.NODE_ENV === 'production' ? 300 : 1000,
    skip: skipLocalhost,
    message: { success: false, message: "Too many requests. Please try again later." },
    standardHeaders: true,
    legacyHeaders: false,
  }));
} catch { console.log("ℹ️  Run: npm install (express-rate-limit not found)"); }

// ── CORS ──────────────────────────────────────────────────────────
const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(",").map(o => o.trim())
  : ["http://localhost:5173", "http://localhost:5174", "http://localhost:3000"];

const corsOptions = {
  origin: (origin, cb) => {
    // Allow requests with no origin (Postman, curl, mobile apps)
    if (!origin) return cb(null, true);
    // In development: allow ALL localhost ports automatically
    if (process.env.NODE_ENV !== "production") {
      const isLocalhost = /^http:\/\/localhost:\d+$/.test(origin) ||
                          /^http:\/\/127\.0\.0\.1:\d+$/.test(origin);
      if (isLocalhost) return cb(null, true);
    }
    // In production: check against whitelist
    if (allowedOrigins.includes(origin)) return cb(null, true);
    // Reject — but don't throw (throwing crashes the error handler)
    cb(null, false);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
};

// Handle OPTIONS preflight for ALL routes
app.options("*", cors(corsOptions));
app.use(cors(corsOptions));

// ── Body parsing ──────────────────────────────────────────────────
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// ── Socket.io ─────────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      if (process.env.NODE_ENV !== "production") {
        const isLocal = /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);
        if (isLocal) return cb(null, true);
      }
      if (allowedOrigins.includes(origin)) return cb(null, true);
      cb(null, false);
    },
    methods: ["GET", "POST"],
    credentials: true,
  },
});
app.set("io", io);

io.on("connection", (socket) => {
  socket.on("join", (room) => socket.join(room));
});

// ── Health check ──────────────────────────────────────────────────
app.get("/health", (req, res) =>
  res.json({ success: true, status: "ok", uptime: process.uptime(), timestamp: new Date().toISOString() })
);
app.get("/", (req, res) =>
  res.json({ success: true, message: "MediCare API v2.0", version: "2.0.0" })
);

// ── API Routes ────────────────────────────────────────────────────
// /api/auth     → login, register patient/doctor
// /api/admin    → admin-only management (stats, approve, CRUD)
// /api/doctor   → doctor profile, appointments, availability
// /api/doctors  → public doctor info (search, profile, schedule)
// /api/patient  → patient profile, book/cancel appointments
// /api/contact  → contact form

// ── Public Stats (for home page — no auth required) ──────────────────────────
app.get("/api/stats", async (req, res) => {
  try {
    const User        = require("./models/User");
    const Appointment = require("./models/Appointment");
    const [totalDoctors, totalPatients, totalAppointments] = await Promise.all([
      User.countDocuments({ role: "doctor", status: "active" }),
      User.countDocuments({ role: "patient" }),
      Appointment.countDocuments({ status: { $in: ["confirmed","completed"] } }),
    ]);
    const specs = await User.distinct("specialization", { role: "doctor", status: "active" });
    res.json({ success: true, stats: {
      totalDoctors, totalPatients, totalAppointments,
      totalSpecializations: specs.filter(Boolean).length
    }});
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.use("/api/auth",    require("./routes/authRoutes"));
app.use("/api/admin",   require("./routes/adminRoutes"));
app.use("/api/doctor",  require("./routes/doctorRoutes"));
app.use("/api/doctors", require("./routes/publicDoctorRoutes"));
app.use("/api/patient", require("./routes/patientRoutes"));
app.use("/api/contact", require("./routes/contactRoutes"));
app.use("/api/payment", require("./routes/paymentRoutes"));
app.use("/api/reviews", require("./routes/reviewRoutes"));

// ── 404 handler ───────────────────────────────────────────────────

app.use((req, res) =>
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.url} not found` })
);

// ── Global error handler ──────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err.message);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal server error",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
});

// ── Start server ──────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;

connectDB().then(async () => {
  server.listen(PORT, () =>
    console.log(`🚀 Server running on port ${PORT} [${process.env.NODE_ENV || "development"}]`)
  );
  // Auto-seed: create default admin + sample doctors on first run
  try {
    const bcrypt = require("bcryptjs");
    const User   = require("./models/User");

    // ── Admin ─────────────────────────────────────────────────────
    const adminExists = await User.findOne({ role: "admin" });
    if (!adminExists) {
      // Pass plain password — pre-save hook will hash it automatically
      await User.create({
        name:     "Admin",
        email:    process.env.ADMIN_EMAIL    || "admin@medicare.com",
        password: process.env.ADMIN_PASSWORD || "admin123",
        role:     "admin",
        status:   "active",
      });
      console.log("✅ Default admin created successfully");
    }


  } catch (e) {
    console.error("Seed error:", e.message);
  }
});

// ── Graceful shutdown ─────────────────────────────────────────────
process.on("SIGTERM", () => {
  server.close(() => { console.log("Server closed"); process.exit(0); });
});