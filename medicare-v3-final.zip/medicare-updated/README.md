# MediCare — MERN Stack Doctor Appointment System

A full-stack MERN doctor appointment system with real-time updates, role-based access control, and a polished UI.

## 📁 Project Structure

```
medicare-mern/
├── backend/
│   ├── config/db.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── userController.js
│   │   ├── doctorController.js
│   │   ├── appointmentController.js
│   │   ├── availabilityController.js
│   │   └── contactController.js
│   ├── middleware/authMiddleware.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Doctor.js
│   │   ├── Admin.js
│   │   ├── Appointment.js
│   │   ├── Availability.js
│   │   └── Contact.js
│   ├── routes/
│   ├── server.js
│   └── .env
└── frontend/
    └── src/
        ├── contexts/       # AuthContext (sessionStorage), SocketContext
        ├── hooks/          # useRealtimeRefresh
        ├── pages/          # PatientDashboard, DoctorDashboard, AdminDashboard
        ├── components/     # Navbar, HeroSection, ProtectedRoute
        └── lib/api.js      # Axios instance (reads from sessionStorage)
```

## 🚀 Setup & Run

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)

### 1. Backend
```bash
cd backend
npm install
# Edit .env if needed (MONGO_URI, JWT_SECRET, PORT)
npm run dev     # development with nodemon
npm start       # production
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```

- Frontend: **http://localhost:5173**
- Backend API: **http://localhost:5000**

---

## 🔐 Default Credentials (auto-seeded on first run)

| Role    | Email                  | Password   |
|---------|------------------------|------------|
| Admin   | admin@medicare.com     | admin123   |
| Doctor  | rajesh@medicare.com    | doctor123  |
| Doctor  | priya@medicare.com     | doctor123  |
| Doctor  | amit@medicare.com      | doctor123  |
| Doctor  | sneha@medicare.com     | doctor123  |

---

## ✨ Features

### 3 Roles
- **Patient** — Browse & book appointments, cancel (pending only), view profile, edit profile
- **Doctor** — Manage availability slots (AM/PM picker), approve/reject appointments, view patient list
- **Admin** — Full CRUD on patients & doctors, appointment management, block/unblock users

### Real-time (Socket.io)
- Patient books → Doctor & Admin notified instantly
- Doctor approves/rejects → Patient notified instantly
- New doctor registered → Patient list updates without refresh
- Each tab has its own session (`sessionStorage`) — patient and doctor can be open in separate tabs simultaneously

### Security
- JWT authentication (7 day expiry)
- Passwords hashed with bcryptjs
- Blocked users cannot login or use API
- Role-based access control on all routes
- Ownership checks: patients can only cancel own appointments, doctors can only manage own slots
- Email & phone validated on both frontend and backend (Mongoose validators)

### Validations
- Phone: exactly 10 digits
- Consultation fee: whole numbers only (no decimals)
- Appointment: future dates only, no duplicate pending appointments with same doctor on same IST day
- Availability slots: end time must be after start time, no duplicate slots

### IST (Indian Standard Time)
- All dates/times displayed in IST (Asia/Kolkata)
- Appointment datetime stored with correct IST offset (+05:30)

---

## 🏗️ Tech Stack

| Layer     | Technology                           |
|-----------|--------------------------------------|
| Frontend  | React 18, Vite, Tailwind CSS         |
| Backend   | Node.js, Express                     |
| Database  | MongoDB, Mongoose                    |
| Auth      | JWT, bcryptjs, sessionStorage        |
| Realtime  | Socket.io                            |
| Styling   | Tailwind CSS, Framer Motion          |
| Icons     | Lucide React                         |
